package com.chafik.alrafik;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/** Prayer-time and bill-due notifications. Works with alarms set by MainActivity. */
public class AlarmReceiver extends BroadcastReceiver {
    static final String CH = "alrafik_alerts";
    static final String[] PRAYER_NAMES = {"الفجر", "", "الظهر", "العصر", "المغرب", "العشاء"};
    static final int[] PRAYER_IDX = {0, 2, 3, 4, 5};
    static final int PRAYER_BASE = 100;
    static final int PI_FLAGS = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;

    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            rescheduleAll(ctx);
            return;
        }
        if ("weather".equals(intent.getAction())) {
            checkRain(ctx);
            return;
        }
        SharedPreferences sp = ctx.getSharedPreferences("alrafik", Context.MODE_PRIVATE);
        boolean isPrayer = intent.getBooleanExtra("prayer", false);
        String pref = intent.getStringExtra("pref");
        if (pref == null) pref = isPrayer ? "notif_prayer" : "notif_bills";
        if (!sp.getBoolean(pref, true)) return;
        showNotification(ctx, intent.getIntExtra("id", 0), intent.getStringExtra("title"), intent.getStringExtra("text"));
        if (isPrayer) armPrayer(ctx, intent.getIntExtra("idx", 0), intent.getStringExtra("hhmm"));
    }

    static void showNotification(Context ctx, int id, String title, String text) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "تنبيهات الرفيق", NotificationManager.IMPORTANCE_HIGH));
            b = new Notification.Builder(ctx, CH);
        } else {
            b = new Notification.Builder(ctx);
        }
        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        b.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title == null ? "الرفيق" : title)
            .setContentText(text == null ? "" : text)
            .setAutoCancel(true)
            .setContentIntent(PendingIntent.getActivity(ctx, id, open, PI_FLAGS));
        nm.notify(id, b.build());
    }

    static void setAlarm(Context ctx, int code, long when, Intent it) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, code, it, PI_FLAGS);
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.set(AlarmManager.RTC_WAKEUP, when, pi);
    }

    static Intent baseIntent(Context ctx, String action) {
        Intent it = new Intent(ctx, AlarmReceiver.class);
        it.setAction(action);
        return it;
    }

    /** Arms the next occurrence of prayer i at hh:mm (today if still ahead, otherwise tomorrow). */
    static void armPrayer(Context ctx, int i, String hhmm) {
        if (hhmm == null || hhmm.length() < 5) return;
        try {
            Calendar c = Calendar.getInstance();
            c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hhmm.substring(0, 2)));
            c.set(Calendar.MINUTE, Integer.parseInt(hhmm.substring(3, 5)));
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            if (c.getTimeInMillis() <= System.currentTimeMillis()) c.add(Calendar.DAY_OF_YEAR, 1);
            Intent it = baseIntent(ctx, "prayer" + i);
            it.putExtra("prayer", true);
            it.putExtra("idx", i);
            it.putExtra("hhmm", hhmm);
            it.putExtra("id", PRAYER_BASE + i);
            it.putExtra("title", "🕌 حان وقت صلاة " + PRAYER_NAMES[i]);
            it.putExtra("text", "الله أكبر، حيّ على الصلاة");
            setAlarm(ctx, PRAYER_BASE + i, c.getTimeInMillis(), it);
        } catch (Exception e) { }
    }

    /** Called after fresh prayer times are downloaded. times = 6 values in KEYS order. */
    static void savePrayers(Context ctx, String[] times) {
        SharedPreferences sp = ctx.getSharedPreferences("alrafik", Context.MODE_PRIVATE);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times.length; i++) { if (i > 0) sb.append(','); sb.append(times[i]); }
        sp.edit().putString("ptimes", sb.toString()).apply();
        if (!sp.getBoolean("notif_prayer", true)) return;
        for (int i : PRAYER_IDX) armPrayer(ctx, i, times[i]);
    }

    static int ridOf(JSONObject b) {
        try { return Integer.parseInt(b.optString("rid", "0")); } catch (Exception e) { return 0; }
    }

    /** Bill reminder at 09:00 on the due day. */
    static void armBill(Context ctx, JSONObject b) {
        int rid = ridOf(b);
        if (rid <= 0) return;
        try {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(Long.parseLong(b.optString("due", "0")));
            c.set(Calendar.HOUR_OF_DAY, 9);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            if (c.getTimeInMillis() <= System.currentTimeMillis()) return;
            Intent it = baseIntent(ctx, "bill" + rid);
            it.putExtra("id", rid);
            it.putExtra("title", "🧾 فاتورة مستحقة اليوم");
            it.putExtra("text", b.optString("type", "فاتورة") + " — " + b.optString("amount", "") + " دج");
            setAlarm(ctx, rid, c.getTimeInMillis(), it);
        } catch (Exception e) { }
    }

    static void cancelBill(Context ctx, int rid) {
        if (rid <= 0) return;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        am.cancel(PendingIntent.getBroadcast(ctx, rid, baseIntent(ctx, "bill" + rid), PI_FLAGS));
    }

    /** Re-arms everything from saved data (app start, boot, settings change). */
    static void rescheduleAll(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences("alrafik", Context.MODE_PRIVATE);
        String t = sp.getString("ptimes", "");
        String[] parts = t.split(",");
        if (parts.length == 6 && sp.getBoolean("notif_prayer", true)) {
            for (int i : PRAYER_IDX) armPrayer(ctx, i, parts[i]);
        }
        scheduleWeather(ctx);
        if (sp.getBoolean("notif_docs", true)) {
            try {
                JSONArray e = new JSONArray(sp.getString("expiry", "[]"));
                for (int i = 0; i < e.length(); i++) {
                    JSONObject b = e.optJSONObject(i);
                    if (b != null) armExpiry(ctx, b);
                }
            } catch (Exception ex) { }
        }
        if (sp.getBoolean("notif_bills", true)) {
            try {
                JSONArray a = new JSONArray(sp.getString("bills", "[]"));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject b = a.optJSONObject(i);
                    if (b != null && !"1".equals(b.optString("paid"))) armBill(ctx, b);
                }
            } catch (Exception e) { }
        }
    }

    /** Generic one-off alarm. action must be unique per item. */
    static void armAt(Context ctx, String action, int code, long when, String title, String text, String pref) {
        Intent it = baseIntent(ctx, action);
        it.putExtra("id", code);
        it.putExtra("title", title);
        it.putExtra("text", text);
        it.putExtra("pref", pref);
        setAlarm(ctx, code, when, it);
    }

    static void cancelAt(Context ctx, String action, int code) {
        if (code <= 0) return;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        am.cancel(PendingIntent.getBroadcast(ctx, code, baseIntent(ctx, action), PI_FLAGS));
    }

    /** Document expiry: reminder 30 days before, at 09:00. */
    static void armExpiry(Context ctx, JSONObject b) {
        int rid = ridOf(b);
        if (rid <= 0) return;
        try {
            Calendar c = Calendar.getInstance();
            c.setTimeInMillis(Long.parseLong(b.optString("due", "0")));
            c.add(Calendar.DAY_OF_YEAR, -30);
            c.set(Calendar.HOUR_OF_DAY, 9);
            c.set(Calendar.MINUTE, 0);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            if (c.getTimeInMillis() <= System.currentTimeMillis()) return;
            armAt(ctx, "exp" + rid, rid, c.getTimeInMillis(), "🪪 وثيقة تنتهي قريباً",
                b.optString("type", "وثيقة") + " — تنتهي خلال 30 يوماً", "notif_docs");
        } catch (Exception e) { }
    }

    /** Plain HTTP GET for background work (no UI thread). */
    static String getUrl(String u) throws Exception {
        java.net.HttpURLConnection con = (java.net.HttpURLConnection) new java.net.URL(u).openConnection();
        con.setConnectTimeout(10000);
        con.setReadTimeout(10000);
        java.io.BufferedReader r = new java.io.BufferedReader(new java.io.InputStreamReader(con.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        return sb.toString();
    }

    /** Every 3 hours: warn if rain is likely within the next 6 hours (Open-Meteo, no API key). */
    static void scheduleWeather(Context ctx) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 7, baseIntent(ctx, "weather"), PI_FLAGS);
        am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + 60000L, 3 * 3600000L, pi);
    }

    static void checkRain(final Context ctx) {
        final SharedPreferences sp = ctx.getSharedPreferences("alrafik", Context.MODE_PRIVATE);
        if (!sp.getBoolean("notif_weather", true)) return;
        final String la = sp.getString("lat", ""), ln = sp.getString("lng", "");
        if (la.isEmpty()) return;
        new Thread(new Runnable() {
            public void run() {
                try {
                    String s = getUrl("https://api.open-meteo.com/v1/forecast?latitude=" + la + "&longitude=" + ln
                        + "&hourly=precipitation_probability&timezone=auto");
                    JSONArray pp = new JSONObject(s).getJSONObject("hourly").getJSONArray("precipitation_probability");
                    int max = 0;
                    for (int i = 0; i < 6 && i < pp.length(); i++) max = Math.max(max, pp.optInt(i));
                    if (max >= 60) showNotification(ctx, 7, "🌧️ احتمال أمطار قريبة",
                        "نسبة الأمطار حتى " + max + "% في الساعات القادمة. خذ مظلتك.");
                } catch (Exception e) { }
            }
        }).start();
    }
}
