package com.chafik.alrafik;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.view.ViewGroup;
import android.media.AudioManager;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.widget.HorizontalScrollView;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.database.Cursor;
import android.provider.CalendarContract;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Xml;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.TimeZone;

public class MainActivity extends Activity {
    static final String DEV = "Chafik Sehmi";
    static final String VERSION = "5.7 PRO";
    static final int ACC = 0xFFFF7A45, ACC2 = 0xFFFF3D81, CYAN = 0xFF22D3EE, WHITE = 0xFFFFFFFF;
    int BG, CARD, TXT, GRAY, STRIP;
    float SC = 1f;
    boolean dark;
    SharedPreferences sp;
    FrameLayout content;
    TextView[] tabs = new TextView[5];
    int[] tabTarget = {0, 9, 28, 43, 33};
    String[] tabNames = {"🏠\nالرئيسية", "🕌\nالصلاة", "📖\nالقرآن", "🔎\nبحث", "👤\nحسابي"};
    long picked = 0;
    String curFeed = "https://www.echoroukonline.com/feed";
    String curLeague = "4753";
    boolean fixtures = true;
    TextView clockTv;
    final android.os.Handler clockH = new android.os.Handler();
    final Runnable clockR = new Runnable() {
        public void run() {
            if (clockTv != null) clockTv.setText(new SimpleDateFormat("HH:mm:ss", Locale.ENGLISH).format(new Date()));
            clockH.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("alrafik", Context.MODE_PRIVATE);
        notifySetup();
        dark = sp.getBoolean("dark", true);
        SC = sp.getBoolean("senior", false) ? 1.3f : 1f;
        if (dark) { BG = 0xFF0D0F16; CARD = 0xFF171B26; TXT = WHITE; GRAY = 0xFF8B93A7; STRIP = 0xFF10131B; }
        else { BG = 0xFFF2F4F8; CARD = WHITE; TXT = 0xFF14161F; GRAY = 0xFF6B7280; STRIP = 0xFFE6E9F0; }
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setGravity(Gravity.CENTER_VERTICAL);
        strip.setPadding(dp(10), dp(5), dp(10), dp(5));
        strip.setBackgroundColor(STRIP);
        clockTv = tv("--:--:--", 12, ACC, true);
        strip.addView(clockTv, new LinearLayout.LayoutParams(-2, -2));
        TextView title = tv("ALRAFIK PRO • الرفيق  |  تطوير: " + DEV, 11, GRAY, true);
        title.setGravity(Gravity.CENTER);
        strip.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(strip, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(CARD);
        for (int i = 0; i < 5; i++) {
            TextView t = tv(tabNames[i], 11, GRAY, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, dp(10), 0, dp(10));
            t.setOnClickListener(go(tabTarget[i]));
            tabs[i] = t;
            bar.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        FrameLayout frame = new FrameLayout(this);
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        final View splash = splashView();
        frame.addView(splash, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        clockH.post(clockR);
        welcomeSound();
        splash.postDelayed(new Runnable() {
            public void run() {
                splash.animate().alpha(0f).setDuration(450).withEndAction(new Runnable() {
                    public void run() {
                        if (splash.getParent() != null) ((ViewGroup) splash.getParent()).removeView(splash);
                    }
                }).start();
            }
        }, 2300);
        int st = sp.getInt("starttab", 0);
        sp.edit().putInt("starttab", 0).apply();
        show(st);
    }

    @Override
    protected void onDestroy() {
        clockH.removeCallbacks(clockR);
        stopPlayer();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_DOC && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
            JSONObject d = obj("uri", u.toString(), "name", displayName(u), "note", "أُضيفت: " + fmt(System.currentTimeMillis()));
            addItem("docs", d);
            show(20);
        }
    }

    void show(int i) {
        if (!sp.getBoolean("onboarded", false) && i != 44) i = 44;
        if (!navBack && curTab != -1 && curTab != i) hist.add(curTab);
        navBack = false;
        curTab = i;
        qiblaStop();
        qiblaOn = (i == 52);
        if (torchOn && i != 61) torchSet(false);
        qiblaArrow = null;
        int hl = -1;
        for (int k = 0; k < 5; k++) if (tabTarget[k] == i) hl = k;
        for (int k = 0; k < 5; k++) tabs[k].setTextColor(k == hl ? ACC : GRAY);
        content.removeAllViews();
        View v;
        switch (i) {
            case 0: v = home(); break;
            case 1: v = transport(); break;
            case 2: v = telecom(); break;
            case 3: v = news(); break;
            case 4: v = more(); break;
            case 5: v = appts(); break;
            case 6: v = emergency(); break;
            case 7: v = wilayas(); break;
            case 8: v = about(); break;
            case 9: v = prayer(); break;
            case 10: v = grades(); break;
            case 11: v = settings(); break;
            case 12: v = football(); break;
            case 13: v = women(); break;
            case 14: v = cooking(); break;
            case 15: v = clothing(); break;
            case 16: v = seniors(); break;
            case 17: v = services(); break;
            case 18: v = hospitals(); break;
            case 19: v = municipality(); break;
            case 20: v = documents(); break;
            case 21: v = complaints(); break;
            case 22: v = internet(); break;
            case 23: v = notes(); break;
            case 24: v = bills(); break;
            case 25: v = restaurants(); break;
            case 26: v = cycle(); break;
            case 27: v = islam(); break;
            case 28: v = quran(); break;
            case 29: v = hisnCats(); break;
            case 30: v = hadiths(); break;
            case 31: v = teaching(); break;
            case 32: v = tasbih(); break;
            case 33: v = login(); break;
            case 34: v = surah(curSurah); break;
            case 35: v = hisnItems(); break;
            case 36: v = radio(); break;
            case 37: v = tvChannels(); break;
            case 38: v = movies(); break;
            case 39: v = specialNeeds(); break;
            case 40: v = orphans(); break;
            case 41: v = adl(); break;
            case 42: v = store(); break;
            case 43: v = searchView(); break;
            case 44: v = onboarding(); break;
            case 45: v = ramadan(); break;
            case 46: v = zakat(); break;
            case 47: v = budget(); break;
            case 48: v = hajj(); break;
            case 49: v = shopping(); break;
            case 50: v = adminDocs(); break;
            case 51: v = prayerTrack(); break;
            case 53: v = expiry(); break;
            case 54: v = currency(); break;
            case 55: v = docRequests(); break;
            case 56: v = weather(); break;
            case 57: v = books(); break;
            case 58: v = students(); break;
            case 59: v = jobs(); break;
            case 60: v = marketplace(); break;
            case 61: v = torch(); break;
            case 52: v = qibla(); break;
            default: v = services();
        }
        content.addView(v);
    }

    // ---------- helpers ----------
    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    TextView tv(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp * SC); t.setTextColor(color);
        t.setTypeface(bold ? brand() : Typeface.DEFAULT);
        return t;
    }

    GradientDrawable shape(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(radius));
        return g;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(shape(CARD, 18));
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setElevation(dp(3));
        return l;
    }

    void add(LinearLayout parent, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(dp(16), dp(5), dp(16), dp(5));
        parent.addView(v, lp);
    }

    void section(LinearLayout col, String s, int color) {
        TextView t = tv(s, 18, color, true);
        t.setPadding(0, dp(14), 0, dp(2));
        add(col, t);
    }

    LinearLayout page(String title, String sub, ScrollView[] out) {
        ScrollView sv = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, 0, 0, dp(16));
        LinearLayout h = new LinearLayout(this);
        h.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{ACC2, ACC});
        float r = dp(30);
        g.setCornerRadii(new float[]{0, 0, 0, 0, r, r, r, r});
        h.setBackground(g);
        h.setPadding(dp(20), dp(30), dp(20), dp(26));
        h.setElevation(dp(8));
        if (!hist.isEmpty()) {
            TextView back = tv("➜ رجوع", 15, WHITE, true);
            back.setPadding(0, 0, 0, dp(6));
            back.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { goBack(); } });
            h.addView(back);
        }
        h.addView(tv(title, 26, WHITE, true));
        if (sub.length() > 0) h.addView(tv(sub, 13, 0xE6FFFFFF, false));
        col.addView(h, new LinearLayout.LayoutParams(-1, -2));
        sv.addView(col);
        out[0] = sv;
        return col;
    }

    View.OnClickListener go(final int tab) { return new View.OnClickListener() { public void onClick(View v) { show(tab); } }; }
    View.OnClickListener url(final String u) { return new View.OnClickListener() { public void onClick(View v) { open(u); } }; }
    View.OnClickListener call(final String n) { return new View.OnClickListener() { public void onClick(View v) { dial(n); } }; }

    void open(String u) { try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u))); } catch (Exception e) { toast("تعذّر الفتح"); } }
    void dial(String n) { startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(n)))); }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    Button button(String s, int color, int textColor) {
        Button bt = new Button(this);
        bt.setText(s); bt.setTextColor(textColor); bt.setTextSize(14 * SC);
        bt.setBackground(shape(color, 16));
        bt.setAllCaps(false);
        bt.setTypeface(Typeface.DEFAULT_BOLD);
        bt.setPadding(dp(14), dp(12), dp(14), dp(12));
        return bt;
    }

    EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setHintTextColor(GRAY); e.setTextColor(TXT); e.setSingleLine(true); e.setTextSize(16 * SC);
        return e;
    }

    void linkCard(LinearLayout col, String label, String u) {
        LinearLayout c = card();
        c.addView(tv(label, 16, TXT, false));
        c.setOnClickListener(url(u));
        add(col, c);
    }

    void linkGroup(LinearLayout col, String title, int color, String[][] links) {
        section(col, title, color);
        for (String[] l : links) linkCard(col, l[0], l[1]);
    }

    void infoCard(LinearLayout col, String title, final String body) {
        LinearLayout c = card();
        c.addView(tv(title, 16, TXT, true));
        c.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { new AlertDialog.Builder(MainActivity.this).setMessage(body).setPositiveButton("حسناً", null).show(); }
        });
        add(col, c);
    }

    String httpGet(String u) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(u).openConnection();
        con.setConnectTimeout(10000); con.setReadTimeout(10000);
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder(); String line;
        while ((line = r.readLine()) != null) sb.append(line);
        r.close();
        return sb.toString();
    }

    void chooseWilaya(final int back) {
        String[] items = new String[W.length];
        for (int i = 0; i < W.length; i++) items[i] = (i + 1) + " - " + W[i];
        new AlertDialog.Builder(this).setTitle("اختر ولايتك").setItems(items, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface d, int which) { sp.edit().putInt("wilaya", which).apply(); show(back); }
        }).show();
    }

    String fmt(long ms) { return new SimpleDateFormat("EEE d/M  HH:mm", new Locale("ar")).format(new Date(ms)); }

    // ---------- HOME ----------
    View home() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("ALRAFIK PRO • الرفيق", "رفيق المواطن الجزائري: تنقّل، اتصالات، رياضة وخدمات", o);
        LinearLayout badge = card();
        badge.setGravity(Gravity.CENTER);
        TextView bt0 = tv("✦  تطوير  ✦", 11, GRAY, true);
        bt0.setGravity(Gravity.CENTER);
        bt0.setLetterSpacing(0.3f);
        badge.addView(bt0);
        badge.addView(gradText(DEV, 24, 0xFF22D3EE, 0xFFF0ABFC, true), new LinearLayout.LayoutParams(-1, -2));
        add(col, badge);
        LinearLayout d = card();
        d.addView(tv("📅 " + new SimpleDateFormat("EEEE d MMMM yyyy", new Locale("ar", "DZ")).format(new Date()), 16, TXT, true));
        add(col, d);
        LinearLayout w = card();
        w.setOrientation(LinearLayout.HORIZONTAL);
        w.addView(tv("📍 ولايتي: " + W[sp.getInt("wilaya", 15)], 15, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        w.addView(tv("تغيير", 13, ACC, true));
        w.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { chooseWilaya(0); } });
        add(col, w);
        addPinned(col);
        String[] gTitles = {"☪️ الإسلاميات", "🧰 أدوات يومية", "📺 الإعلام والترفيه", "🤝 التضامن والسكن", "🏛️ الخدمات والإدارة", "🧾 الحياة اليومية", "👥 المرأة والمعلومات", "🛍️ التسوق", "🎓 الطلبة والمعرفة", "👤 الحساب والإعدادات"};
        String[][] gNames = {
            {"🕌 أوقات الصلاة", "☪️ الإسلاميات", "📖 القرآن الكريم", "🤲 حصن المسلم", "💬 الأحاديث", "🧎 تعليم الصلاة", "📿 المسبحة", "🌙 رمضان", "✅ متابعة الصلاة", "🧭 القبلة"},
            {"🧮 حاسبة الزكاة", "💰 ميزانيتي", "🕋 تحضير الحج والعمرة", "🛒 قائمة التسوق", "📋 الوثائق الإدارية", "⏰ مواعيد الوثائق", "📨 طلبات الوثائق", "💱 محوّل العملات", "🎓 حاسبة المعدل"},
            {"📻 الراديو", "📺 القنوات التلفزيونية", "🎬 الأفلام", "📰 الأخبار", "⚽ المباريات"},
            {"♿ ذوو الاحتياجات الخاصة", "👶 الأيتام", "🏠 سكنات عدل"},
            {"🛠️ الخدمات", "🏛️ البلدية", "🏥 المستشفيات", "📣 الشكاوي", "📂 وثائقي", "🚨 الطوارئ", "🗺️ الولايات"},
            {"🚌 النقل", "🚆 القطارات", "📱 الاتصالات", "📶 تعبئة الإنترنت", "🧾 الفواتير", "🍽️ المطاعم", "📝 الملاحظات", "📅 مواعيدي", "🌦️ الأحوال الجوية", "🔦 المصباح اليدوي", "🛒 سوق وادكنيس", "💼 التشغيل والبطالة"},
            {"👩 المرأة", "🌙 الدورة الشهرية", "🍲 الطبخ", "👗 الملابس", "👴 كبار السن"},
            {"🛍️ المتجر الإلكتروني"},
            {"📚 المكتبة", "🎓 الطلبة الجزائريون"},
            {"🔎 بحث في التطبيق", "👤 حسابي", "⚙️ الإعدادات", "☰ كل الأقسام"}};
        int[][] gTargets = {
            {9, 27, 28, 29, 30, 31, 32, 45, 51, 52},
            {46, 47, 48, 49, 50, 53, 55, 54, 10},
            {36, 37, 38, 3, 12},
            {39, 40, 41},
            {17, 19, 18, 21, 20, 6, 7},
            {1, 1, 2, 22, 24, 25, 23, 5, 56, 61, 60, 59},
            {13, 26, 14, 15, 16},
            {42},
            {57, 58},
            {43, 33, 11, 4}};
        int ci = 0;
        for (int g = 0; g < gNames.length; g++) {
            section(col, gTitles[g], ACC);
            for (int r = 0; r < gNames[g].length; r += 2) {
                LinearLayout row = new LinearLayout(this);
                for (int c = 0; c < 2; c++) {
                    int k = r + c;
                    if (k >= gNames[g].length) { row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f)); continue; }
                    TextView t = tv(gNames[g][k], 15, WHITE, true);
                    t.setGravity(Gravity.CENTER);
                    t.setBackground(shape(GCOL[g], 20));
                    t.setPadding(0, dp(18), 0, dp(18));
                    t.setOnClickListener(go(gTargets[g][k]));
                    final int pinTab = gTargets[g][k];
                    t.setOnLongClickListener(new View.OnLongClickListener() {
                        public boolean onLongClick(View v) {
                            togglePin(pinTab);
                            toast(isPinned(pinTab) ? "أُضيف إلى مفضّلتي" : "أُزيل من مفضّلتي");
                            show(0);
                            return true;
                        }
                    });
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
                    lp.setMargins(dp(6), dp(6), dp(6), dp(6));
                    row.addView(t, lp);
                }
                LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
                rl.setMargins(dp(10), 0, dp(10), 0);
                col.addView(row, rl);
            }
        }
        return o[0];
    }

    // ---------- SERVICES ----------
    View services() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🛠️ الخدمات", "روابط المؤسسات والخدمات اليومية", o);
        linkGroup(col, "🏛️ إدارة ووثائق", ACC, new String[][]{
            {"🛂 جواز السفر والبطاقة البيومترية", "https://passeport.interieur.gov.dz"},
            {"📜 الجريدة الرسمية", "https://www.joradp.dz"},
            {"💰 الضرائب (جبايتك)", "https://jibayatic.mfdgi.gov.dz"}});
        linkGroup(col, "🏥 الضمان والصحة والتقاعد", 0xFF10B981, new String[][]{
            {"🏥 الضمان الاجتماعي CNAS", "https://www.cnas.dz"},
            {"💳 الحنّاء (بطاقة الشفاء)", "https://elhanaa.cnas.dz"},
            {"🧓 صندوق التقاعد CNR", "https://www.cnr.dz"},
            {"🧾 غير الأجراء CASNOS", "https://www.casnos.dz"},
            {"🩺 وزارة الصحة", "https://www.sante.gov.dz"}});
        linkGroup(col, "💼 تشغيل ومشاريع", 0xFFF59E0B, new String[][]{
            {"💼 ANEM التشغيل", "https://www.anem.dz"},
            {"🚀 ANADE دعم المقاولاتية", "https://www.anade.dz"},
            {"🤝 ANGEM القرض المصغر", "https://www.angem.dz"},
            {"📊 CNAC التأمين عن البطالة", "https://www.cnac.dz"}});
        linkGroup(col, "💡 ماء وطاقة وبريد", CYAN, new String[][]{
            {"💡 سونلغاز", "https://www.sonelgaz.dz"},
            {"💧 الجزائرية للمياه ADE", "https://www.ade.dz"},
            {"🚰 سيال SEAAL (العاصمة)", "https://www.seaal.dz"},
            {"📮 بريد الجزائر", "https://www.poste.dz"}});
        linkGroup(col, "✈️ سفر وسكن", ACC2, new String[][]{
            {"✈️ الخطوط الجوية الجزائرية", "https://www.airalgerie.dz"},
            {"🚢 الجزائرية للملاحة", "https://www.algerieferries.dz"},
            {"🚆 السكك الحديدية SNTF", "https://www.sntf.dz"},
            {"🏠 عدل AADL", "https://www.aadl.com.dz"},
            {"🕋 الحج والعمرة (وزارة الشؤون الدينية)", "https://www.marw.gov.dz"}});
        linkGroup(col, "🎓 تعليم", 0xFF8B5CF6, new String[][]{
            {"🎓 البكالوريا ONEC", "https://bac.onec.dz"},
            {"🏫 التعليم العالي MESRS", "https://www.mesrs.dz"}});
        linkGroup(col, "🛒 تسوق وتنقل", 0xFFEC4899, new String[][]{
            {"🛒 واد كنيس Ouedkniss", "https://www.ouedkniss.com"},
            {"📦 جوميا Jumia", "https://www.jumia.dz"},
            {"🚕 ياسير Yassir", "https://yassir.com"},
            {"💊 الصيدليات المناوبة", "https://www.google.com/search?q=صيدلية+مناوبة+قريبة"},
            {"⛅ الأرصاد الجوية", "https://www.meteo.dz"}});
        add(col, tv("الروابط للتسهيل فقط؛ إذا لم يفتح رابط فقد يكون الموقع تغيّر.", 12, GRAY, false));
        return o[0];
    }

    // ---------- FOOTBALL ----------
    static final String[][] LEAGUES = {{"🇩🇿 الرابطة الأولى", "4753"}, {"🏴 البريميرليغ", "4328"}, {"🇪🇸 الليغا", "4335"},
        {"🇮🇹 السيري آ", "4332"}, {"🇩🇪 البوندسليغا", "4331"}, {"🇫🇷 ليغ 1", "4334"}, {"🏆 دوري الأبطال", "4480"}};

    View football() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("⚽ المباريات", "الدوري الجزائري والدوريات الأوروبية", o);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        LinearLayout chips = new LinearLayout(this);
        for (final String[] l : LEAGUES) {
            boolean on = l[1].equals(curLeague);
            Button b = button(l[0], on ? ACC : CARD, on ? WHITE : TXT);
            b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { curLeague = l[1]; show(12); } });
            chips.addView(b);
        }
        hs.addView(chips);
        add(col, hs);
        LinearLayout tg = new LinearLayout(this);
        Button b1 = button("📅 القادمة", fixtures ? ACC2 : CARD, fixtures ? WHITE : TXT);
        Button b2 = button("✅ النتائج", !fixtures ? ACC2 : CARD, !fixtures ? WHITE : TXT);
        b1.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { fixtures = true; show(12); } });
        b2.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { fixtures = false; show(12); } });
        tg.addView(b1, new LinearLayout.LayoutParams(0, -2, 1f));
        tg.addView(b2, new LinearLayout.LayoutParams(0, -2, 1f));
        add(col, tg);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, new LinearLayout.LayoutParams(-1, -2));
        loadMatches(list);
        linkCard(col, "🔗 مباريات اليوم والنتائج المباشرة (كووورة)", "https://www.kooora.com");
        add(col, tv("المصدر: TheSportsDB (نسخة مجانية) — قد تكون البيانات ناقصة أو متأخرة. التوقيت بحسب هاتفك.", 12, GRAY, false));
        return o[0];
    }

    void loadMatches(final LinearLayout list) {
        list.removeAllViews();
        TextView st = tv("جاري التحميل...", 14, GRAY, false);
        st.setPadding(dp(20), dp(10), dp(20), 0);
        list.addView(st);
        final boolean fx = fixtures;
        final String api = "https://www.thesportsdb.com/api/v1/json/3/" + (fx ? "eventsnextleague.php" : "eventspastleague.php") + "?id=" + curLeague;
        new Thread(new Runnable() {
            public void run() {
                final List<String[]> rows = new ArrayList<String[]>();
                String err = null;
                try {
                    JSONArray ev = new JSONObject(httpGet(api)).optJSONArray("events");
                    if (ev != null) {
                        SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
                        in.setTimeZone(TimeZone.getTimeZone("UTC"));
                        for (int i = 0; i < ev.length(); i++) {
                            JSONObject e = ev.getJSONObject(i);
                            String date = e.optString("dateEvent", "");
                            String time = e.optString("strTime", "");
                            String when = date; String key = date + time;
                            try {
                                if (time.length() >= 5) { when = fmt(in.parse(date + " " + time.substring(0, 5)).getTime()); }
                            } catch (Exception ignored) {}
                            String mid = "VS";
                            if (!e.isNull("intHomeScore") && !e.isNull("intAwayScore") && e.optString("intHomeScore").length() > 0)
                                mid = e.optString("intHomeScore") + " - " + e.optString("intAwayScore");
                            boolean hasScore = !"VS".equals(mid);
                            if (fx != hasScore) rows.add(new String[]{e.optString("strHomeTeam"), mid, e.optString("strAwayTeam"), when, key});
                        }
                    }
                } catch (Exception ex) { err = "تعذّر التحميل، تحقق من الإنترنت"; }
                Collections.sort(rows, new Comparator<String[]>() {
                    public int compare(String[] a, String[] b) { return fx ? a[4].compareTo(b[4]) : b[4].compareTo(a[4]); }
                });
                final String er = err;
                runOnUiThread(new Runnable() {
                    public void run() {
                        list.removeAllViews();
                        if (er != null || rows.isEmpty()) {
                            TextView t = tv(er != null ? er : (fx ? "لا توجد مباريات قادمة مسجّلة حالياً في هذا الدوري." : "لا توجد نتائج منتهية مسجّلة حالياً في هذا الدوري."), 14, GRAY, false);
                            t.setPadding(dp(20), dp(10), dp(20), 0);
                            list.addView(t);
                            return;
                        }
                        for (String[] r : rows) {
                            LinearLayout c = card();
                            LinearLayout line = new LinearLayout(this_());
                            TextView h = tv(r[0], 14, TXT, true); h.setGravity(Gravity.CENTER);
                            TextView m = tv(r[1], 16, ACC, true); m.setGravity(Gravity.CENTER);
                            TextView a = tv(r[2], 14, TXT, true); a.setGravity(Gravity.CENTER);
                            line.addView(h, new LinearLayout.LayoutParams(0, -2, 1f));
                            line.addView(m, new LinearLayout.LayoutParams(0, -2, 0.6f));
                            line.addView(a, new LinearLayout.LayoutParams(0, -2, 1f));
                            c.addView(line);
                            TextView tm = tv("🕒 " + r[3], 12, GRAY, false); tm.setGravity(Gravity.CENTER);
                            c.addView(tm);
                            add(list, c);
                        }
                    }
                });
            }
        }).start();
    }

    Context this_() { return this; }

    // ---------- WOMEN ----------
    View women() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("👩 المرأة الجزائرية", "صحة، دعم، مشاريع وحياة يومية", o);
        section(col, "🆘 دعم وحماية", ACC2);
        LinearLayout c1 = card();
        c1.setOrientation(LinearLayout.HORIZONTAL);
        c1.addView(tv("الخط الأخضر للتبليغ عن العنف ضد المرأة", 14, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        c1.addView(tv("1026", 20, ACC2, true));
        c1.setOnClickListener(call("1026"));
        add(col, c1);
        LinearLayout c2 = card();
        c2.setOrientation(LinearLayout.HORIZONTAL);
        c2.addView(tv("الخط الأخضر لحماية الطفولة", 14, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        c2.addView(tv("1111", 20, ACC2, true));
        c2.setOnClickListener(call("1111"));
        add(col, c2);
        add(col, tv("في الخطر الفوري: الشرطة 17 أو الدرك 1055. وزارة التضامن أطلقت أيضاً منصة «حمايتي».", 12, GRAY, false));

        section(col, "🤰 حاسبة موعد الولادة", ACC);
        final TextView res = tv("", 15, CYAN, true);
        Button lmp = button("📆 اختاري تاريخ أول يوم من آخر دورة", ACC, WHITE);
        lmp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final Calendar n = Calendar.getInstance();
                new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker p, int y, int m, int d) {
                        Calendar l = Calendar.getInstance(); l.set(y, m, d, 12, 0, 0);
                        long days = (System.currentTimeMillis() - l.getTimeInMillis()) / 86400000L;
                        Calendar due = (Calendar) l.clone(); due.add(Calendar.DAY_OF_YEAR, 280);
                        res.setText("📅 الموعد التقريبي: " + new SimpleDateFormat("d MMMM yyyy", new Locale("ar")).format(due.getTime())
                            + (days >= 0 ? "\n🤱 عمر الحمل الحالي: " + (days / 7) + " أسبوع و " + (days % 7) + " يوم" : ""));
                    }
                }, n.get(Calendar.YEAR), n.get(Calendar.MONTH), n.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        add(col, lmp);
        add(col, res);
        add(col, tv("تقدير عام فقط؛ تابعي حملك مع الطبيبة أو القابلة.", 12, GRAY, false));

        linkGroup(col, "💼 مشاريع ودعم", 0xFFF59E0B, new String[][]{
            {"🤝 ANGEM القرض المصغر (أنشطة منزلية)", "https://www.angem.dz"},
            {"🚀 ANADE دعم المقاولاتية", "https://www.anade.dz"},
            {"💼 ANEM التشغيل", "https://www.anem.dz"}});

        section(col, "🌸 اكتشفي أيضاً", ACC2);
        String[] n = {"🌙 حاسبة الدورة الشهرية ومتابعتها", "🍲 وصفات جزائرية", "👗 الملابس والأزياء التقليدية"};
        int[] t = {26, 14, 15};
        for (int i = 0; i < n.length; i++) {
            LinearLayout c = card();
            c.addView(tv(n[i], 16, TXT, true));
            c.setOnClickListener(go(t[i]));
            add(col, c);
        }
        section(col, "💡 نصائح عامة", CYAN);
        String[] tips = {"افحصي نفسك دورياً عند الطبيبة، والكشف المبكر ينقذ الأرواح.",
            "حافظي على الحديد والكالسيوم في غذائك واشربي الماء بانتظام.",
            "المشي 30 دقيقة يومياً يفيد الجسم والمزاج.",
            "خذي وقتاً للراحة النفسية، وتحدثي مع من تثقين بهم عند الضغط.",
            "هذه معلومات عامة وليست بديلاً عن استشارة الطبيبة."};
        for (String s : tips) {
            LinearLayout c = card();
            c.addView(tv("• " + s, 14, TXT, false));
            add(col, c);
        }
        return o[0];
    }

    // ---------- COOKING ----------
    static final String[][] RECIPES = {
        {"🥣 شوربة فريك",
         "• 300غ لحم غنم مقطع\n• كوب فريك\n• نصف كوب حمص منقوع\n• بصلة وطماطم مهروسة وملعقة معجون طماطم\n• كرفس ومعدنوس وكزبر\n• زيت، ملح، فلفل أسود، قرفة، قليل من الفلفل الحار",
         "1) حمّري اللحم والبصل بالزيت والتوابل.\n2) أضيفي الطماطم والمعجون والحمص وماء ساخن واتركيها على نار هادئة 45 دقيقة.\n3) أضيفي الفريك المغسول والأعشاب المفرومة وزيدي ماء حسب الرغبة.\n4) اطبخيها 20 دقيقة حتى ينضج الفريك. تُقدّم مع الليمون."},
        {"🍛 الكسكسي بالخضر واللحم",
         "• 500غ كسكسي متوسط\n• 400غ لحم أو دجاج\n• جزر، لفت، كوسة، بطاطس، قرع، حمص\n• بصل وطماطم ومعجون طماطم\n• زيت وسمن، ملح، فلفل أسود، رأس الحانوت أو الكمون",
         "1) رشّي الكسكسي بماء مملح وفتّليه بالزيت ثم بخّريه في الكسكاس مرتين.\n2) حمّري اللحم والبصل في القدر السفلي بالتوابل ثم أضيفي الطماطم والحمص والماء.\n3) أضيفي الخضر الصلبة أولاً ثم الليّنة في آخر الطبخ.\n4) قدّمي الكسكسي مع المرق والخضر واللحم فوقه."},
        {"🍜 الرشتة",
         "• 500غ رشتة (عجين رقيق)\n• دجاج، لفت، حمص\n• بصل، ثوم\n• سمن وزبدة\n• ملح، فلفل أسود، قرفة، كمون\n• مرق دجاج",
         "1) اسلقي الدجاج مع البصل والحمص والتوابل والقليل من القرفة.\n2) أضيفي اللفت واتركيه ينضج.\n3) بخّري الرشتة بالبخار وانفشيها بالزبدة.\n4) قدّميها مع المرق والدجاج فوقها."},
        {"🫒 طاجين الزيتون",
         "• 500غ دجاج أو لحم\n• 300غ زيتون أخضر مسلوق\n• بصلة وثوم\n• ملعقة صغيرة زعفران أو كركم\n• زيت، ملح، فلفل، قليل من الخل أو عصير الليمون",
         "1) حمّري اللحم مع البصل والتوابل.\n2) أضيفي الماء واتركيه ينضج حتى يصير المرق قليلاً.\n3) أضيفي الزيتون واتركيه 15 دقيقة.\n4) أضيفي الليمون في الآخر."},
        {"🥟 بوراك بالجبن",
         "• ورق بوراك (ديول)\n• جبن مبشور وقليل من الجبن الطري\n• بيضة ومعدنوس\n• ملح وفلفل\n• زيت للقلي",
         "1) اخلطي الجبن مع البيضة والمعدنوس والتوابل.\n2) ضعي الحشو على ورقة وطويها على شكل مثلث أو سيجار.\n3) اقليها في زيت ساخن حتى تحمر.\n4) صفّيها على ورق ماص وقدّميها ساخنة."},
        {"🫓 محاجب",
         "• 500غ سميد رفيع\n• ملح وماء\n• حشو: طماطم، بصل، فلفل أخضر، ثوم، زيت وقليل من الفلفل الحار",
         "1) اعجني السميد بالماء والملح عجينة طرية واتركيها ترتاح.\n2) حضّري الحشو بتحمير البصل والفلفل ثم الطماطم حتى تتجانس.\n3) افرديها رقيقة وضعي الحشو واطوي كالمربع.\n4) اطهيها على صاج ساخن من الجهتين."},
        {"🍞 خبز الدار",
         "• 500غ سميد وقليل من الطحين\n• ملعقة خميرة جافة\n• ملح وقليل من السكر\n• ماء دافئ وملعقة زيت",
         "1) اعجني المكونات 10 دقائق حتى تلين العجينة.\n2) اتركيها تختمر ساعة.\n3) شكّليها أقراصاً واتركيها ترتاح 20 دقيقة.\n4) اطهيها على صاج أو في الفرن حتى تحمر."},
        {"🍰 قلب اللوز",
         "• 3 أكواب سميد\n• كوب سكر ورشة ملح\n• 200غ زبدة\n• ماء الزهر\n• قطر: كوبان سكر وكوب ماء وقليل من الليمون\n• لوز أو جوز الهند للتزيين",
         "1) افركي السميد مع الزبدة والسكر وماء الزهر حتى تتجانس.\n2) افردي العجينة في صينية وقطّعيها مربعات.\n3) اخبزيها حتى تحمر وسقيها بالقطر الدافئ.\n4) زيّنيها بالمكسرات."},
        {"🍯 مقروط",
         "• 3 أكواب سميد\n• 150غ سمن أو زبدة\n• ماء الزهر وقليل من الماء\n• حشو التمر المعجون مع القرفة\n• زيت للقلي وعسل",
         "1) افركي السميد بالسمن ثم اعجنيه قليلاً بالماء وماء الزهر.\n2) كوّني أسطوانة وافتحي وسطها وضعي التمر ثم أغلقيها.\n3) قطّعيها معيّنات واقليها في زيت ساخن.\n4) اغمسيها في العسل."},
        {"🍪 شباكية",
         "• 500غ طحين\n• 100غ سمن\n• ملعقة خميرة وماء الزهر وقليل من السمسم المحمص\n• قرفة\n• قطر عسل للتغميس",
         "1) اعجني الطحين مع السمن والبيض وماء الزهر والتوابل.\n2) افرديها رقيقة وشكّلي وردة بقطع صغيرة.\n3) اقليها في زيت ساخن حتى تحمر.\n4) اغمسيها في العسل ورشّيها بالسمسم."}};

    View cooking() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🍲 الطبخ الجزائري", "وصفات تقليدية — اضغطي على الوصفة", o);
        for (String[] r : RECIPES) infoCard(col, r[0], "🛒 المكونات:\n" + r[1] + "\n\n👩‍🍳 الطريقة:\n" + r[2] + "\n\n(الكميات تقريبية وتُعدَّل حسب الذوق)");
        linkCard(col, "🎥 المزيد من الوصفات على يوتيوب", "https://www.youtube.com/results?search_query=وصفات+جزائرية");
        return o[0];
    }

    // ---------- CLOTHING ----------
    View clothing() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("👗 الملابس والأزياء", "اللباس التقليدي الجزائري ومواقع التسوق", o);
        section(col, "🇩🇿 اللباس التقليدي", ACC2);
        String[][] items = {
            {"👘 القفطان", "لباس نسائي فاخر للأعراس والمناسبات، يتميز بالتطريز والمجبود."},
            {"👗 الكاراكو الجزائري", "من أشهر لباس العاصمة، جاكيت مطرز مع سروال، ويُلبس في الأعراس."},
            {"🧕 الملحفة", "لباس تقليدي في الشرق الجزائري (قسنطينة، عنابة وسطيف...) بألوان زاهية."},
            {"🏔️ الجبة القبائلية", "لباس منطقة القبائل بألوانه المميزة وزخارفه الأمازيغية."},
            {"🌹 الشدة التلمسانية", "لباس العروس في تلمسان، فاخر بالأقمشة والحلي."},
            {"🌟 البلوزة الوهرانية", "لباس وهراني نسائي تقليدي بتطريز يدوي."},
            {"🧥 القندورة", "لباس رجالي ونسائي يُلبس في الأعياد والمناسبات الدينية."},
            {"🧣 البرنوس والقشابية", "لباس رجالي شتوي يرمز للأصالة والوقار."}};
        for (String[] it : items) {
            LinearLayout c = card();
            c.addView(tv(it[0], 16, TXT, true));
            c.addView(tv(it[1], 13, GRAY, false));
            add(col, c);
        }
        linkGroup(col, "🛍️ تسوق", ACC, new String[][]{
            {"🛒 واد كنيس (أزياء ومستعمل)", "https://www.ouedkniss.com"},
            {"📦 جوميا", "https://www.jumia.dz"},
            {"🔍 ملابس نسائية جزائرية", "https://www.google.com/search?q=ملابس+نسائية+الجزائر"},
            {"🔍 قندورة وبرنوس رجالي", "https://www.google.com/search?q=قندورة+رجالية+جزائرية"}});
        section(col, "💡 نصائح", CYAN);
        String[] tips = {"اختاري القماش حسب الموسم: قطن وكتان للصيف، صوف وقطيفة للشتاء.",
            "في المناسبات الرسمية يفضَّل اللباس التقليدي مع إكسسوارات بسيطة.",
            "قيسي قبل الشراء عبر الإنترنت وتأكدي من سياسة الاستبدال."};
        for (String s : tips) {
            LinearLayout c = card();
            c.addView(tv("• " + s, 14, TXT, false));
            add(col, c);
        }
        return o[0];
    }

    // ---------- SENIORS ----------
    View seniors() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("👴 كبار السن", "خدمات مبسّطة وخط كبير (فعّل الوضع من الإعدادات)", o);
        LinearLayout em = card();
        em.setBackground(shape(0xFFEF4444, 20));
        TextView e = tv("🚑 اتصال بالإسعاف 115", 22, WHITE, true);
        e.setGravity(Gravity.CENTER);
        em.addView(e);
        em.setOnClickListener(call("115"));
        add(col, em);

        section(col, "👨‍👩‍👧 أرقام عائلتي", ACC);
        final EditText name = edit("الاسم (مثال: ابني)");
        final EditText num = edit("الرقم");
        num.setInputType(InputType.TYPE_CLASS_PHONE);
        add(col, name); add(col, num);
        Button addB = button("➕ حفظ الرقم", ACC, WHITE);
        addB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String n = name.getText().toString().trim(), m = num.getText().toString().trim();
                if (n.isEmpty() || m.isEmpty()) { toast("اكتب الاسم والرقم"); return; }
                String old = sp.getString("family", "");
                sp.edit().putString("family", (old.isEmpty() ? "" : old + "\u0001") + n + "\u0002" + m).apply();
                show(16);
            }
        });
        add(col, addB);
        String raw = sp.getString("family", "");
        if (!raw.isEmpty()) {
            final String[] arr = raw.split("\u0001");
            for (int i = 0; i < arr.length; i++) {
                final int idx = i;
                String[] p = arr[i].split("\u0002");
                final String phone = p.length > 1 ? p[1] : "";
                LinearLayout c = card();
                c.setOrientation(LinearLayout.HORIZONTAL);
                c.setGravity(Gravity.CENTER_VERTICAL);
                c.addView(tv("📞 " + p[0] + "  " + phone, 18, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
                TextView del = tv("🗑", 18, 0xFFFF6B6B, true);
                del.setPadding(dp(14), 0, 0, 0);
                del.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        StringBuilder sb = new StringBuilder();
                        for (int k = 0; k < arr.length; k++) if (k != idx) { if (sb.length() > 0) sb.append("\u0001"); sb.append(arr[k]); }
                        sp.edit().putString("family", sb.toString()).apply();
                        show(16);
                    }
                });
                c.addView(del);
                c.setOnClickListener(call(phone));
                add(col, c);
            }
        }

        section(col, "💊 تذكير الدواء", ACC2);
        final EditText med = edit("اسم الدواء");
        add(col, med);
        Button alarm = button("⏰ اضبط منبه الدواء", ACC2, WHITE);
        alarm.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final String m = med.getText().toString().trim();
                Calendar n = Calendar.getInstance();
                new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    public void onTimeSet(TimePicker tp, int h, int mi) {
                        try {
                            startActivity(new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h)
                                .putExtra(AlarmClock.EXTRA_MINUTES, mi).putExtra(AlarmClock.EXTRA_MESSAGE, "💊 وقت الدواء " + m));
                        } catch (Exception ex) { toast("تعذّر فتح تطبيق المنبه"); }
                    }
                }, n.get(Calendar.HOUR_OF_DAY), n.get(Calendar.MINUTE), true).show();
            }
        });
        add(col, alarm);

        linkGroup(col, "🏛️ خدمات", 0xFF10B981, new String[][]{
            {"🧓 صندوق التقاعد CNR", "https://www.cnr.dz"},
            {"🏥 الضمان الاجتماعي CNAS", "https://www.cnas.dz"},
            {"🩺 وزارة الصحة", "https://www.sante.gov.dz"},
            {"💊 الصيدليات المناوبة", "https://www.google.com/search?q=صيدلية+مناوبة+قريبة"}});
        section(col, "💡 نصائح صحية", CYAN);
        String[] tips = {"اشرب الماء بانتظام حتى لو لم تشعر بالعطش.",
            "المشي الخفيف يومياً مفيد إذا سمح به طبيبك.",
            "تجنّب السقوط: إضاءة جيدة، حذاء مريح غير زلق، وإزالة السجاد المنزلق.",
            "لا توقف دواءً ولا تغيّر جرعته دون استشارة الطبيب.",
            "افحص الضغط والسكر والنظر والسمع بانتظام.",
            "ابقَ على تواصل مع عائلتك وأصدقائك.",
            "هذه نصائح عامة وليست بديلاً عن الطبيب."};
        for (String s : tips) {
            LinearLayout c = card();
            c.addView(tv("• " + s, 15, TXT, false));
            add(col, c);
        }
        return o[0];
    }

    // ---------- PRAYER ----------
    static final String[] KEYS = {"Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"};
    static final String[] KEYS_AR = {"🌙 الفجر", "🌅 الشروق", "☀️ الظهر", "🌤 العصر", "🌇 المغرب", "🌌 العشاء"};

    View prayer() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🕌 أوقات الصلاة", "حسب طريقة وزارة الشؤون الدينية والأوقاف", o);
        final int w = sp.getInt("wilaya", 15);
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.addView(tv("📍 " + W[w], 18, TXT, true), new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(tv("تغيير الولاية", 13, ACC, true));
        c.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { chooseWilaya(9); } });
        add(col, c);
        final TextView hijri = tv("", 14, CYAN, true);
        hijri.setPadding(dp(20), dp(4), dp(20), dp(4));
        col.addView(hijri);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, new LinearLayout.LayoutParams(-1, -2));
        TextView st = tv("جاري التحميل...", 14, GRAY, false);
        st.setPadding(dp(20), dp(10), dp(20), 0);
        list.addView(st);
        final String api = "https://api.aladhan.com/v1/timingsByCity?city=" + Uri.encode(EN[w]) + "&country=Algeria&method=19";
        new Thread(new Runnable() {
            public void run() {
                String[] times = null; String hj = "";
                try {
                    JSONObject data = new JSONObject(httpGet(api)).getJSONObject("data");
                    JSONObject tm = data.getJSONObject("timings");
                    times = new String[6];
                    for (int i = 0; i < 6; i++) times[i] = tm.getString(KEYS[i]).substring(0, 5);
                    AlarmReceiver.savePrayers(MainActivity.this, times);
                    try {
                        JSONObject mt = data.getJSONObject("meta");
                        sp.edit().putString("lat", String.valueOf(mt.getDouble("latitude")))
                            .putString("lng", String.valueOf(mt.getDouble("longitude"))).apply();
                    } catch (Exception ignored) {}
                    try {
                        JSONObject h = data.getJSONObject("date").getJSONObject("hijri");
                        hj = "📆 " + h.getString("day") + " " + h.getJSONObject("month").getString("ar") + " " + h.getString("year") + " هـ";
                    } catch (Exception ignored) {}
                } catch (Exception e) { times = null; }
                final String[] res = times; final String hjf = hj;
                runOnUiThread(new Runnable() {
                    public void run() {
                        list.removeAllViews();
                        hijri.setText(hjf);
                        if (res == null) {
                            TextView t = tv("تعذّر التحميل، تحقق من الإنترنت أو غيّر الولاية", 14, GRAY, false);
                            t.setPadding(dp(20), dp(10), dp(20), 0);
                            list.addView(t);
                            return;
                        }
                        Calendar cal = Calendar.getInstance();
                        int now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE);
                        int next = 0;
                        for (int i = 0; i < 6; i++) {
                            if (i == 1) continue;
                            int m = Integer.parseInt(res[i].substring(0, 2)) * 60 + Integer.parseInt(res[i].substring(3, 5));
                            if (m > now) { next = i; break; }
                        }
                        for (int i = 0; i < 6; i++) {
                            LinearLayout r = card();
                            r.setOrientation(LinearLayout.HORIZONTAL);
                            boolean n = i == next;
                            if (n) r.setBackground(shape(ACC, 18));
                            r.addView(tv(KEYS_AR[i] + (n ? "   ◀ التالية" : ""), 17, n ? WHITE : TXT, n), new LinearLayout.LayoutParams(0, -2, 1f));
                            r.addView(tv(res[i], 20, n ? WHITE : ACC, true));
                            add(list, r);
                        }
                    }
                });
            }
        }).start();
        Button qb = button("🧭 اتجاه القبلة", ACC, WHITE);
        qb.setOnClickListener(go(52));
        add(col, qb);
        Button mb = button("🕌 مساجد قريبة في ولايتي", 0xFF16A34A, WHITE);
        mb.setOnClickListener(url(mapsUrl("مسجد " + curW())));
        add(col, mb);
        add(col, tv("الأوقات للاسترشاد؛ اعتمد توقيت المسجد في حال الاختلاف.", 12, GRAY, false));
        return o[0];
    }

    // ---------- TRANSPORT ----------
    static final String[][] LINES = {
        {"مترو الجزائر", "الحي البدر ↔ عين النعجة", "05:00 – 22:30", "كل 5–10 د", "الجزائر"},
        {"ترامواي الجزائر", "الشهداء ↔ درقانة", "05:30 – 22:30", "كل 8–12 د", "الجزائر"},
        {"ETUSA حافلات", "خطوط العاصمة (حسب الخط)", "05:30 – 20:00", "حسب الخط", "الجزائر"},
        {"ترامواي وهران", "سيدي معروف ↔ الصديقية", "05:30 – 22:00", "كل 10 د", "وهران"},
        {"ترامواي قسنطينة", "بن عبد المالك رمضان ↔ زواغي", "06:00 – 21:30", "كل 10–15 د", "قسنطينة"},
        {"ترامواي سطيف", "المحطة ↔ الجامعة", "06:00 – 21:00", "كل 10–15 د", "سطيف"},
        {"قطار الضاحية", "الجزائر ↔ العفرون", "حسب جدول SNTF", "—", "قطار"},
        {"قطار الضاحية", "الجزائر ↔ الثنية / تيزي وزو", "حسب جدول SNTF", "—", "قطار"},
        {"قطار رئيسي", "الجزائر ↔ وهران", "حسب جدول SNTF", "—", "قطار"},
        {"قطار رئيسي", "الجزائر ↔ قسنطينة", "حسب جدول SNTF", "—", "قطار"},
        {"قطار رئيسي", "الجزائر ↔ عنابة", "حسب جدول SNTF", "—", "قطار"},
        {"قطار رئيسي", "الجزائر ↔ سطيف", "حسب جدول SNTF", "—", "قطار"},
        {"قطار رئيسي", "وهران ↔ تلمسان", "حسب جدول SNTF", "—", "قطار"}};

    View transport() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("النقل والقطارات", "حافلات، ترامواي، مترو وقطارات — الأوقات تقريبية", o);
        LinearLayout t = card();
        t.addView(tv("🎫 حجز تذاكر القطار والجداول الرسمية", 16, CYAN, true));
        t.addView(tv("الموقع الرسمي للشركة الوطنية للنقل بالسكك الحديدية SNTF", 12, GRAY, false));
        t.setOnClickListener(url("https://www.sntf.dz"));
        add(col, t);
        final EditText search = edit("🔍 ابحث: مدينة، خط أو قطار");
        add(col, search);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, new LinearLayout.LayoutParams(-1, -2));
        fill(list, "");
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { fill(list, e.toString().trim()); }
        });
        Button map = button("📍 أقرب محطة حافلات على الخريطة", ACC2, WHITE);
        map.setOnClickListener(url("https://www.google.com/maps/search/محطة+حافلات"));
        add(col, map);
        Button map2 = button("🚉 أقرب محطة قطار على الخريطة", ACC, WHITE);
        map2.setOnClickListener(url("https://www.google.com/maps/search/gare+ferroviaire"));
        add(col, map2);
        Button taxi = button("🚕 ياسير Yassir", CARD, ACC);
        taxi.setOnClickListener(url("https://yassir.com"));
        add(col, taxi);
        return o[0];
    }

    void fill(LinearLayout list, String q) {
        list.removeAllViews();
        for (String[] l : LINES) {
            if (!q.isEmpty() && !(l[0] + l[1] + l[4]).contains(q)) continue;
            LinearLayout c = card();
            c.addView(tv(l[0], 17, ACC, true));
            c.addView(tv(l[1], 14, TXT, false));
            c.addView(tv("الأوقات: " + l[2] + "  •  التردد: " + l[3], 12, GRAY, false));
            c.addView(tv("النوع/المدينة: " + l[4], 12, GRAY, false));
            add(list, c);
        }
    }

    // ---------- TELECOM ----------
    void codeRow(LinearLayout col, String label, String code, int color) {
        LinearLayout c = card();
        c.setOrientation(LinearLayout.HORIZONTAL);
        c.setGravity(Gravity.CENTER_VERTICAL);
        c.addView(tv(label, 14, TXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
        c.addView(tv(code, 18, color, true));
        c.setOnClickListener(call(code));
        add(col, c);
    }

    View telecom() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("الاتصالات", "أكواد جازي، موبيليس، أوريدو واتصالات الجزائر", o);
        add(col, tv("اضغط على الكود ليظهر في الهاتف ثم اضغط اتصال. الأكواد قد تتغير حسب العرض ونوع الشريحة، ويمكنك إضافة أكوادك الخاصة بالأسفل.", 12, GRAY, false));

        section(col, "⭐ أكوادي", CYAN);
        final EditText lab = edit("اسم الكود (مثال: رصيدي)");
        final EditText code = edit("الكود (مثال: *710#)");
        add(col, lab); add(col, code);
        LinearLayout acts = new LinearLayout(this);
        Button dialB = button("📞 اتصل", ACC, WHITE);
        dialB.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { String c = code.getText().toString().trim(); if (!c.isEmpty()) dial(c); } });
        Button saveB = button("💾 حفظ", ACC2, WHITE);
        saveB.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String l = lab.getText().toString().trim(), c = code.getText().toString().trim();
                if (l.isEmpty() || c.isEmpty()) { toast("اكتب الاسم والكود"); return; }
                String old = sp.getString("codes", "");
                sp.edit().putString("codes", (old.isEmpty() ? "" : old + "\u0001") + l + "\u0002" + c).apply();
                show(2);
            }
        });
        acts.addView(dialB, new LinearLayout.LayoutParams(0, -2, 1f));
        acts.addView(saveB, new LinearLayout.LayoutParams(0, -2, 1f));
        add(col, acts);
        String raw = sp.getString("codes", "");
        if (!raw.isEmpty()) {
            final String[] arr = raw.split("\u0001");
            for (int i = 0; i < arr.length; i++) {
                final int idx = i;
                String[] p = arr[i].split("\u0002");
                LinearLayout c = card();
                c.setOrientation(LinearLayout.HORIZONTAL);
                c.setGravity(Gravity.CENTER_VERTICAL);
                c.addView(tv(p[0], 14, TXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
                c.addView(tv(p.length > 1 ? p[1] : "", 18, CYAN, true));
                TextView del = tv("🗑", 16, 0xFFFF6B6B, true);
                del.setPadding(dp(14), 0, 0, 0);
                del.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        StringBuilder sb = new StringBuilder();
                        for (int k = 0; k < arr.length; k++) if (k != idx) { if (sb.length() > 0) sb.append("\u0001"); sb.append(arr[k]); }
                        sp.edit().putString("codes", sb.toString()).apply();
                        show(2);
                    }
                });
                c.addView(del);
                if (p.length > 1) c.setOnClickListener(call(p[1]));
                add(col, c);
            }
        }

        int red = 0xFFFF4B4B;
        section(col, "🔴 Djezzy جازي", red);
        codeRow(col, "معرفة الرصيد والاستهلاك", "*710#", red);
        codeRow(col, "العروض", "*720#", red);
        codeRow(col, "باقات الإنترنت", "*707#", red);
        codeRow(col, "الاستعلام عن الباقة أو الفاتورة", "*787#", red);
        codeRow(col, "خدمة الزبائن", "777", red);
        linkCard(col, "🌐 موقع جازي", "https://www.djezzy.dz");

        int gr = 0xFF10B981;
        section(col, "🟢 Mobilis موبيليس", gr);
        codeRow(col, "الرصيد / رصيد الإنترنت", "*222#", gr);
        codeRow(col, "العروض والباقات والخدمات", "*600#", gr);
        codeRow(col, "قائمة الأرقام المفضلة", "*601#", gr);
        codeRow(col, "معرفة رقم الشريحة", "*101#", gr);
        codeRow(col, "الاشتراك عند فقدان التغطية", "*644#", gr);
        final EditText cm = edit("رقم المراسل لإرسال «كلمني»");
        cm.setInputType(InputType.TYPE_CLASS_PHONE);
        add(col, cm);
        Button cmB = button("📲 أرسل «كلمني» (*606*الرقم#)", gr, WHITE);
        cmB.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { String n = cm.getText().toString().trim(); if (!n.isEmpty()) dial("*606*" + n + "#"); } });
        add(col, cmB);
        linkCard(col, "🌐 موقع موبيليس", "https://www.mobilis.dz");

        int oo = 0xFFFF6B6B;
        section(col, "🔴 Ooredoo أوريدو", oo);
        codeRow(col, "الرصيد ومتابعة الاستهلاك", "*200#", oo);
        codeRow(col, "شراء وتجديد الباقات", "*151#", oo);
        codeRow(col, "قائمة العروض والخدمات", "*500#", oo);
        codeRow(col, "خدمة السلفة", "*505#", oo);
        codeRow(col, "برنامج نقاط Noudjoum", "*511#", oo);
        codeRow(col, "بوابة خدمات Ooredoo", "*113#", oo);
        codeRow(col, "باقات المكالمات الدولية", "*310#", oo);
        codeRow(col, "خدمة الزبائن", "333", oo);
        linkCard(col, "🌐 موقع أوريدو", "https://www.ooredoo.dz");

        int bl = 0xFF3B82F6;
        section(col, "🔵 اتصالات الجزائر Algérie Télécom", bl);
        codeRow(col, "خدمة الزبائن", "12", bl);
        codeRow(col, "تسبيق ساعات الإنترنت (قد يكون تغيّر)", "1500", bl);
        linkCard(col, "🌐 الموقع الرسمي (الفواتير، التعبئة، الأعطال)", "https://www.algerietelecom.dz");

        section(col, "⚙️ أكواد عامة لكل الشبكات", ACC);
        codeRow(col, "عرض رقم IMEI للهاتف", "*#06#", ACC);
        codeRow(col, "التحقق من تحويل المكالمات", "*#21#", ACC);
        codeRow(col, "إلغاء جميع تحويلات المكالمات", "##002#", ACC);
        add(col, tv("لتحويل المكالمات اكتب *21*الرقم# في خانة «اكتب الكود» بالأعلى.", 12, GRAY, false));
        return o[0];
    }

    // ---------- NEWS ----------
    View news() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📰 آخر الأخبار", "من المصادر الجزائرية", o);
        final String[][] feeds = {{"الشروق", "https://www.echoroukonline.com/feed"}, {"الخبر", "https://www.elkhabar.com/feed"}, {"النهار", "https://www.ennaharonline.com/feed/"}};
        LinearLayout chips = new LinearLayout(this);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (final String[] f : feeds) {
            Button bt = button(f[0], CARD, ACC);
            bt.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { curFeed = f[1]; load(list, curFeed); } });
            chips.addView(bt, new LinearLayout.LayoutParams(0, -2, 1f));
        }
        Button rf = button("🔄", ACC, WHITE);
        rf.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { load(list, curFeed); } });
        chips.addView(rf, new LinearLayout.LayoutParams(0, -2, 0.6f));
        add(col, chips);
        col.addView(list, new LinearLayout.LayoutParams(-1, -2));
        load(list, curFeed);
        return o[0];
    }

    void load(final LinearLayout list, final String url) {
        list.removeAllViews();
        TextView st = tv("جاري التحميل...", 14, GRAY, false);
        st.setPadding(dp(16), dp(10), dp(16), 0);
        list.addView(st);
        new Thread(new Runnable() {
            public void run() {
                List<String[]> items = new ArrayList<String[]>();
                String err = null;
                try { items = rss(url); } catch (Exception e) { err = "تعذّر التحميل، تحقق من الإنترنت"; }
                final List<String[]> res = items; final String er = err;
                runOnUiThread(new Runnable() {
                    public void run() {
                        list.removeAllViews();
                        if (er != null || res.isEmpty()) {
                            TextView t = tv(er != null ? er : "لا توجد أخبار حالياً", 14, GRAY, false);
                            t.setPadding(dp(16), dp(10), dp(16), 0);
                            list.addView(t);
                            return;
                        }
                        for (final String[] n : res) {
                            LinearLayout c = card();
                            c.addView(tv(n[0], 15, TXT, false));
                            c.setOnClickListener(url(n[1]));
                            add(list, c);
                        }
                    }
                });
            }
        }).start();
    }

    List<String[]> rss(String u) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(u).openConnection();
        con.setConnectTimeout(8000); con.setReadTimeout(8000);
        con.setRequestProperty("User-Agent", "Mozilla/5.0");
        List<String[]> out = new ArrayList<String[]>();
        XmlPullParser p = Xml.newPullParser();
        p.setInput(con.getInputStream(), null);
        boolean in = false; String t = "", l = "", tag = "";
        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT && out.size() < 25) {
            if (ev == XmlPullParser.START_TAG) {
                tag = p.getName();
                if (tag.equals("item")) { in = true; t = ""; l = ""; }
            } else if (ev == XmlPullParser.TEXT && in) {
                if (tag.equals("title")) t += p.getText(); else if (tag.equals("link")) l += p.getText();
            } else if (ev == XmlPullParser.END_TAG) {
                if (p.getName().equals("item")) { in = false; if (t.trim().length() > 0) out.add(new String[]{t.trim(), l.trim()}); }
                tag = "";
            }
            ev = p.next();
        }
        return out;
    }

    // ---------- MORE ----------
    View more() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("المزيد", "كل ما يحتاجه المواطن في مكان واحد", o);
        String[] n = {"🌦️ الأحوال الجوية", "📚 المكتبة", "🎓 الطلبة", "🔦 المصباح اليدوي", "🛒 سوق وادكنيس", "💼 التشغيل والبطالة", "☪️ الإسلاميات", "📖 القرآن الكريم", "🤲 حصن المسلم", "💬 الأحاديث", "🧎 تعليم الصلاة", "📿 المسبحة",
            "📻 الراديو", "📺 القنوات التلفزيونية", "🎬 الأفلام", "♿ ذوو الاحتياجات الخاصة", "👶 الأيتام", "🏠 سكنات عدل", "🛍️ المتجر الإلكتروني",
            "📰 الأخبار", "🕌 أوقات الصلاة", "👩 المرأة الجزائرية", "🌙 الدورة الشهرية", "🍲 الطبخ الجزائري", "👗 الملابس والأزياء",
            "👴 كبار السن", "🛠️ الخدمات", "🏛️ خدمات البلدية", "🏥 المستشفيات", "📂 وثائقي (من الهاتف)", "📣 الشكاوي", "📶 تعبئة الإنترنت",
            "📝 سجل الملاحظات", "🧾 الفواتير", "🍽️ المطاعم", "📅 مواعيدي", "🎓 حاسبة المعدل", "🚨 أرقام الطوارئ", "🗺️ الولايات",
            "🧭 القبلة", "✅ متابعة الصلاة", "🌙 رمضان", "🧮 حاسبة الزكاة", "💰 ميزانيتي", "🕋 تحضير الحج والعمرة", "🛒 قائمة التسوق", "📋 الوثائق الإدارية", "⏰ مواعيد الوثائق", "📨 طلبات الوثائق", "💱 محوّل العملات", "🔎 بحث في التطبيق", "👤 حسابي", "⚙️ الإعدادات", "ℹ️ حول التطبيق والمطور"};
        int[] t = {56, 57, 58, 61, 60, 59, 27, 28, 29, 30, 31, 32, 36, 37, 38, 39, 40, 41, 42, 3, 9, 13, 26, 14, 15, 16, 17, 19, 18, 20, 21, 22, 23, 24, 25, 5, 10, 6, 7, 52, 51, 45, 46, 47, 48, 49, 50, 53, 55, 54, 43, 33, 11, 8};
        for (int i = 0; i < n.length; i++) {
            LinearLayout c = card();
            c.addView(tv(n[i], 17, TXT, true));
            c.setOnClickListener(go(t[i]));
            add(col, c);
        }
        return o[0];
    }

    // ---------- APPOINTMENTS ----------
    void pickDateTime(final TextView target) {
        final Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker v, final int y, final int m, final int d) {
                new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    public void onTimeSet(TimePicker tp, int h, int mi) {
                        Calendar r = Calendar.getInstance();
                        r.set(y, m, d, h, mi, 0);
                        picked = r.getTimeInMillis();
                        target.setText("🗓 " + fmt(picked));
                    }
                }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show();
            }
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    View appts() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📅 مواعيدي", "سجّل مواعيدك وأضفها إلى تقويم هاتفك", o);
        final EditText title = edit("الموعد (مثال: طبيب، إدارة، سفر)");
        add(col, title);
        LinearLayout pc = card();
        final TextView dt = tv(picked > 0 ? "🗓 " + fmt(picked) : "🗓 اختر التاريخ والوقت", 15, CYAN, true);
        pc.addView(dt);
        pc.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pickDateTime(dt); } });
        add(col, pc);
        Button addBtn = button("➕ إضافة الموعد", ACC, WHITE);
        addBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String name = title.getText().toString().trim();
                if (name.isEmpty()) { toast("اكتب اسم الموعد"); return; }
                String old = sp.getString("appts", "");
                String item = name + "\u0002" + picked;
                sp.edit().putString("appts", old.isEmpty() ? item : old + "\u0001" + item).apply();
                picked = 0;
                show(5);
            }
        });
        add(col, addBtn);
        String raw = sp.getString("appts", "");
        if (raw.isEmpty()) { add(col, tv("لا توجد مواعيد بعد", 14, GRAY, false)); return o[0]; }
        final String[] arr = raw.split("\u0001");
        for (int i = 0; i < arr.length; i++) {
            final int idx = i;
            String[] parts = arr[i].split("\u0002");
            final String name = parts[0];
            long ms = 0;
            if (parts.length > 1) { try { ms = Long.parseLong(parts[1]); } catch (Exception e) { ms = 0; } }
            final long when = ms;
            LinearLayout c = card();
            c.addView(tv(name, 16, TXT, true));
            if (ms > 0) c.addView(tv("🗓 " + fmt(ms), 13, GRAY, false));
            LinearLayout acts = new LinearLayout(this);
            if (ms > 0) {
                TextView cal = tv("📅 إضافة للتقويم", 13, CYAN, true);
                cal.setPadding(0, dp(8), dp(20), 0);
                cal.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        try {
                            startActivity(new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                                .putExtra(CalendarContract.Events.TITLE, name)
                                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, when));
                        } catch (Exception e) { toast("لا يوجد تطبيق تقويم"); }
                    }
                });
                acts.addView(cal);
            }
            TextView del = tv("🗑 حذف", 13, 0xFFFF6B6B, true);
            del.setPadding(0, dp(8), 0, 0);
            del.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    StringBuilder sb = new StringBuilder();
                    for (int k = 0; k < arr.length; k++) if (k != idx) { if (sb.length() > 0) sb.append("\u0001"); sb.append(arr[k]); }
                    sp.edit().putString("appts", sb.toString()).apply();
                    show(5);
                }
            });
            acts.addView(del);
            c.addView(acts);
            add(col, c);
        }
        return o[0];
    }

    // ---------- GRADES ----------
    void addRow(LinearLayout rows, List<EditText[]> fields) {
        LinearLayout r = new LinearLayout(this);
        EditText m = edit("العلامة /20");
        EditText k = edit("المعامل");
        m.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        k.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        r.addView(m, new LinearLayout.LayoutParams(0, -2, 1f));
        r.addView(k, new LinearLayout.LayoutParams(0, -2, 1f));
        fields.add(new EditText[]{m, k});
        add(rows, r);
    }

    View grades() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🎓 حاسبة المعدل", "أدخل علامة ومعامل كل مادة", o);
        final LinearLayout rows = new LinearLayout(this);
        rows.setOrientation(LinearLayout.VERTICAL);
        final List<EditText[]> fields = new ArrayList<EditText[]>();
        for (int i = 0; i < 6; i++) addRow(rows, fields);
        col.addView(rows, new LinearLayout.LayoutParams(-1, -2));
        Button more = button("➕ إضافة مادة", CARD, ACC);
        more.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { addRow(rows, fields); } });
        add(col, more);
        final TextView res = tv("", 24, ACC, true);
        res.setGravity(Gravity.CENTER);
        Button calc = button("احسب المعدل", ACC, WHITE);
        calc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                double s = 0, k = 0;
                for (EditText[] f : fields) {
                    try {
                        double m = Double.parseDouble(f[0].getText().toString().replace(',', '.'));
                        double c = Double.parseDouble(f[1].getText().toString().replace(',', '.'));
                        s += m * c; k += c;
                    } catch (Exception ignored) {}
                }
                if (k == 0) { res.setText("أدخل العلامات والمعاملات"); return; }
                double avg = s / k;
                res.setText("المعدل: " + String.format(Locale.US, "%.2f", avg) + (avg >= 10 ? "  ✅" : "  ⚠️"));
            }
        });
        add(col, calc);
        add(col, res);
        return o[0];
    }

    // ---------- EMERGENCY ----------
    View emergency() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🚨 أرقام الطوارئ", "اضغط للاتصال مباشرة", o);
        String[][] n = {{"🚓 الشرطة (النجدة)", "17"}, {"🚓 الشرطة (الرقم الأخضر)", "1548"}, {"🛡️ الدرك الوطني", "1055"},
            {"🚒 الحماية المدنية", "14"}, {"🚑 الإسعاف SAMU", "115"}, {"💡 سونلغاز (أعطال)", "3303"},
            {"👩 العنف ضد المرأة", "1026"}, {"👶 حماية الطفولة", "1111"}};
        for (String[] x : n) codeRow(col, x[0], x[1], ACC);
        add(col, tv("في حالة الخطر الفوري اتصل بالرقم المناسب مباشرة.", 12, GRAY, false));
        return o[0];
    }

    // ---------- WILAYAS ----------
    static final String[] W = {"أدرار", "الشلف", "الأغواط", "أم البواقي", "باتنة", "بجاية", "بسكرة", "بشار", "البليدة", "البويرة",
        "تمنراست", "تبسة", "تلمسان", "تيارت", "تيزي وزو", "الجزائر", "الجلفة", "جيجل", "سطيف", "سعيدة", "سكيكدة", "سيدي بلعباس",
        "عنابة", "قالمة", "قسنطينة", "المدية", "مستغانم", "المسيلة", "معسكر", "ورقلة", "وهران", "البيض", "إليزي", "برج بوعريريج",
        "بومرداس", "الطارف", "تندوف", "تيسمسيلت", "الوادي", "خنشلة", "سوق أهراس", "تيبازة", "ميلة", "عين الدفلى", "النعامة",
        "عين تموشنت", "غرداية", "غليزان", "تيميمون", "برج باجي مختار", "أولاد جلال", "بني عباس", "عين صالح", "عين قزام",
        "تقرت", "جانت", "المغير", "المنيعة"};
    static final String[] EN = {"Adrar", "Chlef", "Laghouat", "Oum El Bouaghi", "Batna", "Bejaia", "Biskra", "Bechar", "Blida", "Bouira",
        "Tamanrasset", "Tebessa", "Tlemcen", "Tiaret", "Tizi Ouzou", "Algiers", "Djelfa", "Jijel", "Setif", "Saida", "Skikda", "Sidi Bel Abbes",
        "Annaba", "Guelma", "Constantine", "Medea", "Mostaganem", "M'Sila", "Mascara", "Ouargla", "Oran", "El Bayadh", "Illizi", "Bordj Bou Arreridj",
        "Boumerdes", "El Tarf", "Tindouf", "Tissemsilt", "El Oued", "Khenchela", "Souk Ahras", "Tipaza", "Mila", "Ain Defla", "Naama",
        "Ain Temouchent", "Ghardaia", "Relizane", "Timimoun", "Bordj Badji Mokhtar", "Ouled Djellal", "Beni Abbes", "In Salah", "In Guezzam",
        "Touggourt", "Djanet", "El M'Ghair", "El Meniaa"};

    View wilayas() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🗺️ الولايات", "رقم الولاية (لوحات السيارات) — اضغط لمعرفة الطقس", o);
        final EditText search = edit("🔍 ابحث بالاسم أو الرقم");
        add(col, search);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, new LinearLayout.LayoutParams(-1, -2));
        fillW(list, "");
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { fillW(list, e.toString().trim()); }
        });
        return o[0];
    }

    void fillW(LinearLayout list, String q) {
        list.removeAllViews();
        for (int i = 0; i < W.length; i++) {
            String num = String.valueOf(i + 1);
            if (!q.isEmpty() && !W[i].contains(q) && !num.equals(q)) continue;
            LinearLayout c = card();
            c.setOrientation(LinearLayout.HORIZONTAL);
            c.addView(tv(W[i], 16, TXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
            c.addView(tv(num, 18, ACC, true));
            c.setOnClickListener(url("https://www.google.com/search?q=طقس+" + Uri.encode(W[i])));
            add(list, c);
        }
    }

    // ---------- SETTINGS ----------
    View settings() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("⚙️ الإعدادات · Paramètres", "المظهر، الخط، التنبيهات والولاية", o);
        LinearLayout t = card();
        t.addView(tv("🎨 المظهر: " + (dark ? "داكن" : "فاتح"), 16, TXT, true));
        t.addView(tv("اضغط للتبديل", 12, GRAY, false));
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sp.edit().putBoolean("dark", !dark).putInt("starttab", 11).apply();
                recreate();
            }
        });
        add(col, t);
        final boolean sen = sp.getBoolean("senior", false);
        LinearLayout s = card();
        s.addView(tv("👴 وضع كبار السن (خط كبير): " + (sen ? "مفعّل" : "متوقف"), 16, TXT, true));
        s.addView(tv("اضغط للتبديل", 12, GRAY, false));
        s.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sp.edit().putBoolean("senior", !sen).putInt("starttab", 11).apply();
                recreate();
            }
        });
        add(col, s);
        LinearLayout w = card();
        w.addView(tv("📍 ولايتي: " + W[sp.getInt("wilaya", 15)], 16, TXT, true));
        w.addView(tv("تُستعمل لأوقات الصلاة — اضغط للتغيير", 12, GRAY, false));
        w.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { chooseWilaya(11); } });
        add(col, w);
        LinearLayout ac = card();
        ac.addView(tv("👤 الحساب: " + sp.getString("acc_user", "—"), 16, TXT, true));
        ac.addView(tv("اضغط لتسجيل الخروج", 12, GRAY, false));
        ac.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sp.edit().putBoolean("loggedIn", false).apply(); show(33); }
        });
        final boolean np = sp.getBoolean("notif_prayer", true);
        LinearLayout n1 = card();
        n1.addView(tv("🔔 تنبيهات أوقات الصلاة: " + (np ? "مفعّلة" : "متوقفة"), 16, TXT, true));
        n1.addView(tv("اضغط للتبديل", 12, GRAY, false));
        n1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sp.edit().putBoolean("notif_prayer", !np).apply(); notifySetup(); show(11); }
        });
        add(col, n1);
        final boolean nb = sp.getBoolean("notif_bills", true);
        LinearLayout n2 = card();
        n2.addView(tv("🧾 تنبيهات الفواتير المستحقة: " + (nb ? "مفعّلة" : "متوقفة"), 16, TXT, true));
        n2.addView(tv("تذكير في التاسعة صباحاً يوم الاستحقاق", 12, GRAY, false));
        n2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sp.edit().putBoolean("notif_bills", !nb).apply(); AlarmReceiver.rescheduleAll(MainActivity.this); show(11); }
        });
        add(col, n2);
        final boolean nd = sp.getBoolean("notif_docs", true);
        LinearLayout n3 = card();
        n3.addView(tv("⏰ تذكير انتهاء الوثائق: " + (nd ? "مفعّل" : "متوقف"), 16, TXT, true));
        n3.addView(tv("قبل 30 يوماً من انتهاء كل وثيقة", 12, GRAY, false));
        n3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sp.edit().putBoolean("notif_docs", !nd).apply(); AlarmReceiver.rescheduleAll(MainActivity.this); show(11); }
        });
        add(col, n3);
        final boolean nw = sp.getBoolean("notif_weather", true);
        LinearLayout n4 = card();
        n4.addView(tv("🌧️ تنبيهات الأمطار: " + (nw ? "مفعّلة" : "متوقفة"), 16, TXT, true));
        n4.addView(tv("تنبيه عند احتمال مطر مرتفع خلال 6 ساعات", 12, GRAY, false));
        n4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sp.edit().putBoolean("notif_weather", !nw).apply(); AlarmReceiver.rescheduleAll(MainActivity.this); show(11); }
        });
        add(col, n4);
        final boolean ws = sp.getBoolean("welcome_sound", true);
        LinearLayout n5 = card();
        n5.addView(tv("🔔 نغمة الترحيب: " + (ws ? "مفعّلة" : "متوقفة"), 16, TXT, true));
        n5.addView(tv("تُشغَّل عند فتح التطبيق", 12, GRAY, false));
        n5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sp.edit().putBoolean("welcome_sound", !ws).apply(); show(11); }
        });
        add(col, n5);
        add(col, ac);
        return o[0];
    }

    // ---------- ABOUT ----------
    View about() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("ALRAFIK PRO • الرفيق", "الإصدار " + VERSION, o);
        LinearLayout c = card();
        c.addView(tv("تطبيق يساعد المواطن الجزائري على التنقل ومتابعة الأخبار والرياضة والخدمات اليومية من الهاتف.", 15, TXT, false));
        add(col, c);
        LinearLayout d = card();
        d.addView(tv("👨‍💻 المطور", 13, GRAY, false));
        d.addView(gradText(DEV, 30, 0xFF22D3EE, 0xFFF0ABFC, true));
        add(col, d);
        Button share = button("📤 مشاركة التطبيق", ACC2, WHITE);
        share.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, "جرّب تطبيق ALRAFIK PRO الرفيق — تطوير " + DEV);
                startActivity(Intent.createChooser(i, "مشاركة"));
            }
        });
        add(col, share);
        add(col, tv("المعلومات (الأوقات، الأكواد، الأرقام، المباريات) للمساعدة فقط وقد تتغير؛ تأكد من المصدر الرسمي.", 12, GRAY, false));
        return o[0];
    }

    // =====================================================================
    // v5 ADDITIONS
    // =====================================================================
    static final int REQ_DOC = 42;
    int curSurah = 1, curHisn = 0;
    static final String[] CATS = {"النظافة", "الإنارة العمومية", "الماء", "الكهرباء والغاز", "الطرقات", "النقل", "الإدارة والوثائق", "أخرى"};
    static final String[] BILL_TYPES = {"💧 الماء", "🔥 الغاز", "💡 الكهرباء", "🏠 الإيجار / الكراء", "📱 الهاتف والإنترنت", "🏷️ أخرى"};

    String mapsUrl(String q) { return "https://www.google.com/maps/search/" + Uri.encode(q); }
    String curW() { return W[sp.getInt("wilaya", 15)]; }
    String dayStr(long t) { return new SimpleDateFormat("d MMMM yyyy", new Locale("ar")).format(new Date(t)); }

    // ---- storage helpers (JSON lists in SharedPreferences) ----
    JSONArray loadArr(String key) {
        try { return new JSONArray(sp.getString(key, "[]")); } catch (Exception e) { return new JSONArray(); }
    }
    void saveArr(String key, JSONArray a) { sp.edit().putString(key, a.toString()).apply(); }
    JSONObject obj(String... kv) {
        JSONObject o = new JSONObject();
        try { for (int i = 0; i + 1 < kv.length; i += 2) o.put(kv[i], kv[i + 1]); } catch (Exception e) { }
        return o;
    }
    void addItem(String key, JSONObject o) { JSONArray a = loadArr(key); a.put(o); saveArr(key, a); }
    void removeAt(String key, int idx) {
        JSONArray a = loadArr(key), out = new JSONArray();
        for (int i = 0; i < a.length(); i++) if (i != idx) out.put(a.opt(i));
        saveArr(key, out);
    }
    void confirmDelete(final String key, final int idx, final int tab, String msg) {
        new AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("حذف", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) { removeAt(key, idx); show(tab); }
            })
            .setNegativeButton("إلغاء", null).show();
    }
    void toggleItem(String key, int idx, String field, int tab) {
        JSONArray a = loadArr(key);
        JSONObject o = a.optJSONObject(idx);
        if (o == null) return;
        try { o.put(field, "1".equals(o.optString(field)) ? "0" : "1"); } catch (Exception e) { }
        saveArr(key, a);
        show(tab);
    }
    void navCard(LinearLayout col, String label, final int tab) {
        LinearLayout c = card();
        c.addView(tv(label, 16, TXT, true));
        c.setOnClickListener(go(tab));
        add(col, c);
    }
    String displayName(Uri u) {
        Cursor c = null;
        try {
            c = getContentResolver().query(u, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0 && c.getString(i) != null) return c.getString(i);
            }
        } catch (Exception e) {
        } finally {
            if (c != null) c.close();
        }
        return "وثيقة";
    }

    // =====================================================================
    // 🏥 HOSPITALS
    // =====================================================================
    View hospitals() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🏥 المستشفيات", "ولايتك: " + curW(), o);
        Button b1 = button("🏥 مستشفيات قريبة في ولايتي", ACC2, WHITE);
        b1.setOnClickListener(url(mapsUrl("مستشفى " + curW())));
        add(col, b1);
        Button b2 = button("🚑 مستعجلات قريبة", ACC, WHITE);
        b2.setOnClickListener(url(mapsUrl("مستعجلات " + curW())));
        add(col, b2);
        Button b3 = button("💊 صيدلية مناوبة قريبة", 0xFF16A34A, WHITE);
        b3.setOnClickListener(url(mapsUrl("صيدلية مناوبة " + curW())));
        add(col, b3);
        section(col, "🚨 أرقام الإسعاف", ACC);
        codeRow(col, "🚑 الإسعاف SAMU", "115", ACC);
        codeRow(col, "🚒 الحماية المدنية", "14", ACC);
        section(col, "🏥 المستشفيات الجامعية الكبرى", CYAN);
        String[] chu = {"الجزائر (مصطفى باشا)", "وهران", "قسنطينة", "عنابة", "البليدة", "تلمسان", "سطيف", "باتنة", "تيزي وزو"};
        for (String c : chu) linkCard(col, "🏥 المستشفى الجامعي – " + c, mapsUrl("المستشفى الجامعي " + c));
        add(col, tv("الروابط تفتح خرائط Google لإيجاد أقرب مؤسسة. للمواعيد والمعلومات تواصل مع المؤسسة نفسها.", 12, GRAY, false));
        return o[0];
    }

    // =====================================================================
    // 🏛️ MUNICIPALITY
    // =====================================================================
    View municipality() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🏛️ خدمات البلدية", "الحالة المدنية، التعمير، النظافة والشكاوي", o);
        Button bm = button("📍 بلدية ولايتي على الخرائط", ACC, WHITE);
        bm.setOnClickListener(url(mapsUrl("بلدية " + curW())));
        add(col, bm);
        section(col, "📄 الوثائق الإدارية", ACC2);
        infoCard(col, "📜 شهادة الميلاد", "تُطلب من مصلحة الحالة المدنية في بلدية الولادة أو بلدية الإقامة حسب الإجراء المعمول به. عادةً يُحتاج إلى بطاقة التعريف الوطنية، وقد يُطلب دفع رسم بسيط.");
        infoCard(col, "🏠 شهادة الإقامة", "تُطلب من بلدية مكان السكن الحالي، وعادةً تحتاج إلى بطاقة التعريف الوطنية وعقد الكراء أو شهادة الإيواء.");
        infoCard(col, "💍 شهادة الحياة والعزوبة", "شهادة الحياة تثبت أنك على قيد الحياة، وشهادة العزوبة تثبت الحالة الاجتماعية. تُطلبان من البلدية، والمتطلبات تختلف من بلدية لأخرى.");
        section(col, "🏗️ التعمير والنشاط", ACC);
        infoCard(col, "🧱 رخصة البناء", "تُقدَّم ملفاتها لمصلحة التعمير في البلدية، ويجب الحصول عليها قبل بدء البناء. المتطلبات تختلف حسب نوع البناء، فاستفسر في البلدية.");
        infoCard(col, "🏪 رخصة المحل التجاري", "تُطلب من البلدية، وتحتاج عادةً إلى السجل التجاري وشهادة الإقامة وتصميم المحل حسب الحالة.");
        section(col, "🧹 النظافة والمرافق", CYAN);
        infoCard(col, "🗑️ رسم رفع النفايات المنزلية", "رسم يُدفع عادةً مع فاتورة الكهرباء أو عبر البلدية حسب ولايتك. عند عدم رفع النفايات قدّم شكوى.");
        navCard(col, "📣 تقديم شكوى بلدية", 21);
        section(col, "🔗 روابط رسمية", ACC);
        linkCard(col, "🏛️ وزارة الداخلية والجماعات المحلية", "https://www.interieur.gov.dz");
        add(col, tv("المعلومات عامة وقد تختلف من بلدية لأخرى؛ الوثائق المطلوبة يؤكدها مكتب البلدية.", 12, GRAY, false));
        return o[0];
    }

    // =====================================================================
    // 📂 DOCUMENTS FROM PHONE (references only, no upload)
    // =====================================================================
    void pickDocument() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/pdf", "image/*"});
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try { startActivityForResult(i, REQ_DOC); } catch (Exception e) { toast("لا يوجد تطبيق لاختيار الملفات"); }
    }
    void openDoc(String u) {
        try {
            Uri uri = Uri.parse(u);
            String mime = getContentResolver().getType(uri);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(uri, mime != null ? mime : "*/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        } catch (Exception e) { toast("تعذّر فتح الوثيقة، ربما نُقلت أو حُذفت من الهاتف"); }
    }

    View documents() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📂 وثائقي", "وثائقك من الهاتف فقط — بدون إنترنت ولا رفع", o);
        Button add = button("➕ اختيار وثيقة من الهاتف (PDF أو صورة)", ACC, WHITE);
        add.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { pickDocument(); } });
        add(col, add);
        add(col, tv("التطبيق يحفظ مرجع الملف فقط داخل الهاتف ولا يرفعه لأي خادم. إذا نقلتَ الملف أو حذفته من الهاتف لن يُفتح.", 12, GRAY, false));
        section(col, "📁 وثائقي المحفوظة", ACC2);
        JSONArray a = loadArr("docs");
        if (a.length() == 0) add(col, tv("لم تضف أي وثيقة بعد. اضغط «اختيار وثيقة» أعلاه.", 14, GRAY, false));
        for (int i = 0; i < a.length(); i++) {
            final JSONObject d = a.optJSONObject(i);
            if (d == null) continue;
            final int idx = i;
            LinearLayout c = card();
            c.addView(tv("📄 " + d.optString("name", "وثيقة"), 15, TXT, true));
            c.addView(tv(d.optString("note", ""), 12, GRAY, false));
            c.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { openDoc(d.optString("uri")); } });
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { confirmDelete("docs", idx, 20, "حذف هذه الوثيقة من القائمة؟ (الملف يبقى في هاتفك)"); return true; }
            });
            add(col, c);
        }
        if (a.length() > 0) add(col, tv("اضغط على الوثيقة للفتح • اضغط مطولاً للحذف من القائمة", 12, GRAY, false));
        return o[0];
    }

    // =====================================================================
    // 📣 COMPLAINTS
    // =====================================================================
    View complaints() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📣 الشكاوي", "سجّل شكواك، أرسلها، وتابع حالتها", o);
        section(col, "✍️ شكوى جديدة", ACC2);
        final String[] cat = {"أخرى"};
        final Button catBtn = button("📌 نوع الشكوى: أخرى", ACC, WHITE);
        catBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this).setItems(CATS, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { cat[0] = CATS[w]; catBtn.setText("📌 نوع الشكوى: " + CATS[w]); }
                }).show();
            }
        });
        add(col, catBtn);
        final EditText body = edit("اكتب شكواك بالتفصيل: المكان، المشكل، منذ متى");
        body.setSingleLine(false); body.setMinLines(4); body.setGravity(Gravity.TOP | Gravity.START);
        add(col, body);
        Button save = button("💾 حفظ الشكوى", ACC2, WHITE);
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String t = body.getText().toString().trim();
                if (t.isEmpty()) { toast("اكتب نص الشكوى أولاً"); return; }
                addItem("complaints", obj("cat", cat[0], "text", t, "date", fmt(System.currentTimeMillis()), "done", "0"));
                show(21);
            }
        });
        add(col, save);
        Button send = button("📤 إرسال الشكوى (واتساب، بريد، رسالة)", CYAN, WHITE);
        send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String t = body.getText().toString().trim();
                if (t.isEmpty()) { toast("اكتب نص الشكوى أولاً"); return; }
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, "شكوى — " + cat[0] + "\n\n" + t);
                startActivity(Intent.createChooser(i, "إرسال الشكوى"));
            }
        });
        add(col, send);
        section(col, "📋 شكاواي", CYAN);
        JSONArray a = loadArr("complaints");
        if (a.length() == 0) add(col, tv("لم تُسجَّل أي شكوى بعد. اكتب شكواك أعلاه ثم احفظها.", 14, GRAY, false));
        for (int i = a.length() - 1; i >= 0; i--) {
            JSONObject it = a.optJSONObject(i);
            if (it == null) continue;
            final int idx = i;
            boolean done = "1".equals(it.optString("done"));
            LinearLayout c = card();
            c.addView(tv((done ? "✅ تمت المعالجة" : "⏳ قيد المتابعة") + "  •  " + it.optString("cat"), 14, done ? 0xFF16A34A : ACC, true));
            c.addView(tv(it.optString("text"), 15, TXT, false));
            c.addView(tv(it.optString("date"), 12, GRAY, false));
            c.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggleItem("complaints", idx, "done", 21); } });
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { confirmDelete("complaints", idx, 21, "حذف هذه الشكوى؟"); return true; }
            });
            add(col, c);
        }
        if (a.length() > 0) add(col, tv("اضغط على الشكوى لتغيير حالتها • اضغط مطولاً للحذف", 12, GRAY, false));
        linkCard(col, "🏛️ وزارة الداخلية والجماعات المحلية", "https://www.interieur.gov.dz");
        return o[0];
    }

    // =====================================================================
    // 📶 INTERNET RECHARGE
    // =====================================================================
    View internet() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📶 تعبئة الإنترنت", "المشغّلون الثلاثة ونسخ كود التعبئة", o);
        section(col, "📡 المشغّلون", ACC);
        linkCard(col, "📱 Djezzy (جازي)", "https://www.djezzy.dz");
        linkCard(col, "📱 Mobilis (موبيليس)", "https://www.mobilis.dz");
        linkCard(col, "📱 Ooredoo (أوريدو)", "https://www.ooredoo.dz");
        section(col, "🎟️ كود التعبئة", ACC2);
        final EditText code = edit("أدخل رقم بطاقة التعبئة");
        code.setInputType(InputType.TYPE_CLASS_NUMBER);
        add(col, code);
        Button copy = button("📋 نسخ الكود", ACC2, WHITE);
        copy.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String s = code.getText().toString().trim();
                if (s.isEmpty()) { toast("أدخل الكود أولاً"); return; }
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("code", s));
                toast("تم النسخ، ألصقه في تطبيق المشغّل أو خانة التعبئة");
            }
        });
        add(col, copy);
        navCard(col, "📞 أكواد الاستعلام والرصيد (الاتصالات)", 2);
        add(col, tv("التعبئة الفعلية تتم عبر بطاقة الشحن أو تطبيق مشغّلك الرسمي. تحقق من الكود قبل الإدخال.", 12, GRAY, false));
        return o[0];
    }

    // =====================================================================
    // 📝 NOTES
    // =====================================================================
    View notes() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📝 سجل الملاحظات", "ملاحظاتك محفوظة في هاتفك فقط", o);
        final EditText ed = edit("اكتب ملاحظة...");
        ed.setSingleLine(false); ed.setMinLines(3); ed.setGravity(Gravity.TOP | Gravity.START);
        add(col, ed);
        Button save = button("💾 حفظ الملاحظة", ACC, WHITE);
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String t = ed.getText().toString().trim();
                if (t.isEmpty()) { toast("اكتب الملاحظة أولاً"); return; }
                addItem("notes", obj("text", t, "date", fmt(System.currentTimeMillis())));
                show(23);
            }
        });
        add(col, save);
        section(col, "🗒️ ملاحظاتي", CYAN);
        JSONArray a = loadArr("notes");
        if (a.length() == 0) add(col, tv("لا توجد ملاحظات بعد. اكتب أول ملاحظة أعلاه.", 14, GRAY, false));
        for (int i = a.length() - 1; i >= 0; i--) {
            JSONObject it = a.optJSONObject(i);
            if (it == null) continue;
            final int idx = i;
            LinearLayout c = card();
            c.addView(tv(it.optString("text"), 15, TXT, false));
            c.addView(tv(it.optString("date"), 12, GRAY, false));
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { confirmDelete("notes", idx, 23, "حذف هذه الملاحظة؟"); return true; }
            });
            add(col, c);
        }
        if (a.length() > 0) add(col, tv("اضغط مطولاً على ملاحظة لحذفها", 12, GRAY, false));
        return o[0];
    }

    // =====================================================================
    // 🧾 BILLS (water, gas, electricity, rent...)
    // =====================================================================
    View bills() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🧾 الفواتير", "تتبّع الماء والغاز والكهرباء والكراء", o);
        JSONArray a = loadArr("bills");
        double unpaid = 0; int unpaidCount = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject b = a.optJSONObject(i);
            if (b == null || "1".equals(b.optString("paid"))) continue;
            try { unpaid += Double.parseDouble(b.optString("amount", "0")); } catch (Exception e) { }
            unpaidCount++;
        }
        LinearLayout sum = card();
        sum.addView(tv("💰 المستحق: " + String.format(Locale.ENGLISH, "%.0f", unpaid) + " دج", 18, CYAN, true));
        sum.addView(tv("فواتير غير مدفوعة: " + unpaidCount, 13, GRAY, false));
        add(col, sum);

        section(col, "➕ إضافة فاتورة", ACC2);
        final String[] type = {BILL_TYPES[0]};
        final Button tb = button("نوع الفاتورة: " + BILL_TYPES[0], ACC, WHITE);
        tb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this).setItems(BILL_TYPES, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { type[0] = BILL_TYPES[w]; tb.setText("نوع الفاتورة: " + BILL_TYPES[w]); }
                }).show();
            }
        });
        add(col, tb);
        final EditText amt = edit("المبلغ بالدينار");
        amt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        add(col, amt);
        final long[] due = {System.currentTimeMillis()};
        final Button db = button("📆 تاريخ الاستحقاق: " + dayStr(due[0]), ACC, WHITE);
        db.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Calendar n = Calendar.getInstance();
                new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker p, int y, int m, int d) {
                        Calendar c = Calendar.getInstance(); c.set(y, m, d, 12, 0, 0);
                        due[0] = c.getTimeInMillis();
                        db.setText("📆 تاريخ الاستحقاق: " + dayStr(due[0]));
                    }
                }, n.get(Calendar.YEAR), n.get(Calendar.MONTH), n.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        add(col, db);
        Button save = button("💾 إضافة الفاتورة", ACC2, WHITE);
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String s = amt.getText().toString().trim();
                if (s.isEmpty()) { toast("أدخل المبلغ أولاً"); return; }
                int rid = 1000 + new Random().nextInt(900000);
                addItem("bills", obj("type", type[0], "amount", s, "due", String.valueOf(due[0]), "paid", "0", "rid", String.valueOf(rid)));
                AlarmReceiver.rescheduleAll(MainActivity.this);
                show(24);
            }
        });
        add(col, save);

        section(col, "📋 فواتيري", CYAN);
        if (a.length() == 0) add(col, tv("لا توجد فواتير بعد. أضف أول فاتورة من النموذج أعلاه.", 14, GRAY, false));
        long now = System.currentTimeMillis();
        for (int i = 0; i < a.length(); i++) {
            JSONObject b = a.optJSONObject(i);
            if (b == null) continue;
            final int idx = i;
            boolean paid = "1".equals(b.optString("paid"));
            long dueT = 0;
            try { dueT = Long.parseLong(b.optString("due", "0")); } catch (Exception e) { }
            String status = paid ? "✅ مدفوعة" : (dueT < now ? "⚠️ متأخرة" : "⏳ مستحقة");
            LinearLayout c = card();
            c.addView(tv(b.optString("type") + "  —  " + b.optString("amount") + " دج", 15, TXT, true));
            c.addView(tv(status + "  •  الاستحقاق: " + dayStr(dueT), 13, paid ? 0xFF16A34A : (dueT < now ? 0xFFEF4444 : GRAY), true));
            c.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { billToggle(idx); } });
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { billDelete(idx); return true; }
            });
            add(col, c);
        }
        if (a.length() > 0) add(col, tv("اضغط على الفاتورة لتعليمها مدفوعة • اضغط مطولاً للحذف", 12, GRAY, false));

        linkGroup(col, "💳 الدفع عبر الجهات الرسمية", CYAN, new String[][]{
            {"💡 سونلغاز (الكهرباء والغاز)", "https://www.sonelgaz.dz"},
            {"💧 الجزائرية للمياه ADE", "https://www.ade.dz"},
            {"📮 بريد الجزائر", "https://www.poste.dz"}});
        return o[0];
    }

    // =====================================================================
    // 🍽️ RESTAURANTS
    // =====================================================================
    View restaurants() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🍽️ المطاعم", "مطاعم ولايتك: " + curW(), o);
        section(col, "🔎 ابحث في ولايتي", ACC);
        String[][] cats = {{"🍽️ مطاعم", "مطعم"}, {"🥘 مطاعم شعبية", "مطعم شعبي"}, {"🍢 مشاوي", "مشوي"}, {"🥗 مطاعم حلال", "مطعم حلال"},
            {"🥐 مخابز وحلويات", "حلويات"}, {"☕ مقاهي", "مقهى"}, {"🍕 بيتزا وبرغر", "بيتزا"}};
        for (String[] c : cats) linkCard(col, c[0] + " — " + curW(), mapsUrl(c[1] + " " + curW()));
        section(col, "🛵 توصيل", ACC2);
        linkCard(col, "🚕 ياسير Yassir", "https://yassir.com");
        section(col, "⭐ مطاعمي المفضّلة", CYAN);
        final EditText name = edit("اسم المطعم (مثال: شوربة الحاج)");
        add(col, name);
        Button fav = button("➕ أضف للمفضّلة", ACC, WHITE);
        fav.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String t = name.getText().toString().trim();
                if (t.isEmpty()) { toast("اكتب اسم المطعم"); return; }
                addItem("fav_rest", obj("name", t, "date", fmt(System.currentTimeMillis())));
                show(25);
            }
        });
        add(col, fav);
        JSONArray a = loadArr("fav_rest");
        if (a.length() == 0) add(col, tv("أضف مطعمك المفضل من الخانة أعلاه.", 14, GRAY, false));
        for (int i = a.length() - 1; i >= 0; i--) {
            JSONObject it = a.optJSONObject(i);
            if (it == null) continue;
            final int idx = i;
            final String nm = it.optString("name");
            LinearLayout c = card();
            c.addView(tv("🍴 " + nm, 15, TXT, true));
            c.addView(tv(it.optString("date"), 12, GRAY, false));
            c.setOnClickListener(url(mapsUrl(nm + " " + curW())));
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { confirmDelete("fav_rest", idx, 25, "حذف هذا المطعم من المفضّلة؟"); return true; }
            });
            add(col, c);
        }
        if (a.length() > 0) add(col, tv("اضغط للبحث عنه على الخريطة • اضغط مطولاً للحذف", 12, GRAY, false));
        return o[0];
    }

    // =====================================================================
    // 🌙 MONTHLY CYCLE CALCULATOR
    // =====================================================================
    void addCycleDate(long t) {
        JSONArray a = loadArr("cyc_hist");
        List<Long> l = new ArrayList<Long>();
        for (int i = 0; i < a.length(); i++) {
            long x = a.optLong(i);
            if (Math.abs(x - t) < 2 * 86400000L) { toast("هذا التاريخ مسجّل مسبقاً"); return; }
            l.add(x);
        }
        l.add(t);
        Collections.sort(l);
        JSONArray out = new JSONArray();
        for (Long x : l) out.put(x);
        saveArr("cyc_hist", out);
        toast("تم تسجيل بداية الدورة");
    }

    String cycleReport(JSONArray hist, int defLen) {
        if (hist.length() == 0) return "سجّلي بداية دورتك الأخيرة لتظهر التوقعات هنا.";
        int L = defLen;
        boolean fromHist = false;
        if (hist.length() >= 2) {
            long sum = 0; int cnt = 0;
            for (int i = 1; i < hist.length(); i++) {
                long diff = (hist.optLong(i) - hist.optLong(i - 1)) / 86400000L;
                if (diff >= 15 && diff <= 60) { sum += diff; cnt++; }
            }
            if (cnt > 0) { L = (int) Math.round((double) sum / cnt); fromHist = true; }
        }
        long now = System.currentTimeMillis();
        Calendar nx = Calendar.getInstance();
        nx.setTimeInMillis(hist.optLong(hist.length() - 1));
        nx.add(Calendar.DAY_OF_YEAR, L);
        while (nx.getTimeInMillis() < now) nx.add(Calendar.DAY_OF_YEAR, L);
        Calendar ov = (Calendar) nx.clone(); ov.add(Calendar.DAY_OF_YEAR, -14);
        Calendar fs = (Calendar) ov.clone(); fs.add(Calendar.DAY_OF_YEAR, -5);
        Calendar fe = (Calendar) ov.clone(); fe.add(Calendar.DAY_OF_YEAR, 1);
        long left = (nx.getTimeInMillis() - now) / 86400000L;
        return "🩸 الدورة القادمة: " + dayStr(nx.getTimeInMillis()) + "\n"
            + "⏳ متوقعة بعد " + left + " يوم\n"
            + "🥚 الإباضة التقريبية: " + dayStr(ov.getTimeInMillis()) + "\n"
            + "🌿 الفترة الخصبة التقريبية: من " + dayStr(fs.getTimeInMillis()) + " إلى " + dayStr(fe.getTimeInMillis()) + "\n"
            + "📏 مدة الدورة المستعملة: " + L + " يوماً" + (fromHist ? " (متوسط سجلّك)" : "") + "\n\n"
            + "⚠️ تقدير تقريبي وليس وسيلة لمنع الحمل ولا تشخيصاً؛ استشيري طبيبتك عند عدم الانتظام أو الألم الشديد.";
    }

    View cycle() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🌙 حاسبة الدورة الشهرية", "تتبّعي دورتك وتوقّعي الموعد القادم", o);
        final JSONArray hist = loadArr("cyc_hist");
        final int defL = sp.getInt("cyc_len", 28);

        section(col, "📅 سجّلي دورتك", ACC2);
        Button today = button("✅ بدأت دورتي اليوم", ACC2, WHITE);
        today.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { addCycleDate(System.currentTimeMillis()); show(26); }
        });
        add(col, today);
        Button pick = button("📆 تسجيل تاريخ بداية دورة سابقة", ACC, WHITE);
        pick.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Calendar n = Calendar.getInstance();
                new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker p, int y, int m, int d) {
                        Calendar c = Calendar.getInstance(); c.set(y, m, d, 12, 0, 0);
                        addCycleDate(c.getTimeInMillis());
                        show(26);
                    }
                }, n.get(Calendar.YEAR), n.get(Calendar.MONTH), n.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        add(col, pick);

        section(col, "⚙️ التوقعات", ACC);
        final EditText len = edit("مدة دورتك المعتادة بالأيام (20 إلى 45)");
        len.setInputType(InputType.TYPE_CLASS_NUMBER);
        len.setText(String.valueOf(defL));
        add(col, len);
        final TextView res = tv(cycleReport(hist, defL), 15, CYAN, true);
        Button calc = button("🔎 احسب وحدّث التوقعات", ACC, WHITE);
        calc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int L;
                try { L = Integer.parseInt(len.getText().toString().trim()); } catch (Exception e) { L = -1; }
                if (L < 20 || L > 45) { toast("أدخلي مدة بين 20 و 45 يوماً"); return; }
                sp.edit().putInt("cyc_len", L).apply();
                res.setText(cycleReport(loadArr("cyc_hist"), L));
            }
        });
        add(col, calc);
        LinearLayout rc = card();
        rc.addView(res);
        add(col, rc);

        section(col, "🗂️ سجلّ دوراتي", CYAN);
        if (hist.length() == 0) add(col, tv("سجّلي أول يوم من دورتك لتبدأ التوقعات.", 14, GRAY, false));
        for (int i = hist.length() - 1; i >= 0 && i >= hist.length() - 12; i--) {
            final int idx = i;
            LinearLayout c = card();
            c.addView(tv("🩸 " + dayStr(hist.optLong(i)), 15, TXT, false));
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { confirmDelete("cyc_hist", idx, 26, "حذف هذا التاريخ من السجل؟"); return true; }
            });
            add(col, c);
        }
        if (hist.length() > 0) add(col, tv("اضغطي مطولاً على تاريخ لحذفه. التوقعات تتحسن كلما سجّلتِ أكثر.", 12, GRAY, false));
        return o[0];
    }

    // =====================================================================
    // v5.1 ADDITIONS: ISLAMIC SECTION + LOGIN
    // =====================================================================
    static final int[] PALETTE = {0xFFFF7A45, 0xFF0EA5C6, 0xFFFF3D81, 0xFF8B5CF6, 0xFF16A34A, 0xFF10B981, 0xFFEC4899, 0xFFEA580C,
        0xFFA855F7, 0xFF0284C7, 0xFF475569, 0xFF3B82F6, 0xFFEF4444, 0xFFF59E0B, 0xFFD946EF, 0xFF64748B};
    static final String[] SURAHS = {"الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
        "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه", "الأنبياء", "الحج", "المؤمنون", "النور",
        "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم", "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص",
        "الزمر", "غافر", "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق", "الذاريات", "الطور",
        "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة", "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق",
        "التحريم", "الملك", "القلم", "الحاقة", "المعارج", "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ",
        "النازعات", "عبس", "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد", "الشمس",
        "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات", "القارعة", "التكاثر", "العصر", "الهمزة",
        "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر", "المسد", "الإخلاص", "الفلق", "الناس"};
    static final String[] DHIKR = {"سبحان الله", "الحمد لله", "الله أكبر", "لا إله إلا الله", "أستغفر الله", "لا حول ولا قوة إلا بالله"};
    static final String[][] HADITHS = {
        {"إنما الأعمال بالنيات، وإنما لكل امرئ ما نوى.", "متفق عليه"},
        {"الدين النصيحة.", "رواه مسلم"},
        {"من حسن إسلام المرء تركه ما لا يعنيه.", "رواه الترمذي وابن ماجه"},
        {"لا يؤمن أحدكم حتى يحب لأخيه ما يحب لنفسه.", "متفق عليه"},
        {"الطهور شطر الإيمان.", "رواه مسلم"},
        {"تبسّمك في وجه أخيك صدقة.", "رواه الترمذي"},
        {"المؤمن للمؤمن كالبنيان يشدّ بعضه بعضاً.", "متفق عليه"},
        {"خيركم من تعلّم القرآن وعلّمه.", "رواه البخاري"},
        {"من كان يؤمن بالله واليوم الآخر فليقل خيراً أو ليصمت.", "متفق عليه"},
        {"لا ضرر ولا ضرار.", "رواه ابن ماجه والدارقطني"},
        {"إن الله رفيق يحب الرفق في الأمر كله.", "متفق عليه"},
        {"أحب الأعمال إلى الله أدومها وإن قل.", "متفق عليه"},
        {"بُني الإسلام على خمس: شهادة أن لا إله إلا الله وأن محمداً رسول الله، وإقام الصلاة، وإيتاء الزكاة، وصوم رمضان، وحج البيت.", "متفق عليه"},
        {"ليس الشديد بالصُّرعة، إنما الشديد الذي يملك نفسه عند الغضب.", "متفق عليه"},
        {"لا تغضب.", "رواه البخاري"},
        {"اتق الله حيثما كنت، وأتبع السيئة الحسنة تمحها، وخالق الناس بخلق حسن.", "رواه الترمذي"},
        {"من غشّنا فليس منا.", "رواه مسلم"},
        {"المسلم من سلم المسلمون من لسانه ويده.", "متفق عليه"},
        {"الكلمة الطيبة صدقة.", "متفق عليه"},
        {"الحياء من الإيمان.", "متفق عليه"},
        {"ما نقصت صدقة من مال.", "رواه مسلم"},
        {"أنا عند ظن عبدي بي.", "متفق عليه"},
        {"كل ابن آدم خطّاء، وخير الخطّائين التوّابون.", "رواه الترمذي وابن ماجه"},
        {"إن الله طيب لا يقبل إلا طيباً.", "رواه مسلم"},
        {"لا يشكر الله من لا يشكر الناس.", "رواه أبو داود والترمذي"}
    };
    static final String[][] TEACH = {
        {"1️⃣ الوضوء", "١) النية في القلب، وتبدأ بـ: بسم الله.\n٢) غسل الوجه ثلاثاً.\n٣) غسل اليدين إلى المرفقين ثلاثاً.\n٤) مسح الرأس.\n٥) مسح الأذنين.\n٦) غسل الرجلين إلى الكعبين ثلاثاً.\nيُرتّب المسلم هذه الخطوات متتالية، ويقول بعد الانتهاء: أشهد أن لا إله إلا الله وحده لا شريك له، وأشهد أن محمداً عبده ورسوله."},
        {"2️⃣ النية والتكبير", "تنوي الصلاة المفروضة (مثلاً: صلاة الظهر) لله تعالى، ثم تقول: الله أكبر، وتضع يديك على صدرك (اليمنى على اليسرى)."},
        {"3️⃣ القيام وقراءة الفاتحة", "بسم الله الرحمن الرحيم\nالحمد لله رب العالمين\nالرحمن الرحيم\nمالك يوم الدين\nإياك نعبد وإياك نستعين\nاهدنا الصراط المستقيم\nصراط الذين أنعمت عليهم غير المغضوب عليهم ولا الضالين\nثم تقرأ ما تيسّر من القرآن في الركعتين الأوليين."},
        {"4️⃣ الركوع", "تقول: الله أكبر، ثم تنحني وتضع يديك على ركبتيك وتقول: سبحان ربي العظيم، ثلاث مرات على الأقل."},
        {"5️⃣ الرفع من الركوع", "ترفع وتقول: سمع الله لمن حمده، ثم وأنت قائم تقول: ربنا ولك الحمد."},
        {"6️⃣ السجود", "تقول: الله أكبر، ثم تسجد على سبعة أعضاء: الجبهة مع الأنف، واليدين، والركبتين، وأطراف القدمين. وتقول: سبحان ربي الأعلى، ثلاث مرات على الأقل."},
        {"7️⃣ الجلسة بين السجدتين", "تقول: الله أكبر، ثم ترفع وتجلس مطمئناً وتقول: رب اغفر لي."},
        {"8️⃣ التشهد", "تجلس وتقول: التحيات لله، والصلوات والطيبات، السلام عليك أيها النبي ورحمة الله وبركاته، السلام علينا وعلى عباد الله الصالحين، أشهد أن لا إله إلا الله، وأشهد أن محمداً عبده ورسوله."},
        {"9️⃣ التسليم", "تقول: السلام عليكم ورحمة الله، وتلتفت يميناً، ثم تقولها وتلتفت يساراً. بذلك تنتهي الصلاة."},
        {"📌 عدد الركعات", "الفجر ركعتان، الظهر أربع، العصر أربع، المغرب ثلاث، العشاء أربع.\nهذا شرح مبسط؛ للتعلّم الصحيح يُستحسن الأخذ عن إمام أو معلّم مختص."}
    };

    // ---------- ISLAMIC HUB ----------
    View islam() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("☪️ الإسلاميات", "القرآن، الأذكار، الأحاديث، وتعليم الصلاة", o);
        navCard(col, "📖 القرآن الكريم (114 سورة)", 28);
        navCard(col, "🤲 حصن المسلم (أذكار مختارة)", 29);
        navCard(col, "💬 أحاديث نبوية مختارة", 30);
        navCard(col, "🧎 تعليم الصلاة خطوة بخطوة", 31);
        navCard(col, "📿 المسبحة الإلكترونية", 32);
        navCard(col, "🕌 أوقات الصلاة", 9);
        return o[0];
    }

    // ---------- QURAN LIST ----------
    void fillSurahs(LinearLayout list, String q) {
        list.removeAllViews();
        for (int i = 0; i < SURAHS.length; i++) {
            if (!q.isEmpty() && !SURAHS[i].contains(q) && !String.valueOf(i + 1).equals(q)) continue;
            final int n = i + 1;
            LinearLayout c = card();
            c.setOrientation(LinearLayout.HORIZONTAL);
            c.addView(tv(n + ".  سورة " + SURAHS[i], 16, TXT, false), new LinearLayout.LayoutParams(0, -2, 1f));
            c.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { curSurah = n; show(34); } });
            add(list, c);
        }
    }

    View quran() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📖 القرآن الكريم", "اختر السورة — النص يُحمَّل من الإنترنت", o);
        LinearLayout pc = card();
        pc.addView(tv("📊 ختمتك: " + readCount() + " من 114 سورة", 15, TXT, true));
        final int lastS = sp.getInt("last_surah", 0);
        if (lastS > 0) {
            pc.addView(tv("📌 متابعة القراءة: سورة " + SURAHS[lastS - 1] + "  ›", 14, ACC, true));
            pc.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { curSurah = lastS; show(34); } });
        }
        add(col, pc);
        final EditText search = edit("🔍 ابحث بالاسم أو الرقم");
        add(col, search);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, new LinearLayout.LayoutParams(-1, -2));
        fillSurahs(list, "");
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { fillSurahs(list, e.toString().trim()); }
        });
        return o[0];
    }

    // ---------- SURAH READER (downloads text in background) ----------
    View surah(final int n) {
        ScrollView[] o = new ScrollView[1];
        markRead(n);
        LinearLayout col = page("📖 سورة " + SURAHS[n - 1], "", o);
        final TextView loading = tv("⏳ جارٍ تحميل النص...", 15, GRAY, false);
        add(col, loading);
        final LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        add(col, body);
        String cachedQ = sp.getString("q" + n, "");
        if (cachedQ.length() > 0) {
            loading.setVisibility(View.GONE);
            LinearLayout cc = card();
            TextView ct = tv(cachedQ, 20, TXT, false);
            ct.setLineSpacing(dp(6), 1f);
            cc.addView(ct);
            add(body, cc);
            return o[0];
        }
        new Thread(new Runnable() {
            public void run() {
                try {
                    String json = httpGet("https://api.alquran.cloud/v1/surah/" + n + "/quran-uthmani");
                    JSONArray ay = new JSONObject(json).getJSONObject("data").getJSONArray("ayahs");
                    final StringBuilder sb = new StringBuilder();
                    for (int i = 0; i < ay.length(); i++) {
                        JSONObject a = ay.getJSONObject(i);
                        sb.append(a.getString("text")).append("  ﴿").append(a.getInt("numberInSurah")).append("﴾  ");
                    }
                    sp.edit().putString("q" + n, sb.toString()).apply();
                    runOnUiThread(new Runnable() {
                        public void run() {
                            loading.setVisibility(View.GONE);
                            LinearLayout c = card();
                            TextView t = tv(sb.toString(), 20, TXT, false);
                            t.setLineSpacing(dp(6), 1f);
                            c.addView(t);
                            add(body, c);
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() { loading.setText("تعذّر تحميل السورة. تحقق من اتصالك بالإنترنت ثم أعد المحاولة."); }
                    });
                }
            }
        }).start();
        return o[0];
    }

    // ---------- HADITHS ----------
    View hadiths() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("💬 أحاديث نبوية", "مختارة من الصحيحين وكتب السنة", o);
        int r = new Random().nextInt(HADITHS.length);
        LinearLayout hc = card();
        hc.addView(tv("✨ حديث اليوم", 13, ACC, true));
        hc.addView(tv(HADITHS[r][0], 18, TXT, true));
        hc.addView(tv(HADITHS[r][1], 12, GRAY, false));
        add(col, hc);
        Button again = button("🔄 حديث آخر", ACC, WHITE);
        again.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { show(30); } });
        add(col, again);
        section(col, "📚 كل الأحاديث", CYAN);
        for (String[] h : HADITHS) {
            LinearLayout c = card();
            c.addView(tv(h[0], 15, TXT, false));
            c.addView(tv(h[1], 12, GRAY, false));
            add(col, c);
        }
        add(col, tv("للاطلاع الكامل راجع كتب السنة الموثوقة (صحيح البخاري، صحيح مسلم، وغيرهما).", 12, GRAY, false));
        return o[0];
    }

    // ---------- PRAYER TEACHING ----------
    View teaching() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🧎 تعليم الصلاة", "خطوات الوضوء والصلاة — اضغط على الخطوة", o);
        for (String[] s : TEACH) infoCard(col, s[0], s[1]);
        return o[0];
    }

    // ---------- TASBIH ----------
    View tasbih() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📿 المسبحة", "اضغط الزر للتسبيح", o);
        final TextView num = tv(String.valueOf(sp.getInt("tasbih_n", 0)), 64, ACC, true);
        num.setGravity(Gravity.CENTER);
        LinearLayout nc = card();
        nc.addView(num);
        add(col, nc);
        final int zi = sp.getInt("tasbih_z", 0);
        final Button dz = button(DHIKR[zi], CYAN, WHITE);
        dz.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int nz = (sp.getInt("tasbih_z", 0) + 1) % DHIKR.length;
                sp.edit().putInt("tasbih_z", nz).apply();
                dz.setText(DHIKR[nz]);
            }
        });
        add(col, dz);
        Button tap = button("👆 سبّح", ACC2, WHITE);
        tap.setTextSize(22 * SC);
        tap.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int c = sp.getInt("tasbih_n", 0) + 1;
                sp.edit().putInt("tasbih_n", c).apply();
                num.setText(String.valueOf(c));
            }
        });
        add(col, tap);
        Button reset = button("🔄 تصفير العداد", GRAY, WHITE);
        reset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sp.edit().putInt("tasbih_n", 0).apply(); show(32); }
        });
        add(col, reset);
        return o[0];
    }

    // ---------- ACCOUNT (local login) ----------
    boolean loggedIn() { return sp.getBoolean("loggedIn", false); }
    boolean hasAccount() { return sp.contains("acc_user"); }
    static String hashPin(String s) {
        try {
            byte[] b = java.security.MessageDigest.getInstance("SHA-256").digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x & 0xff));
            return sb.toString();
        } catch (Exception e) { return s; }
    }

    // =====================================================================
    // v5.2 ADDITIONS
    // =====================================================================
    static final String RAW_BASE = "https://raw.githubusercontent.com/rn0x/Adhkar-json/main";
    static final String HISN_URL = RAW_BASE + "/adhkar.json";
    static final String STORE_WA = "213000000000"; // ضع رقم واتساب المتجر بالصيغة الدولية بدون +
    static final String[][] STORE_ITEMS = {
        {"منتج 1 (غيّر الاسم والسعر)", "1000"},
        {"منتج 2 (غيّر الاسم والسعر)", "2500"},
        {"منتج 3 (غيّر الاسم والسعر)", "1500"},
        {"منتج 4 (غيّر الاسم والسعر)", "3000"}};
    MediaPlayer player;
    int[] cartQty;

    // ---------- AUDIO ----------
    void playUrl(String url) {
        try {
            stopPlayer();
            player = new MediaPlayer();
            player.setAudioStreamType(AudioManager.STREAM_MUSIC);
            player.setDataSource(url);
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                public void onPrepared(MediaPlayer mp) { mp.start(); }
            });
            player.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                public boolean onError(MediaPlayer mp, int what, int extra) { toast("تعذّر تشغيل البث"); return true; }
            });
            player.prepareAsync();
        } catch (Exception e) {
            toast("تعذّر تشغيل الصوت، تحقق من الإنترنت");
        }
    }
    void stopPlayer() {
        if (player != null) {
            try { player.stop(); } catch (Exception e) { }
            player.release();
            player = null;
        }
    }

    // ---------- HISN AL-MUSLIM (full book, loaded once then cached) ----------
    void fetchHisn() {
        toast("جارٍ تحميل الكتاب...");
        new Thread(new Runnable() {
            public void run() {
                try {
                    String s = httpGet(HISN_URL);
                    new JSONArray(s);
                    sp.edit().putString("hisn_json", s).apply();
                    runOnUiThread(new Runnable() { public void run() { show(29); } });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() { public void run() { toast("تعذّر تحميل الكتاب، تحقق من الإنترنت ثم أعد المحاولة"); } });
                }
            }
        }).start();
    }

    JSONArray hisnData() {
        try { return new JSONArray(sp.getString("hisn_json", "[]")); } catch (Exception e) { return new JSONArray(); }
    }

    View hisnCats() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🤲 حصن المسلم", "الكتاب كاملاً — يُحمَّل مرة واحدة ثم يعمل بدون إنترنت", o);
        JSONArray cats = hisnData();
        if (cats.length() == 0) {
            add(col, tv("الكتاب غير محمّل بعد. يلزم اتصال بالإنترنت للمرة الأولى.", 15, GRAY, false));
            Button retry = button("🔄 تحميل الكتاب", ACC, WHITE);
            retry.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { fetchHisn(); } });
            add(col, retry);
            return o[0];
        }
        for (int i = 0; i < cats.length(); i++) {
            JSONObject c = cats.optJSONObject(i);
            if (c == null) continue;
            final int idx = i;
            int n = c.optJSONArray("array") != null ? c.optJSONArray("array").length() : 0;
            LinearLayout card = card();
            card.addView(tv(c.optString("category", "باب"), 16, TXT, true));
            card.addView(tv(n + " ذكراً أو دعاءً", 12, GRAY, false));
            card.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { curHisn = idx; show(35); } });
            add(col, card);
        }
        add(col, tv("المصدر: كتاب حصن المسلم للشيخ سعيد بن علي القحطاني (ملف أذكار مفتوح)، والصوت بقراءة الشيخ حمد الدريهم.", 12, GRAY, false));
        return o[0];
    }

    View hisnItems() {
        ScrollView[] o = new ScrollView[1];
        JSONArray cats = hisnData();
        JSONObject cat = cats.optJSONObject(curHisn);
        if (cat == null) return hisnCats();
        LinearLayout col = page(cat.optString("category", "حصن المسلم"), "اضغط على الذكر لعرضه بخط كبير", o);
        final String audio = cat.optString("audio", "");
        if (audio.length() > 0) {
            Button play = button("🔊 استماع لهذا الباب", ACC2, WHITE);
            play.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { playUrl(RAW_BASE + audio); toast("▶ تشغيل"); } });
            add(col, play);
            Button stop = button("⏹ إيقاف الصوت", GRAY, WHITE);
            stop.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { stopPlayer(); } });
            add(col, stop);
        }
        JSONArray arr = cat.optJSONArray("array");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject z = arr.optJSONObject(i);
                if (z == null) continue;
                final String t = z.optString("text", "");
                final String cnt = z.optString("count", "1");
                LinearLayout c = card();
                c.addView(tv(t, 17, TXT, false));
                c.addView(tv("× " + cnt, 12, ACC, true));
                c.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View v) {
                        new AlertDialog.Builder(MainActivity.this).setMessage(t).setPositiveButton("حسناً", null).show();
                    }
                });
                add(col, c);
            }
        }
        return o[0];
    }

    // ---------- RADIO (live streams from Radio Browser directory) ----------
    View radio() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📻 الراديو", "إذاعات جزائرية مباشرة — اضغط للاستماع", o);
        final TextView status = tv("⏹ لا يوجد بث حالياً", 14, GRAY, true);
        add(col, status);
        Button stop = button("⏹ إيقاف البث", ACC2, WHITE);
        stop.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { stopPlayer(); status.setText("⏹ متوقف"); }
        });
        add(col, stop);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, new LinearLayout.LayoutParams(-1, -2));
        add(list, tv("⏳ جارٍ تحميل قائمة الإذاعات...", 14, GRAY, false));
        new Thread(new Runnable() {
            public void run() {
                try {
                    String s = httpGet("https://de1.api.radio-browser.info/json/stations/bycountrycodeexact/DZ?hidebroken=true&order=clickcount&reverse=true&limit=80");
                    final JSONArray arr = new JSONArray(s);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            list.removeAllViews();
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject st = arr.optJSONObject(i);
                                if (st == null) continue;
                                final String name = st.optString("name", "إذاعة");
                                final String url = st.optString("url_resolved", st.optString("url", ""));
                                if (url.length() == 0) continue;
                                LinearLayout c = card();
                                c.addView(tv("📻 " + name, 15, TXT, true));
                                c.setOnClickListener(new View.OnClickListener() {
                                    public void onClick(View v) { status.setText("▶ " + name); playUrl(url); }
                                });
                                add(list, c);
                            }
                            if (list.getChildCount() == 0) add(list, tv("لا توجد إذاعات متاحة الآن.", 14, GRAY, false));
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() {
                            list.removeAllViews();
                            add(list, tv("تعذّر تحميل الإذاعات، تحقق من الإنترنت ثم ادخل الصفحة من جديد.", 14, GRAY, false));
                        }
                    });
                }
            }
        }).start();
        linkCard(col, "🌐 الإذاعة الجزائرية الرسمية", "https://my.radioalgerie.dz");
        return o[0];
    }

    // ---------- TV CHANNELS (official EPTV links) ----------
    View tvChannels() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📺 القنوات التلفزيونية", "قنوات التلفزيون الجزائري الرسمية (EPTV)", o);
        String[][] ch = {
            {"📺 القناة الأولى (ENTV)", "https://www.entv.dz"},
            {"📺 Canal Algérie (فرنسية) — بث مباشر", "https://www.entv.dz/live-canal-algerie/"},
            {"📺 القناة الثالثة A3 (الأخبار)", "https://www.entv.dz"},
            {"📺 القناة الرابعة (أمازيغية)", "https://www.entv.dz"},
            {"📺 القناة الخامسة (القرآن الكريم)", "https://www.entv.dz"},
            {"▶️ Canal Algérie على يوتيوب", "https://www.youtube.com/@CanalAlgerieDZ"}};
        linkGroup(col, "📡 القنوات", ACC, ch);
        add(col, tv("الروابط تفتح الموقع الرسمي أو قناة يوتيوب الرسمية للبث المباشر والبرامج.", 12, GRAY, false));
        return o[0];
    }

    // ---------- MOVIES (legal sources only) ----------
    View movies() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🎬 الأفلام", "أفلام من منصات قانونية ومجانية", o);
        linkGroup(col, "🎬 ابحث في يوتيوب", ACC2, new String[][]{
            {"🇩🇿 أفلام جزائرية", mapsYt("أفلام جزائرية كاملة")},
            {"🎞️ أفلام عربية", mapsYt("أفلام عربية كاملة")},
            {"🎥 أفلام وثائقية", mapsYt("أفلام وثائقية")},
            {"👶 أفلام الأطفال", mapsYt("أفلام كرتون للأطفال")}});
        linkGroup(col, "🌐 منصات رسمية", CYAN, new String[][]{
            {"▶️ قناة Canal Algérie على يوتيوب", "https://www.youtube.com/@CanalAlgerieDZ"},
            {"📺 تلفزيون الجزائر (ENTV)", "https://www.entv.dz"}});
        add(col, tv("التطبيق يوجّه فقط إلى منصات قانونية؛ لا يعرض أفلاماً مقرصنة.", 12, GRAY, false));
        return o[0];
    }
    String mapsYt(String q) { return "https://www.youtube.com/results?search_query=" + Uri.encode(q); }

    // ---------- SPECIAL NEEDS ----------
    View specialNeeds() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("♿ ذوو الاحتياجات الخاصة", "الحقوق، البطاقات، والمنح", o);
        linkGroup(col, "🪪 الخدمات الرقمية", ACC, new String[][]{
            {"🌐 البوابة الوطنية للخدمات الرقمية (dzds.dz)", "https://dzds.dz/ar-dz"}});
        infoCard(col, "🪪 بطاقة الشخص ذي الاحتياجات الخاصة",
            "يمكن طلب البطاقة لأول مرة، أو تعديل بياناتها، أو إعادة إصدارها عند الضياع أو التلف، عبر البوابة الوطنية للخدمات الرقمية بعد إنشاء حساب فيها.");
        infoCard(col, "💰 المنحة الجزافية للتضامن",
            "يمكن طلب بطاقة المنحة أو تحديث بياناتها أو إعادة إصدارها عبر البوابة الوطنية للخدمات الرقمية، وتشترط المنحة عدم الازدواج في الاستفادة.");
        infoCard(col, "🏥 التغطية الصحية",
            "حسب وزارة التضامن، يستفيد المعنيون من التغطية الصحية التي تشمل الأدوية والتحاليل والنظارات والأجهزة الخاصة وإعادة التأهيل.");
        infoCard(col, "⚖️ القانون 25-01",
            "القانون المتعلق بحماية الأشخاص ذوي الاحتياجات الخاصة وترقيتهم (فيفري 2025)، وصدرت بعده مراسيم وتعديلات لفائدة من لا دخل لهم.");
        infoCard(col, "🎓 التكوين المهني",
            "المتربصون من ذوي الاحتياجات الخاصة في مراكز التكوين المهني يواصلون الاستفادة من المنحة والتغطية الاجتماعية أثناء التكوين، حسب المنشور الوزاري المشترك.");
        linkCard(col, "📍 مديرية النشاط الاجتماعي لولايتي (خرائط)", mapsUrl("مديرية النشاط الاجتماعي " + curW()));
        add(col, tv("المعلومات عامة؛ تأكد من الشروط والوثائق لدى مصالح وزارة التضامن أو مديريتها في ولايتك.", 12, GRAY, false));
        return o[0];
    }

    // ---------- ORPHANS ----------
    View orphans() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("👶 الأيتام", "كفالة اليتيم والمساعدة", o);
        infoCard(col, "🤍 كفالة اليتيم",
            "المساعدة والكفالة للأيتام تُطلب من مديرية النشاط الاجتماعي للتضامن في ولايتك. اسأل المديرية عن الوثائق المطلوبة، وغالباً تشمل شهادة الميلاد وشهادة الوفاة للأب أو الأم وشهادة الحالة الاجتماعية.");
        infoCard(col, "🧾 الخدمات الرقمية",
            "بعض إجراءات وزارة التضامن أصبحت رقمية عبر البوابة الوطنية للخدمات الرقمية، بعد إنشاء حساب فيها.");
        linkGroup(col, "🔗 روابط وأماكن", ACC2, new String[][]{
            {"🌐 البوابة الوطنية للخدمات الرقمية", "https://dzds.dz/ar-dz"},
            {"📍 مديرية النشاط الاجتماعي لولايتي", mapsUrl("مديرية النشاط الاجتماعي " + curW())},
            {"🤝 جمعيات كفالة اليتيم في ولايتي", mapsUrl("جمعية كفالة اليتيم " + curW())}});
        add(col, tv("المعلومات عامة؛ الشروط والوثائق تحددها المصالح المختصة في ولايتك.", 12, GRAY, false));
        return o[0];
    }

    // ---------- ADL HOUSING ----------
    View adl() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🏠 سكنات عدل", "المواقع الرسمية والتحقق من التسجيل", o);
        linkGroup(col, "🔗 المواقع الرسمية", ACC, new String[][]{
            {"🏠 الموقع الرسمي لوكالة عدل (aadl.dz)", "https://www.aadl.dz"},
            {"🔑 منصة تمليك سكنات عدل", "https://mainlevee.aadl.com.dz"}});
        section(col, "☎️ الرقم الأخضر", ACC2);
        codeRow(col, "الرقم الأخضر لوكالة عدل (الاستفسارات)", "3040", ACC2);
        infoCard(col, "📌 التحقق من التسجيل",
            "حسب بيان وزارة السكن، يُعتبر مسجلاً كل من تلقى الرسالة الصوتية بعد الاتصال بالرقم الثابت المعروض على المنصة الرسمية.");
        infoCard(col, "⚠️ احذر المواقع الوهمية",
            "هناك مواقع تبيع أو تعد بسكنات عدل بطرق غير رسمية. التسجيل والطعون والتمليك تكون فقط عبر الموقع الرسمي للوكالة، ولا تدفع أي مبلغ لأي جهة غير رسمية.");
        add(col, tv("للمتابعة استعمل الموقع الرسمي فقط، وتأكد من المعلومات قبل أي خطوة.", 12, GRAY, false));
        return o[0];
    }

    // ---------- ONLINE STORE (orders via WhatsApp) ----------
    int cartTotal() {
        int t = 0;
        for (int i = 0; i < STORE_ITEMS.length; i++) {
            try { t += Integer.parseInt(STORE_ITEMS[i][1]) * cartQty[i]; } catch (Exception e) { }
        }
        return t;
    }
    View store() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🛍️ المتجر الإلكتروني", "اختر المنتجات واطلب عبر واتساب", o);
        if (cartQty == null || cartQty.length != STORE_ITEMS.length) cartQty = new int[STORE_ITEMS.length];
        final TextView totalTv = tv("المجموع: " + cartTotal() + " دج", 18, CYAN, true);
        add(col, totalTv);
        for (int i = 0; i < STORE_ITEMS.length; i++) {
            final int idx = i;
            LinearLayout c = card();
            c.addView(tv(STORE_ITEMS[i][0], 16, TXT, true));
            c.addView(tv(STORE_ITEMS[i][1] + " دج", 14, ACC, true));
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            final TextView q = tv(String.valueOf(cartQty[i]), 18, TXT, true);
            q.setGravity(Gravity.CENTER);
            Button minus = button("−", GRAY, WHITE);
            Button plus = button("+", ACC, WHITE);
            minus.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    if (cartQty[idx] > 0) cartQty[idx]--;
                    q.setText(String.valueOf(cartQty[idx]));
                    totalTv.setText("المجموع: " + cartTotal() + " دج");
                }
            });
            plus.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    cartQty[idx]++;
                    q.setText(String.valueOf(cartQty[idx]));
                    totalTv.setText("المجموع: " + cartTotal() + " دج");
                }
            });
            row.addView(minus, new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(q, new LinearLayout.LayoutParams(0, -2, 1f));
            row.addView(plus, new LinearLayout.LayoutParams(0, -2, 1f));
            c.addView(row);
            add(col, c);
        }
        Button order = button("📲 اطلب عبر واتساب", 0xFF16A34A, WHITE);
        order.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (cartTotal() == 0) { toast("اختر منتجاً أولاً"); return; }
                StringBuilder sb = new StringBuilder("طلب جديد:\n");
                for (int i = 0; i < STORE_ITEMS.length; i++) {
                    if (cartQty[i] > 0) sb.append("- ").append(STORE_ITEMS[i][0]).append(" × ").append(cartQty[i]).append("\n");
                }
                sb.append("المجموع: ").append(cartTotal()).append(" دج");
                open("https://wa.me/" + STORE_WA + "?text=" + Uri.encode(sb.toString()));
            }
        });
        add(col, order);
        add(col, tv("الأسعار والمنتجات قابلة للتغيير. الطلب يُرسل إلى الواتساب، والدفع والتسليم يُتفق عليهما مع البائع.", 12, GRAY, false));
        return o[0];
    }

    // ---------- ACCOUNT SOCIAL LINKS ----------
    void socialCard(LinearLayout col) {
        section(col, "💬 حساباتي على واتساب وتيليغرام", CYAN);
        final EditText wa = edit("رقم واتساب بالصيغة الدولية (مثال: 2135XXXXXXXX)");
        wa.setInputType(InputType.TYPE_CLASS_PHONE);
        wa.setText(sp.getString("acc_wa", ""));
        add(col, wa);
        final EditText tg = edit("اسم المستخدم على تيليغرام (بدون @)");
        tg.setText(sp.getString("acc_tg", ""));
        add(col, tg);
        Button save = button("💾 حفظ الحسابين", ACC, WHITE);
        save.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String d = wa.getText().toString().replaceAll("[^0-9]", "");
                String t = tg.getText().toString().trim().replace("@", "");
                sp.edit().putString("acc_wa", d).putString("acc_tg", t).apply();
                toast("تم الحفظ");
            }
        });
        add(col, save);
        Button ow = button("💬 فتح واتساب", 0xFF16A34A, WHITE);
        ow.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String d = sp.getString("acc_wa", "");
                if (d.length() == 0) { toast("أدخل رقم واتساب أولاً"); return; }
                open("https://wa.me/" + d);
            }
        });
        add(col, ow);
        Button ot = button("✈️ فتح تيليغرام", 0xFF0EA5C6, WHITE);
        ot.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String t = sp.getString("acc_tg", "");
                if (t.length() == 0) { toast("أدخل اسم المستخدم أولاً"); return; }
                open("https://t.me/" + t);
            }
        });
        add(col, ot);
    }

    // =====================================================================
    // v5.3 ADDITIONS: notifications, bill alerts, search, cache, settings
    // =====================================================================
    void notifySetup() {
        AlarmReceiver.rescheduleAll(this);
        if (Build.VERSION.SDK_INT >= 33 && sp.getBoolean("notif_prayer", true)
            && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 77);
        }
    }

    void billToggle(int idx) {
        JSONArray a = loadArr("bills");
        JSONObject b = a.optJSONObject(idx);
        if (b == null) return;
        boolean nowPaid = !"1".equals(b.optString("paid"));
        try { b.put("paid", nowPaid ? "1" : "0"); } catch (Exception e) { }
        saveArr("bills", a);
        if (nowPaid) AlarmReceiver.cancelBill(this, AlarmReceiver.ridOf(b));
        else AlarmReceiver.rescheduleAll(this);
        show(24);
    }

    void billDelete(final int idx) {
        new AlertDialog.Builder(this).setMessage("حذف هذه الفاتورة؟")
            .setPositiveButton("حذف", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int w) {
                    JSONObject b = loadArr("bills").optJSONObject(idx);
                    if (b != null) AlarmReceiver.cancelBill(MainActivity.this, AlarmReceiver.ridOf(b));
                    removeAt("bills", idx);
                    show(24);
                }
            })
            .setNegativeButton("إلغاء", null).show();
    }

    // ---------- GLOBAL SEARCH ----------
    static final String[][] SEARCH_INDEX = {
        {"أوقات الصلاة", "صلاة فجر ظهر عصر مغرب عشاء أذان مواقيت", "9"},
        {"القرآن الكريم", "قرآن سورة آية مصحف", "28"},
        {"حصن المسلم", "أذكار دعاء ذكر صباح مساء نوم حصن", "29"},
        {"الأحاديث", "حديث نبوي سنة", "30"},
        {"تعليم الصلاة", "وضوء ركوع سجود تشهد تكبير صلاة", "31"},
        {"المسبحة", "تسبيح ذكر عداد", "32"},
        {"الراديو", "إذاعة إذاعات بث قرآن جزائر", "36"},
        {"القنوات التلفزيونية", "تلفزيون قناة قنوات entv canal", "37"},
        {"الأفلام", "فيلم أفلام سينما وثائقي", "38"},
        {"ذوو الاحتياجات الخاصة", "إعاقة بطاقة منحة تضامن", "39"},
        {"الأيتام", "يتيم كفالة", "40"},
        {"سكنات عدل", "عدل aadl سكن تمليك", "41"},
        {"المتجر الإلكتروني", "شراء طلب منتج متجر", "42"},
        {"المستشفيات", "مستشفى مستعجلات إسعاف صيدلية طبيب", "18"},
        {"خدمات البلدية", "بلدية شهادة ميلاد إقامة حياة عزوبة رخصة", "19"},
        {"وثائقي", "وثائق ملفات pdf صورة", "20"},
        {"الشكاوي", "شكوى شكاية مشكل", "21"},
        {"تعبئة الإنترنت", "انترنت إنترنت شحن كود جازي موبيليس أوريدو", "22"},
        {"سجل الملاحظات", "ملاحظة مذكرة", "23"},
        {"الفواتير", "فاتورة ماء غاز كهرباء كراء إيجار", "24"},
        {"المطاعم", "مطعم أكل توصيل", "25"},
        {"الدورة الشهرية", "دورة حيض توقع إباضة", "26"},
        {"أرقام الطوارئ", "طوارئ 17 شرطة درك إسعاف 115", "6"},
        {"الولايات", "ولاية رقم لوحة طقس", "7"},
        {"النقل", "مترو ترامواي حافلة قطار SNTF", "1"},
        {"الاتصالات", "هاتف رصيد أكواد", "2"},
        {"الأخبار", "خبر أخبار", "3"},
        {"المباريات", "كرة قدم رياضة نتائج", "12"},
        {"المرأة الجزائرية", "امرأة عنف حماية حمل", "13"},
        {"الطبخ الجزائري", "وصفة طبخ أكل جزائري", "14"},
        {"الملابس والأزياء", "قندورة لباس تقليدي", "15"},
        {"كبار السن", "مسن تقاعد", "16"},
        {"مواعيدي", "موعد تقويم", "5"},
        {"حاسبة المعدل", "معدل بكالوريا نقاط", "10"},
        {"حسابي", "تسجيل دخول واتساب تيليغرام حساب", "33"},
        {"الإعدادات", "إعدادات مظهر خط كبير وضع داكن إشعارات", "11"},
        {"حول التطبيق", "المطور معلومات", "8"},
        {"الإسلاميات", "إسلام دين", "27"}
    };

    View searchView() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🔎 بحث في التطبيق", "ابحث عن قسم، سورة، حديث، أو ذكر", o);
        final EditText ed = edit("اكتب كلمة للبحث...");
        add(col, ed);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, new LinearLayout.LayoutParams(-1, -2));
        doSearch(list, "");
        ed.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            public void onTextChanged(CharSequence s, int a, int b, int c) {}
            public void afterTextChanged(Editable e) { doSearch(list, e.toString().trim()); }
        });
        return o[0];
    }

    void addResult(LinearLayout list, String title, String sub, final int tab, final int surah, final int hisnCat) {
        LinearLayout c = card();
        c.addView(tv(title, 16, TXT, true));
        c.addView(tv(sub, 12, GRAY, false));
        c.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (surah > 0) curSurah = surah;
                if (hisnCat >= 0) curHisn = hisnCat;
                show(tab);
            }
        });
        add(list, c);
    }

    void doSearch(LinearLayout list, String q) {
        list.removeAllViews();
        if (q.length() < 2) {
            add(list, tv("اكتب حرفين على الأقل، مثلاً: فجر، قرآن، فاتورة، طبيب", 14, GRAY, false));
            return;
        }
        int count = 0;
        for (String[][] group : new String[][][]{SEARCH_INDEX, SEARCH_INDEX2}) {
            for (String[] s : group) {
                if (s[0].contains(q) || s[1].contains(q)) { addResult(list, s[0], "قسم", Integer.parseInt(s[2]), -1, -1); count++; }
            }
        }
        for (int i = 0; i < SURAHS.length; i++) {
            if (SURAHS[i].contains(q)) { addResult(list, "📖 سورة " + SURAHS[i], "القرآن الكريم", 34, i + 1, -1); count++; }
        }
        for (String[] h : HADITHS) {
            if (h[0].contains(q)) { addResult(list, h[0], "حديث — " + h[1], 30, -1, -1); count++; }
        }
        JSONArray cats = hisnData();
        int shown = 0;
        for (int i = 0; i < cats.length() && shown < 30; i++) {
            JSONObject c = cats.optJSONObject(i);
            if (c == null) continue;
            JSONArray arr = c.optJSONArray("array");
            if (arr == null) continue;
            for (int j = 0; j < arr.length() && shown < 30; j++) {
                JSONObject z = arr.optJSONObject(j);
                if (z == null) continue;
                String t = z.optString("text", "");
                if (t.contains(q)) {
                    String snip = t.length() > 70 ? t.substring(0, 70) + "..." : t;
                    addResult(list, snip, "حصن المسلم — " + c.optString("category"), 35, -1, i);
                    shown++; count++;
                }
            }
        }
        if (count == 0) add(list, tv("لا توجد نتائج لـ «" + q + "»", 14, GRAY, false));
    }

    // =====================================================================
    // v5.4: navigation with back, onboarding, account, Algerian-style tools
    // =====================================================================
    java.util.ArrayList<Integer> hist = new java.util.ArrayList<Integer>();
    int curTab = -1;
    boolean navBack = false;
    static final int[] GCOL = {0xFF16A34A, 0xFF8B5CF6, 0xFFEC4899, 0xFF0EA5C6, 0xFFEA580C, 0xFFDB2777, 0xFFF59E0B, 0xFF475569, 0xFF0F766E, 0xFF6366F1};
    static final String[] HAJJ_ITEMS = {"جواز سفر ساري المفعول (تحقق من مدة الصلاحية)", "التسجيل عبر الجهة الرسمية أو الوكالة المعتمدة",
        "الفحوصات الطبية والتلقيحات المطلوبة", "الأدوية الشخصية مع الوصفة الطبية", "الملابس والحقيبة (الإحرام للرجال)",
        "صور شمسية حسب المتطلبات", "تعلّم أحكام المناسك والأدعية (حصن المسلم)", "تأكيد الرحلة والإقامة"};
    static final String[] CN_ITEMS = {"الوثيقة القديمة إن وُجدت (في حالة التجديد)", "شهادة الميلاد", "صورة شمسية حديثة", "إثبات الإقامة", "الرسوم المطلوبة (تحقق من المصلحة)"};
    static final String[] PP_ITEMS = {"بطاقة التعريف الوطنية", "شهادة الميلاد", "جواز السفر القديم إن وُجد", "صور شمسية حديثة", "وصل الدفع (تحقق من المبلغ)"};
    static final String[] BIRTH_ITEMS = {"بطاقة التعريف الوطنية أو وثيقة هوية", "تاريخ ومكان الولادة", "الرسوم إن طُلبت"};
    static final String[] RENT_ITEMS = {"بطاقة التعريف الوطنية", "عقد الكراء (موثّق إن وُجد)", "آخر فاتورة ماء أو كهرباء", "شهادة الإقامة"};

    void goBack() {
        if (hist.isEmpty()) return;
        int prev = hist.remove(hist.size() - 1);
        navBack = true;
        show(prev);
    }

    @Override
    public void onBackPressed() {
        if (!hist.isEmpty()) goBack(); else super.onBackPressed();
    }

    long atToday(String hhmm) {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hhmm.substring(0, 2)));
        c.set(Calendar.MINUTE, Integer.parseInt(hhmm.substring(3, 5)));
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    String fmtD(double v) { return String.format(Locale.ENGLISH, "%.0f", v); }
    double num(EditText e) { try { return Double.parseDouble(e.getText().toString().trim()); } catch (Exception x) { return 0; } }

    // ---------- ONBOARDING ----------
    View onboarding() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("مرحباً بك في الرفيق", "خطوتان فقط قبل البدء", o);
        section(col, "1️⃣ اختر ولايتك", ACC);
        Button wb = button("📍 ولايتي: " + curW() + "  (تغيير)", ACC, WHITE);
        wb.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { chooseWilaya(44); } });
        add(col, wb);
        add(col, tv("تُستعمل لأوقات الصلاة وخدمات المنطقة.", 12, GRAY, false));
        section(col, "2️⃣ التنبيهات", ACC2);
        add(col, tv("نذكّرك بأوقات الصلاة وتواريخ الفواتير. يمكنك تغيير ذلك من الإعدادات في أي وقت.", 14, TXT, false));
        Button start = button("✅ ابدأ الاستعمال", ACC2, WHITE);
        start.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { sp.edit().putBoolean("onboarded", true).apply(); notifySetup(); show(0); }
        });
        add(col, start);
        return o[0];
    }

    // ---------- RAMADAN ----------
    View ramadan() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🌙 رمضان", "عداد الإمساك والإفطار حسب ولايتك", o);
        String[] p = sp.getString("ptimes", "").split(",");
        if (p.length != 6) {
            add(col, tv("افتح «أوقات الصلاة» مرة واحدة ليُحفظ التوقيت، ثم عُد إلى هنا.", 14, GRAY, false));
            Button gb = button("🕌 أوقات الصلاة", ACC, WHITE);
            gb.setOnClickListener(go(9));
            add(col, gb);
            return o[0];
        }
        long now = System.currentTimeMillis();
        long fajr = atToday(p[0]), maghrib = atToday(p[4]);
        String label; long target;
        if (now < fajr) { label = "⏳ باقٍ على الإمساك"; target = fajr; }
        else if (now < maghrib) { label = "🍽️ باقٍ على الإفطار"; target = maghrib; }
        else { label = "🌙 باقٍ على إمساك الغد"; target = fajr + 86400000L; }
        long diff = Math.max(0, target - now);
        LinearLayout c = card();
        c.addView(tv(label, 16, ACC, true));
        c.addView(tv((diff / 3600000L) + " س  " + ((diff % 3600000L) / 60000L) + " د", 40, TXT, true));
        add(col, c);
        LinearLayout t2 = card();
        t2.addView(tv("🌅 الإمساك (الفجر): " + p[0], 16, TXT, false));
        t2.addView(tv("🌇 الإفطار (المغرب): " + p[4], 16, TXT, false));
        add(col, t2);
        Button rf = button("🔄 تحديث العداد", ACC, WHITE);
        rf.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { show(45); } });
        add(col, rf);
        section(col, "🤲 دعاء الإفطار", CYAN);
        LinearLayout dc = card();
        dc.addView(tv("ذهب الظمأ، وابتلت العروق، وثبت الأجر إن شاء الله.", 16, TXT, false));
        dc.addView(tv("رواه أبو داود", 12, GRAY, false));
        add(col, dc);
        add(col, tv("التوقيت محفوظ من آخر تحميل لأوقات الصلاة.", 12, GRAY, false));
        return o[0];
    }

    // ---------- ZAKAT ----------
    View zakat() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🧮 حاسبة الزكاة", "زكاة المال 2.5% إذا بلغ النصاب وحال عليه الحول", o);
        final EditText money = edit("مجموع المال (نقود وأرصدة) بالدينار");
        money.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        add(col, money);
        final EditText gold = edit("سعر غرام الذهب اليوم بالدينار");
        gold.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        gold.setText(sp.getString("gold_price", ""));
        add(col, gold);
        final EditText debts = edit("الديون الحالّة عليك (اختياري)");
        debts.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        add(col, debts);
        final TextView res = tv("", 16, CYAN, true);
        Button calc = button("🧮 احسب الزكاة", ACC, WHITE);
        calc.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sp.edit().putString("gold_price", gold.getText().toString().trim()).apply();
                double g = num(gold);
                if (g <= 0) { res.setText("أدخل سعر غرام الذهب لحساب النصاب."); return; }
                double nisab = 85 * g;
                double net = num(money) - num(debts);
                if (net < nisab) res.setText("المال لم يبلغ النصاب (" + fmtD(nisab) + " دج)، فلا زكاة فيه.");
                else res.setText("🕋 الزكاة المستحقة: " + fmtD(net * 0.025) + " دج");
            }
        });
        add(col, calc);
        LinearLayout rc = card();
        rc.addView(res);
        add(col, rc);
        add(col, tv("النصاب 85 غراماً من الذهب الخالص. خصم الديون رأي معتمد عند كثير من العلماء؛ عند الاشتباه استشر إماماً.", 12, GRAY, false));
        return o[0];
    }

    // ---------- BUDGET ----------
    View budget() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("💰 ميزانيتي", "دخلك ومصاريفك", o);
        JSONArray a = loadArr("budget");
        double inc = 0, out = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject b = a.optJSONObject(i);
            if (b == null) continue;
            double v = 0;
            try { v = Double.parseDouble(b.optString("amount", "0")); } catch (Exception e) { }
            if ("in".equals(b.optString("kind"))) inc += v; else out += v;
        }
        LinearLayout sum = card();
        sum.addView(tv("🟢 الدخل: " + fmtD(inc) + " دج", 16, 0xFF16A34A, true));
        sum.addView(tv("🔴 المصاريف: " + fmtD(out) + " دج", 16, 0xFFEF4444, true));
        sum.addView(tv("⚖️ الرصيد: " + fmtD(inc - out) + " دج", 20, inc - out >= 0 ? ACC : 0xFFEF4444, true));
        add(col, sum);
        section(col, "➕ تسجيل عملية", ACC2);
        final String[] kind = {"out"};
        final Button kb = button("🔴 مصروف (اضغط للتغيير إلى دخل)", ACC2, WHITE);
        kb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                kind[0] = kind[0].equals("out") ? "in" : "out";
                kb.setText(kind[0].equals("out") ? "🔴 مصروف (اضغط للتغيير إلى دخل)" : "🟢 دخل (اضغط للتغيير إلى مصروف)");
            }
        });
        add(col, kb);
        final EditText lab = edit("البيان (مثال: كراء، سوبرماركت، راتب)");
        add(col, lab);
        final EditText amt = edit("المبلغ بالدينار");
        amt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        add(col, amt);
        Button sv = button("💾 تسجيل", ACC, WHITE);
        sv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String s = amt.getText().toString().trim();
                if (s.isEmpty()) { toast("أدخل المبلغ أولاً"); return; }
                String l = lab.getText().toString().trim();
                addItem("budget", obj("kind", kind[0], "label", l.isEmpty() ? "عملية" : l, "amount", s, "date", fmt(System.currentTimeMillis())));
                show(47);
            }
        });
        add(col, sv);
        section(col, "📋 العمليات", CYAN);
        if (a.length() == 0) add(col, tv("لم تُسجَّل أي عملية بعد. ابدأ بتسجيل دخلك أو أول مصروف أعلاه.", 14, GRAY, false));
        for (int i = a.length() - 1; i >= 0; i--) {
            JSONObject b = a.optJSONObject(i);
            if (b == null) continue;
            final int idx = i;
            boolean in = "in".equals(b.optString("kind"));
            LinearLayout c = card();
            c.addView(tv((in ? "🟢 " : "🔴 ") + b.optString("label") + "  —  " + b.optString("amount") + " دج", 15, TXT, true));
            c.addView(tv(b.optString("date"), 12, GRAY, false));
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { confirmDelete("budget", idx, 47, "حذف هذه العملية؟"); return true; }
            });
            add(col, c);
        }
        if (a.length() > 0) add(col, tv("اضغط مطولاً على عملية لحذفها", 12, GRAY, false));
        return o[0];
    }

    // ---------- CHECKLISTS (Hajj, administrative documents) ----------
    void checklistInto(LinearLayout col, final String key, final String[] items, final int tab) {
        String st = sp.getString(key, "");
        for (int i = 0; i < items.length; i++) {
            final int idx = i;
            boolean on = i < st.length() && st.charAt(i) == '1';
            LinearLayout c = card();
            c.addView(tv((on ? "✅  " : "⬜  ") + items[i], 15, on ? GRAY : TXT, false));
            c.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    String cur = sp.getString(key, "");
                    StringBuilder sb = new StringBuilder();
                    for (int j = 0; j < items.length; j++) {
                        char ch = j < cur.length() ? cur.charAt(j) : '0';
                        if (j == idx) ch = ch == '1' ? '0' : '1';
                        sb.append(ch);
                    }
                    sp.edit().putString(key, sb.toString()).apply();
                    show(tab);
                }
            });
            add(col, c);
        }
    }

    View hajj() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🕋 تحضير الحج والعمرة", "قائمة تحضير اضغط على البند لتعليمه", o);
        checklistInto(col, "chk_hajj", HAJJ_ITEMS, 48);
        Button rs = button("🔄 إعادة تعيين القائمة", GRAY, WHITE);
        rs.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { sp.edit().remove("chk_hajj").apply(); show(48); } });
        add(col, rs);
        add(col, tv("هذه قائمة تذكيرية عامة؛ الشروط والمواعيد تحددها الجهات الرسمية المعتمدة.", 12, GRAY, false));
        return o[0];
    }

    View adminDocs() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📋 الوثائق الإدارية", "قوائم تحضير للمعاملات الشائعة", o);
        section(col, "🪪 بطاقة التعريف الوطنية", ACC);
        checklistInto(col, "chk_cn", CN_ITEMS, 50);
        section(col, "🛂 جواز السفر", ACC2);
        checklistInto(col, "chk_pp", PP_ITEMS, 50);
        section(col, "📜 شهادة الميلاد", CYAN);
        checklistInto(col, "chk_birth", BIRTH_ITEMS, 50);
        section(col, "🏠 عقد الكراء والسكن", ACC);
        checklistInto(col, "chk_rent", RENT_ITEMS, 50);
        section(col, "🚗 رخصة السياقة", CYAN);
        checklistInto(col, "chk_dl", DL_ITEMS, 50);
        section(col, "🆘 في حال ضياع وثيقة", ACC2);
        checklistInto(col, "chk_lost", LOST_ITEMS, 50);
        add(col, tv("القوائم تذكيرية؛ الوثائق والرسوم الفعلية تحددها المصلحة المختصة في بلديتك أو الموقع الرسمي للمعاملة.", 12, GRAY, false));
        return o[0];
    }

    // ---------- SHOPPING LIST ----------
    View shopping() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🛒 قائمة التسوق", "أضف ما تحتاجه واضغط لتعليمه", o);
        final EditText ed = edit("مثال: حليب، خبز، بيض");
        add(col, ed);
        Button ad = button("➕ أضف للقائمة", ACC, WHITE);
        ad.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String t = ed.getText().toString().trim();
                if (t.isEmpty()) { toast("اكتب شيئاً أولاً"); return; }
                addItem("shop", obj("name", t, "done", "0"));
                show(49);
            }
        });
        add(col, ad);
        JSONArray a = loadArr("shop");
        if (a.length() == 0) add(col, tv("القائمة فارغة. أضف أول منتج من الخانة أعلاه.", 14, GRAY, false));
        for (int i = 0; i < a.length(); i++) {
            JSONObject it = a.optJSONObject(i);
            if (it == null) continue;
            final int idx = i;
            boolean done = "1".equals(it.optString("done"));
            LinearLayout c = card();
            c.addView(tv((done ? "✅  " : "⬜  ") + it.optString("name"), 16, done ? GRAY : TXT, false));
            c.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { toggleItem("shop", idx, "done", 49); } });
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { confirmDelete("shop", idx, 49, "حذف هذا العنصر؟"); return true; }
            });
            add(col, c);
        }
        if (a.length() > 0) {
            Button cl = button("🧹 حذف المعلَّمة", GRAY, WHITE);
            cl.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    JSONArray src = loadArr("shop"), out = new JSONArray();
                    for (int i = 0; i < src.length(); i++) {
                        JSONObject it = src.optJSONObject(i);
                        if (it != null && !"1".equals(it.optString("done"))) out.put(it);
                    }
                    saveArr("shop", out);
                    show(49);
                }
            });
            add(col, cl);
        }
        return o[0];
    }

    // ---------- ACCOUNT (optional) ----------
    View login() {
        ScrollView[] o = new ScrollView[1];
        if (loggedIn()) {
            LinearLayout col = page("👤 حسابي", "ملفك الشخصي ونشاطك في التطبيق", o);
            LinearLayout pc = card();
            pc.addView(tv("👋 أهلاً " + sp.getString("acc_name", sp.getString("acc_user", "")), 20, TXT, true));
            pc.addView(tv("📍 " + curW(), 14, GRAY, false));
            add(col, pc);
            section(col, "📊 نشاطي", CYAN);
            int unpaid = 0;
            JSONArray bl = loadArr("bills");
            for (int i = 0; i < bl.length(); i++) {
                JSONObject b = bl.optJSONObject(i);
                if (b != null && !"1".equals(b.optString("paid"))) unpaid++;
            }
            LinearLayout st = card();
            st.addView(tv("🧾 فواتير غير مدفوعة: " + unpaid, 15, TXT, false));
            st.addView(tv("📣 شكاوي محفوظة: " + loadArr("complaints").length(), 15, TXT, false));
            st.addView(tv("📝 ملاحظات: " + loadArr("notes").length(), 15, TXT, false));
            st.addView(tv("🍴 مطاعم مفضّلة: " + loadArr("fav_rest").length(), 15, TXT, false));
            add(col, st);
            section(col, "✏️ معلوماتي", ACC);
            final EditText nm = edit("الاسم الكامل");
            nm.setText(sp.getString("acc_name", ""));
            add(col, nm);
            final EditText ph = edit("رقم الهاتف");
            ph.setInputType(InputType.TYPE_CLASS_PHONE);
            ph.setText(sp.getString("acc_phone", ""));
            add(col, ph);
            Button sv = button("💾 حفظ المعلومات", ACC, WHITE);
            sv.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    sp.edit().putString("acc_name", nm.getText().toString().trim()).putString("acc_phone", ph.getText().toString().trim()).apply();
                    toast("تم الحفظ");
                    show(33);
                }
            });
            add(col, sv);
            socialCard(col);
            Button out = button("🚪 تسجيل الخروج", ACC2, WHITE);
            out.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) { sp.edit().putBoolean("loggedIn", false).apply(); show(33); }
            });
            add(col, out);
            return o[0];
        }
        boolean reg = !hasAccount();
        LinearLayout col = page(reg ? "👤 إنشاء حساب" : "👤 تسجيل الدخول",
            reg ? "حساب اختياري لحفظ معلوماتك على هذا الجهاز" : "أدخل اسم المستخدم ورمز PIN", o);
        final EditText user = edit("اسم المستخدم");
        add(col, user);
        final EditText nmR = reg ? edit("الاسم الكامل (اختياري)") : null;
        if (reg) add(col, nmR);
        final EditText pin = edit("رمز PIN من 4 أرقام");
        pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        add(col, pin);
        final EditText pin2 = edit("أعد إدخال رمز PIN");
        pin2.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        if (reg) add(col, pin2);
        Button go = button(reg ? "✅ إنشاء الحساب" : "🔓 دخول", ACC, WHITE);
        go.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String u = user.getText().toString().trim();
                String p = pin.getText().toString().trim();
                if (u.isEmpty() || !p.matches("\\d{4}")) { toast("أدخل اسم المستخدم ورمز PIN من 4 أرقام"); return; }
                if (reg) {
                    if (!p.equals(pin2.getText().toString().trim())) { toast("رمزا PIN غير متطابقين"); return; }
                    sp.edit().putString("acc_user", u).putString("acc_pin", hashPin(p))
                        .putString("acc_name", nmR.getText().toString().trim())
                        .putBoolean("loggedIn", true).apply();
                    show(0);
                } else if (u.equals(sp.getString("acc_user", "")) && hashPin(p).equals(sp.getString("acc_pin", ""))) {
                    sp.edit().putBoolean("loggedIn", true).apply();
                    show(0);
                } else {
                    toast("اسم المستخدم أو رمز PIN غير صحيح");
                }
            }
        });
        add(col, go);
        add(col, tv("الحساب محلي على جهازك، واختياري بالكامل.", 12, GRAY, false));
        return o[0];
    }

    static final String[][] SEARCH_INDEX2 = {
        {"رمضان", "صيام إمساك إفطار عداد دعاء", "45"},
        {"القبلة", "اتجاه القبلة بوصلة مكة الكعبة", "52"},
        {"متابعة الصلاة", "صلوات الفجر الظهر العصر سلسلة صيام تتبع", "51"},
        {"حاسبة الزكاة", "زكاة نصاب ذهب مال", "46"},
        {"ميزانيتي", "ميزانية دخل مصاريف رصيد", "47"},
        {"تحضير الحج والعمرة", "حج عمرة مناسك قائمة", "48"},
        {"قائمة التسوق", "تسوق مشتريات قائمة", "49"},
        {"الوثائق الإدارية", "بطاقة تعريف جواز شهادة ميلاد كراء عقد", "50"},
        {"مواعيد الوثائق", "انتهاء صلاحية تذكير بطاقة جواز رخصة", "53"},
        {"طلبات الوثائق", "طلب متابعة حالة شهادة وثيقة إدارية", "55"},
        {"محوّل العملات", "يورو دولار صرف سعر عملة", "54"},
        {"الأحوال الجوية", "طقس مطر أمطار حرارة جو", "56"},
        {"المكتبة", "كتب كتاب قراءة مؤلف رواية", "57"},
        {"الطلبة الجزائريون", "طالب جامعة إقامة جامعية منحة طلبة", "58"},
        {"التشغيل والبطالة", "بطالة منحة عمل توظيف anem cnac", "59"},
        {"سوق وادكنيس", "وادكنيس بيع شراء إعلانات سوق", "60"},
        {"المصباح اليدوي", "مصباح فلاش ضوء كشاف", "61"}
    };

    // =====================================================================
    // v5.5: Qibla compass, prayer & fasting tracker, Quran progress, mosques
    // =====================================================================
    SensorManager sensorMgr;
    Sensor rotSensor;
    TextView qiblaArrow;
    double qiblaDeg = -1;
    boolean qiblaOn = false;
    final SensorEventListener qiblaListener = new SensorEventListener() {
        final float[] R = new float[9];
        final float[] ori = new float[3];
        public void onSensorChanged(SensorEvent e) {
            if (qiblaArrow == null || qiblaDeg < 0) return;
            SensorManager.getRotationMatrixFromVector(R, e.values);
            SensorManager.getOrientation(R, ori);
            double az = Math.toDegrees(ori[0]);
            qiblaArrow.setRotation((float) (qiblaDeg - az));
        }
        public void onAccuracyChanged(Sensor s, int accuracy) {}
    };

    void qiblaStart() {
        if (sensorMgr == null) sensorMgr = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (rotSensor == null) rotSensor = sensorMgr.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rotSensor != null) sensorMgr.registerListener(qiblaListener, rotSensor, SensorManager.SENSOR_DELAY_UI);
    }
    void qiblaStop() {
        if (sensorMgr != null) sensorMgr.unregisterListener(qiblaListener);
    }
    @Override
    protected void onPause() { qiblaStop(); if (torchOn) torchSet(false); super.onPause(); }
    @Override
    protected void onResume() { super.onResume(); if (qiblaOn) qiblaStart(); }

    View qibla() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🧭 اتجاه القبلة", "حرّك الهاتف حتى يشير السهم إلى الأمام", o);
        String la = sp.getString("lat", ""), ln = sp.getString("lng", "");
        if (la.isEmpty()) {
            add(col, tv("افتح «أوقات الصلاة» مرة واحدة ليُحدَّد موقع ولايتك، ثم عُد إلى هنا.", 14, GRAY, false));
            Button gb = button("🕌 أوقات الصلاة", ACC, WHITE);
            gb.setOnClickListener(go(9));
            add(col, gb);
            return o[0];
        }
        double lat = Double.parseDouble(la), lng = Double.parseDouble(ln);
        double kLat = Math.toRadians(21.4225), kLng = Math.toRadians(39.8262);
        double pl = Math.toRadians(lat), dl = kLng - Math.toRadians(lng);
        double y = Math.sin(dl) * Math.cos(kLat);
        double x = Math.cos(pl) * Math.sin(kLat) - Math.sin(pl) * Math.cos(kLat) * Math.cos(dl);
        qiblaDeg = (Math.toDegrees(Math.atan2(y, x)) + 360) % 360;
        double dp = kLat - pl;
        double h = Math.sin(dp / 2) * Math.sin(dp / 2) + Math.cos(pl) * Math.cos(kLat) * Math.sin(dl / 2) * Math.sin(dl / 2);
        double km = 2 * 6371 * Math.asin(Math.min(1, Math.sqrt(h)));

        LinearLayout c = card();
        c.setGravity(Gravity.CENTER);
        qiblaArrow = tv("⬆", 96, ACC, true);
        qiblaArrow.setGravity(Gravity.CENTER);
        c.addView(qiblaArrow);
        add(col, c);
        LinearLayout info = card();
        info.addView(tv("🕋 اتجاه القبلة: " + fmtD(qiblaDeg) + "° من الشمال", 16, TXT, true));
        info.addView(tv("📏 المسافة إلى مكة: " + fmtD(km) + " كم", 14, GRAY, false));
        add(col, info);
        if (rotSensor == null && sensorMgr == null) {
            sensorMgr = (SensorManager) getSystemService(SENSOR_SERVICE);
            rotSensor = sensorMgr.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        }
        if (rotSensor == null) add(col, tv("جهازك لا يملك بوصلة. استعمل الاتجاه المكتوب أعلاه مع بوصلة أخرى.", 13, GRAY, false));
        add(col, tv("للدقة، ابتعد عن المعادن والمغناطيس وأبقِ الهاتف مستوياً. الحساب يعتمد على موقع ولايتك.", 12, GRAY, false));
        qiblaOn = true;
        qiblaStart();
        return o[0];
    }

    // ---------- PRAYER & FASTING TRACKER ----------
    String dayKey(Calendar c) { return new SimpleDateFormat("yyyyMMdd", Locale.ENGLISH).format(c.getTime()); }

    View prayerTrack() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("✅ متابعة الصلاة والصيام", "سجّل صلواتك كل يوم وتابع سلسلتك", o);
        Calendar now = Calendar.getInstance();
        String day = dayKey(now);
        String[] names = {"الفجر", "الظهر", "العصر", "المغرب", "العشاء"};
        section(col, "🕌 صلوات اليوم", ACC);
        checklistInto(col, "pt_" + day, names, 51);
        section(col, "🌙 صيام اليوم", CYAN);
        checklistInto(col, "fast_" + day, new String[]{"صمت اليوم"}, 51);

        int total = 0, streak = 0;
        boolean first = true;
        Calendar c = Calendar.getInstance();
        for (int d = 0; d < 30; d++) {
            String st = sp.getString("pt_" + dayKey(c), "");
            int done = 0;
            for (int i = 0; i < st.length(); i++) if (st.charAt(i) == '1') done++;
            total += done;
            if (done == 5) streak++;
            else if (!first) break;
            first = false;
            c.add(Calendar.DAY_OF_YEAR, -1);
        }
        section(col, "📊 إحصائياتك", CYAN);
        LinearLayout sc = card();
        sc.addView(tv("🔥 سلسلة الأيام الكاملة: " + streak + " يوم", 16, TXT, true));
        sc.addView(tv("📈 نسبة الالتزام خلال 30 يوماً: " + fmtD(total * 100.0 / 150) + "%", 14, GRAY, false));
        add(col, sc);
        add(col, tv("السلسلة تحسب الأيام المكتملة بالصلوات الخمس، ويبقى اليوم الحالي مفتوحاً حتى يكتمل.", 12, GRAY, false));
        return o[0];
    }

    // ---------- QURAN PROGRESS ----------
    int readCount() {
        String s = sp.getString("q_read", "");
        int n = 0;
        for (int i = 1; i <= 114; i++) if (s.contains("," + i + ",")) n++;
        return n;
    }
    void markRead(int n) {
        String s = sp.getString("q_read", ",");
        if (!s.contains("," + n + ",")) s = s + n + ",";
        sp.edit().putString("q_read", s).putInt("last_surah", n).apply();
    }

    @Override
    protected void onRestart() { super.onRestart(); }

    // =====================================================================
    // v5.6: design system (brand font, gradient names), splash screen,
    // document expiry, document requests, currency converter
    // =====================================================================
    Typeface brandTf;
    static final String[] EXP_TYPES = {"🪪 بطاقة التعريف الوطنية", "🛂 جواز السفر", "🚗 رخصة السياقة", "🏠 عقد الكراء", "🛡️ تأمين السيارة", "🏷️ أخرى"};
    static final String[] DOC_REQ_TYPES = {"🪪 بطاقة التعريف الوطنية", "🛂 جواز السفر", "🚗 رخصة السياقة", "📜 شهادة الميلاد", "🏠 شهادة الإقامة", "📄 وثيقة أخرى"};
    static final String[] REQ_STATES = {"⏳ قيد الانتظار", "🛠️ قيد الإنجاز", "✅ جاهزة للاستلام"};
    static final String[] DL_ITEMS = {"طلب تجديد أو استخراج رخصة السياقة من الجهة المختصة", "الشهادة الطبية إن طُلبت", "بطاقة التعريف الوطنية", "صور شمسية حسب المتطلبات", "الرسوم (تحقق من المبلغ الحالي)"};
    static final String[] LOST_ITEMS = {"التصريح بالضياع لدى مصالح الأمن أو الدرك إن طُلب", "التوجه إلى مصلحة الوثيقة في بلديتك أو مركز الجهة المختصة", "تقديم شهادة الميلاد وصور شمسية", "حفظ وصل الطلب لمتابعة الإجراء"};

    // ---------- DESIGN SYSTEM ----------
    Typeface brand() {
        if (brandTf == null) {
            try { brandTf = Typeface.createFromAsset(getAssets(), "fonts/brand.ttf"); }
            catch (Exception e) { brandTf = Typeface.create("sans-serif-medium", Typeface.BOLD); }
        }
        return brandTf;
    }

    /** Text filled with a left-to-right gradient, used for the app and developer names. */
    TextView gradText(String s, float sizeSp, final int c1, final int c2, boolean italic) {
        TextView t = new TextView(this) {
            @Override
            protected void onSizeChanged(int w, int h, int ow, int oh) {
                super.onSizeChanged(w, h, ow, oh);
                getPaint().setShader(new LinearGradient(0, 0, w, 0, new int[]{c1, c2}, null, Shader.TileMode.CLAMP));
            }
        };
        t.setText(s);
        t.setTextSize(sizeSp * SC);
        t.setGravity(Gravity.CENTER);
        t.setLetterSpacing(0.08f);
        t.setTypeface(italic ? Typeface.create("serif", Typeface.BOLD_ITALIC) : brand());
        return t;
    }

    View splashView() {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF0B1020, 0xFF1E1B4B, 0xFF3B0764}));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        TextView logo = tv("R", 44, WHITE, true);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable circ = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{ACC2, ACC});
        circ.setShape(GradientDrawable.OVAL);
        logo.setBackground(circ);
        logo.setElevation(dp(8));
        col.addView(logo, new LinearLayout.LayoutParams(dp(96), dp(96)));
        TextView name = gradText("ALRAFIK PRO", 34, 0xFFFFB27A, ACC2, false);
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-1, -2);
        nl.setMargins(0, dp(22), 0, 0);
        col.addView(name, nl);
        TextView ar = tv("الرفيق", 22, 0xE6FFFFFF, true);
        ar.setGravity(Gravity.CENTER);
        col.addView(ar);
        TextView wel = tv("مرحباً بك 👋", 16, 0xFFFFFFFF, true);
        wel.setGravity(Gravity.CENTER);
        wel.setPadding(0, dp(14), 0, 0);
        col.addView(wel);
        View line = new View(this);
        line.setBackgroundColor(0x66FFFFFF);
        LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(dp(120), dp(1));
        ll.setMargins(0, dp(20), 0, dp(20));
        col.addView(line, ll);
        TextView by = tv("✦  تطوير  ✦", 12, 0xB3FFFFFF, true);
        by.setGravity(Gravity.CENTER);
        by.setLetterSpacing(0.3f);
        col.addView(by);
        TextView dev = gradText("Chafik Sehmi", 28, 0xFF22D3EE, 0xFFF0ABFC, true);
        col.addView(dev, new LinearLayout.LayoutParams(-1, -2));
        f.addView(col, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        return f;
    }

    // ---------- DOCUMENT EXPIRY ----------
    View expiry() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("⏰ مواعيد الوثائق", "ننبهك قبل 30 يوماً من انتهاء كل وثيقة", o);
        final String[] type = {EXP_TYPES[0]};
        final Button tb = button("نوع الوثيقة: " + EXP_TYPES[0], ACC, WHITE);
        tb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this).setItems(EXP_TYPES, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { type[0] = EXP_TYPES[w]; tb.setText("نوع الوثيقة: " + EXP_TYPES[w]); }
                }).show();
            }
        });
        add(col, tb);
        final long[] exp = {System.currentTimeMillis() + 365L * 86400000L};
        final Button db = button("📆 تاريخ الانتهاء: " + dayStr(exp[0]), ACC2, WHITE);
        db.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Calendar n = Calendar.getInstance();
                new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker p, int y, int m, int d) {
                        Calendar c = Calendar.getInstance(); c.set(y, m, d, 12, 0, 0);
                        exp[0] = c.getTimeInMillis();
                        db.setText("📆 تاريخ الانتهاء: " + dayStr(exp[0]));
                    }
                }, n.get(Calendar.YEAR), n.get(Calendar.MONTH), n.get(Calendar.DAY_OF_MONTH)).show();
            }
        });
        add(col, db);
        Button sv = button("💾 حفظ وتفعيل التذكير", 0xFF16A34A, WHITE);
        sv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int rid = 1000 + new Random().nextInt(900000);
                addItem("expiry", obj("type", type[0], "due", String.valueOf(exp[0]), "rid", String.valueOf(rid)));
                AlarmReceiver.rescheduleAll(MainActivity.this);
                show(53);
            }
        });
        add(col, sv);

        section(col, "📋 وثائقي", CYAN);
        JSONArray a = loadArr("expiry");
        if (a.length() == 0) add(col, tv("لم تُضف أي وثيقة بعد. اختر نوعها وتاريخ انتهائها أعلاه.", 14, GRAY, false));
        long now = System.currentTimeMillis();
        for (int i = a.length() - 1; i >= 0; i--) {
            JSONObject b = a.optJSONObject(i);
            if (b == null) continue;
            final int idx = i;
            long due = 0;
            try { due = Long.parseLong(b.optString("due", "0")); } catch (Exception e) { }
            long days = (due - now) / 86400000L;
            int color = days < 30 ? 0xFFEF4444 : (days < 90 ? 0xFFF59E0B : 0xFF16A34A);
            LinearLayout c = card();
            c.addView(tv(b.optString("type"), 16, TXT, true));
            c.addView(tv("تنتهي: " + dayStr(due) + "  •  " + (days < 0 ? "منتهية" : "بعد " + days + " يوماً"), 13, color, true));
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) {
                    new AlertDialog.Builder(MainActivity.this).setMessage("حذف هذه الوثيقة من المتابعة؟")
                        .setPositiveButton("حذف", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface d, int w) {
                                JSONObject it = loadArr("expiry").optJSONObject(idx);
                                if (it != null) AlarmReceiver.cancelAt(MainActivity.this, "exp" + AlarmReceiver.ridOf(it), AlarmReceiver.ridOf(it));
                                removeAt("expiry", idx);
                                show(53);
                            }
                        }).setNegativeButton("إلغاء", null).show();
                    return true;
                }
            });
            add(col, c);
        }
        if (a.length() > 0) add(col, tv("اضغط مطولاً على وثيقة لحذفها من المتابعة", 12, GRAY, false));
        return o[0];
    }

    // ---------- DOCUMENT REQUESTS TRACKER ----------
    View docRequests() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📨 طلبات الوثائق", "تابع حالة كل طلب إداري", o);
        final String[] type = {DOC_REQ_TYPES[0]};
        final Button tb = button("نوع الوثيقة: " + DOC_REQ_TYPES[0], ACC, WHITE);
        tb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this).setItems(DOC_REQ_TYPES, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int w) { type[0] = DOC_REQ_TYPES[w]; tb.setText("نوع الوثيقة: " + DOC_REQ_TYPES[w]); }
                }).show();
            }
        });
        add(col, tb);
        final EditText office = edit("المكتب أو البلدية أو الجهة");
        add(col, office);
        Button sv = button("💾 تسجيل الطلب", ACC2, WHITE);
        sv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String of = office.getText().toString().trim();
                addItem("doc_req", obj("type", type[0], "office", of.isEmpty() ? "غير محدد" : of, "date", fmt(System.currentTimeMillis()), "st", "0"));
                show(55);
            }
        });
        add(col, sv);
        section(col, "📋 طلباتي", CYAN);
        JSONArray a = loadArr("doc_req");
        if (a.length() == 0) add(col, tv("لم تُسجَّل أي طلبات بعد. أضف طلبك الأول أعلاه.", 14, GRAY, false));
        for (int i = a.length() - 1; i >= 0; i--) {
            JSONObject b = a.optJSONObject(i);
            if (b == null) continue;
            final int idx = i;
            int st = 0;
            try { st = Integer.parseInt(b.optString("st", "0")) % 3; } catch (Exception e) { }
            final int nextSt = (st + 1) % 3;
            LinearLayout c = card();
            c.addView(tv(b.optString("type"), 16, TXT, true));
            c.addView(tv(REQ_STATES[st] + "  •  " + b.optString("office"), 13, st == 2 ? 0xFF16A34A : ACC, true));
            c.addView(tv(b.optString("date"), 12, GRAY, false));
            c.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    JSONArray src = loadArr("doc_req");
                    JSONObject it = src.optJSONObject(idx);
                    if (it != null) { try { it.put("st", String.valueOf(nextSt)); } catch (Exception e) { } }
                    saveArr("doc_req", src);
                    show(55);
                }
            });
            c.setOnLongClickListener(new View.OnLongClickListener() {
                public boolean onLongClick(View v) { confirmDelete("doc_req", idx, 55, "حذف هذا الطلب؟"); return true; }
            });
            add(col, c);
        }
        if (a.length() > 0) add(col, tv("اضغط على الطلب لتغيير حالته • اضغط مطولاً للحذف", 12, GRAY, false));
        return o[0];
    }

    // ---------- CURRENCY CONVERTER (rates entered manually) ----------
    static String fmt2(double v) { return String.format(Locale.ENGLISH, "%.2f", v); }

    View currency() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("💱 محوّل العملات", "أدخل سعر الصرف الذي يعرضه بنكك أو مكتب الصرف", o);
        final EditText eur = edit("سعر 1 يورو بالدينار");
        eur.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        eur.setText(sp.getString("rate_eur", ""));
        add(col, eur);
        final EditText usd = edit("سعر 1 دولار بالدينار");
        usd.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        usd.setText(sp.getString("rate_usd", ""));
        add(col, usd);
        final EditText amt = edit("المبلغ");
        amt.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        add(col, amt);
        final TextView res = tv("", 16, ACC, true);
        Button cv = button("🔄 حوّل", ACC, WHITE);
        cv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                sp.edit().putString("rate_eur", eur.getText().toString().trim())
                    .putString("rate_usd", usd.getText().toString().trim()).apply();
                double a = num(amt), e = num(eur), u = num(usd);
                StringBuilder sb = new StringBuilder();
                if (e > 0) {
                    sb.append("🇪🇺 ").append(fmt2(a)).append(" دج = ").append(fmt2(a / e)).append(" €\n");
                    sb.append("🇪🇺 ").append(fmt2(a)).append(" € = ").append(fmt2(a * e)).append(" دج\n");
                }
                if (u > 0) {
                    sb.append("🇺🇸 ").append(fmt2(a)).append(" دج = ").append(fmt2(a / u)).append(" $\n");
                    sb.append("🇺🇸 ").append(fmt2(a)).append(" $ = ").append(fmt2(a * u)).append(" دج");
                }
                res.setText(sb.length() == 0 ? "أدخل سعر الصرف أولاً." : sb.toString().trim());
            }
        });
        add(col, cv);
        LinearLayout rc = card();
        rc.addView(res);
        add(col, rc);
        add(col, tv("التطبيق لا يجلب أسعار الصرف تلقائياً؛ أدخل السعر الذي تراه اليوم لدى مصرفك لنتيجة دقيقة.", 12, GRAY, false));
        return o[0];
    }

    // =====================================================================
    // v5.7: weather, books, students, jobs, marketplace, torch, pinned
    // favourites, welcome sound, corrected match lists
    // =====================================================================
    CameraManager camMgr;
    String torchId;
    boolean torchOn = false;

    static String wmo(int c) {
        if (c == 0) return "☀️ صافٍ";
        if (c <= 2) return "🌤️ غائم جزئياً";
        if (c == 3) return "☁️ ملبّد";
        if (c == 45 || c == 48) return "🌫️ ضباب";
        if (c >= 51 && c <= 57) return "🌦️ رذاذ";
        if (c >= 61 && c <= 67) return "🌧️ مطر";
        if (c >= 71 && c <= 77) return "❄️ ثلج";
        if (c >= 80 && c <= 82) return "🌦️ زخات مطر";
        if (c >= 95) return "⛈️ عاصفة رعدية";
        return "🌥️ متغيّر";
    }

    View weather() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🌦️ الأحوال الجوية", "طقس ولايتك وفرص الأمطار", o);
        final String la = sp.getString("lat", ""), ln = sp.getString("lng", "");
        if (la.isEmpty()) {
            add(col, tv("افتح «أوقات الصلاة» مرة واحدة ليُحدَّد موقع ولايتك، ثم عُد إلى هنا.", 14, GRAY, false));
            Button gb = button("🕌 أوقات الصلاة", ACC, WHITE);
            gb.setOnClickListener(go(9));
            add(col, gb);
            return o[0];
        }
        final LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        col.addView(body, new LinearLayout.LayoutParams(-1, -2));
        add(body, tv("⏳ جارٍ تحميل الطقس...", 14, GRAY, false));
        new Thread(new Runnable() {
            public void run() {
                try {
                    String s = AlarmReceiver.getUrl("https://api.open-meteo.com/v1/forecast?latitude=" + la + "&longitude=" + ln
                        + "&current=temperature_2m,weather_code&hourly=precipitation_probability&timezone=auto");
                    JSONObject j = new JSONObject(s);
                    JSONObject cur = j.getJSONObject("current");
                    final double temp = cur.getDouble("temperature_2m");
                    final int code = cur.getInt("weather_code");
                    JSONArray pp = j.getJSONObject("hourly").getJSONArray("precipitation_probability");
                    int max6 = 0, max12 = 0;
                    for (int i = 0; i < pp.length() && i < 12; i++) {
                        int v = pp.optInt(i);
                        if (i < 6) max6 = Math.max(max6, v);
                        max12 = Math.max(max12, v);
                    }
                    final int m6 = max6, m12 = max12;
                    runOnUiThread(new Runnable() {
                        public void run() {
                            body.removeAllViews();
                            LinearLayout c = card();
                            c.addView(tv(wmo(code), 18, TXT, true));
                            c.addView(tv(fmtD(temp) + "°", 48, ACC, true));
                            c.addView(tv("📍 " + curW(), 13, GRAY, false));
                            add(body, c);
                            LinearLayout r = card();
                            r.addView(tv("🌧️ احتمال المطر خلال 6 ساعات: " + m6 + "%", 15, TXT, true));
                            r.addView(tv("🌧️ احتمال المطر خلال 12 ساعة: " + m12 + "%", 15, TXT, false));
                            add(body, r);
                            if (m6 >= 60) {
                                LinearLayout w = card();
                                w.addView(tv("☔ خذ مظلتك: الأمطار مرجّحة قريباً", 15, 0xFFEF4444, true));
                                add(body, w);
                            }
                            add(body, tv("تُرسل تنبيهات المطر تلقائياً كل 3 ساعات عند احتمال مرتفع (يمكن إيقافها من الإعدادات).", 12, GRAY, false));
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        public void run() { body.removeAllViews(); add(body, tv("تعذّر تحميل الطقس، تحقق من الإنترنت ثم أعد فتح الصفحة.", 14, GRAY, false)); }
                    });
                }
            }
        }).start();
        return o[0];
    }

    // ---------- BOOKS (Open Library, free catalogue) ----------
    View books() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("📚 المكتبة", "ابحث في مكتبة Open Library المفتوحة", o);
        final EditText q = edit("ابحث بالعنوان أو المؤلف");
        add(col, q);
        final boolean[] arOnly = {true};
        final Button lang = button("🌐 الكتب العربية فقط", ACC2, WHITE);
        lang.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                arOnly[0] = !arOnly[0];
                lang.setText(arOnly[0] ? "🌐 الكتب العربية فقط" : "🌍 كل اللغات");
            }
        });
        add(col, lang);
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        col.addView(list, new LinearLayout.LayoutParams(-1, -2));
        Button sb = button("🔎 بحث", ACC, WHITE);
        sb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                final String term = q.getText().toString().trim();
                if (term.length() < 2) { toast("اكتب كلمتين على الأقل"); return; }
                list.removeAllViews();
                add(list, tv("⏳ جارٍ البحث...", 14, GRAY, false));
                final boolean ar = arOnly[0];
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            String u = "https://openlibrary.org/search.json?q=" + Uri.encode(term) + "&limit=20" + (ar ? "&language=ara" : "");
                            JSONArray docs = new JSONObject(httpGet(u)).getJSONArray("docs");
                            final JSONArray res = docs;
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    list.removeAllViews();
                                    if (res.length() == 0) { add(list, tv("لا توجد نتائج. جرّب كلمات أخرى أو اختر كل اللغات.", 14, GRAY, false)); return; }
                                    for (int i = 0; i < res.length(); i++) {
                                        JSONObject d = res.optJSONObject(i);
                                        if (d == null) continue;
                                        String author = "مؤلف غير معروف";
                                        JSONArray an = d.optJSONArray("author_name");
                                        if (an != null && an.length() > 0) author = an.optString(0);
                                        final String key = d.optString("key", "");
                                        LinearLayout c = card();
                                        c.addView(tv(d.optString("title", "بدون عنوان"), 16, TXT, true));
                                        c.addView(tv("✍️ " + author + (d.has("first_publish_year") ? "  •  " + d.optInt("first_publish_year") : ""), 13, GRAY, false));
                                        c.setOnClickListener(new View.OnClickListener() {
                                            public void onClick(View v) { open("https://openlibrary.org" + key); }
                                        });
                                        add(list, c);
                                    }
                                    add(list, tv("الروابط تفتح صفحة الكتاب في Open Library، حيث تجد الإصدارات المتاحة.", 12, GRAY, false));
                                }
                            });
                        } catch (Exception e) {
                            runOnUiThread(new Runnable() {
                                public void run() { list.removeAllViews(); add(list, tv("تعذّر البحث، تحقق من الإنترنت.", 14, GRAY, false)); }
                            });
                        }
                    }
                }).start();
            }
        });
        add(col, sb);
        return o[0];
    }

    // ---------- STUDENTS ----------
    View students() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🎓 الطلبة الجزائريون", "أدوات الدراسة والسكن والمكتبة", o);
        section(col, "📚 دراستي", ACC);
        navCard(col, "🎓 حاسبة المعدل", 10);
        navCard(col, "📝 ملاحظات الدروس", 23);
        navCard(col, "📚 المكتبة والكتب", 57);
        navCard(col, "🧾 ميزانية الطالب", 47);
        navCard(col, "⏰ مواعيد الوثائق (بطاقة، جواز، ...)", 53);
        section(col, "🏠 السكن الجامعي والمنحة", CYAN);
        infoCard(col, "🏠 الإقامة الجامعية",
            "طلبات الإقامة والمطعم الجامعي تُقدَّم عادة عبر الديوان الوطني للخدمات الجامعية في الجامعة أو الموقع الرسمي المعلن. اسأل مصلحة الطلبة في جامعتك عن المواعيد والشروط الحالية.");
        infoCard(col, "💰 المنحة الجامعية",
            "تُحدَّد حسب الوضعية الاجتماعية وتُقدَّم سنوياً عبر منصة الجامعة. احتفظ بوثائق الدخل والإقامة جاهزة قبل فتح باب الطلبات.");
        section(col, "💡 نصائح", CYAN);
        infoCard(col, "🗓️ نظّم أسبوعك", "سجّل محاضراتك وامتحاناتك في «مواعيدي»، وأضف كل امتحان كحدث حتى لا يفوتك موعد.");
        infoCard(col, "💸 ميزانية الشهر", "سجّل المنحة والمصاريف في «ميزانيتي» لتعرف متى تحتاج إلى التقشّف.");
        add(col, tv("المعلومات عامة؛ المواعيد والشروط تحددها الجامعة والجهات الوصية.", 12, GRAY, false));
        return o[0];
    }

    // ---------- UNEMPLOYMENT & EMPLOYMENT ----------
    View jobs() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("💼 التشغيل والبطالة", "منح البطالة والبحث عن عمل", o);
        infoCard(col, "💼 منحة البطالة",
            "تُمنح لبعض المسجلين لدى الوكالة الوطنية للتشغيل (ANEM) أو وفق برامج الصندوق الوطني للتأمين عن البطالة (CNAC) بشروط محددة. الشروط والمبالغ تتغيّر، فتحقق منها لدى الجهة المعنية.");
        infoCard(col, "📋 وثائق التسجيل",
            "عادةً: بطاقة التعريف الوطنية، شهادة العمل أو عقد العمل السابق، شهادة الشهادة أو المؤهل، وصورة شمسية. تأكد من القائمة الحالية عند الجهة.");
        linkGroup(col, "🔗 الجهات الرسمية", ACC, new String[][]{
            {"💼 الوكالة الوطنية للتشغيل ANEM", "https://www.anem.dz"},
            {"📊 الصندوق الوطني للتأمين عن البطالة CNAC", "https://www.cnac.dz"},
            {"🚀 ANADE دعم المقاولاتية", "https://www.anade.dz"}});
        linkCard(col, "🔎 عروض العمل على الإنترنت", google("توظيف عروض عمل الجزائر"));
        add(col, tv("للتسجيل والمتابعة استعمل الموقع الرسمي للجهة فقط.", 12, GRAY, false));
        return o[0];
    }
    String google(String q) { return "https://www.google.com/search?q=" + Uri.encode(q); }

    // ---------- OUEDKNISS MARKETPLACE ----------
    View marketplace() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🛒 سوق وادكنيس", "البيع والشراء والإعلانات المبوّبة", o);
        final EditText q = edit("ابحث عن منتج (مثال: هاتف، سيارة، شقة)");
        add(col, q);
        Button sb = button("🔎 ابحث في وادكنيس", ACC, WHITE);
        sb.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String t = q.getText().toString().trim();
                open(google("ouedkniss " + (t.isEmpty() ? "" : t)));
            }
        });
        add(col, sb);
        linkCard(col, "🏠 الموقع الرسمي لوادكنيس", "https://www.ouedkniss.com");
        infoCard(col, "🛡️ نصائح الشراء الآمن",
            "لا تدفع قبل رؤية السلعة. تفقّد هوية البائع وتقييماته. تجنّب الدفع المسبق لحساب بريدي مجهول. التقِ في مكان عام وبحضور شخص آخر عند الصفقات الكبيرة.");
        infoCard(col, "🚩 علامات تحذير",
            "سعر أقل بكثير من السوق، إلحاح على الدفع، رفض المعاينة، أو طلب رمز أو كود عبر الهاتف.");
        add(col, tv("التطبيق يفتح نتائج البحث في المتصفح؛ الإعلانات والمعاملات بين الأفراد تتم على مسؤولية المتعاملين.", 12, GRAY, false));
        return o[0];
    }

    // ---------- TORCH ----------
    void torchSet(boolean on) {
        if (Build.VERSION.SDK_INT < 23) { toast("المصباح يحتاج Android 6 أو أحدث"); return; }
        try {
            if (camMgr == null) camMgr = (CameraManager) getSystemService(CAMERA_SERVICE);
            if (torchId == null) {
                for (String id : camMgr.getCameraIdList()) {
                    CameraCharacteristics ch = camMgr.getCameraCharacteristics(id);
                    Boolean f = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                    if (f != null && f) { torchId = id; break; }
                }
            }
            if (torchId == null) { toast("لا يوجد فلاش في جهازك"); return; }
            camMgr.setTorchMode(torchId, on);
            torchOn = on;
        } catch (Throwable e) {
            toast("تعذّر تشغيل المصباح");
        }
    }

    View torch() {
        ScrollView[] o = new ScrollView[1];
        LinearLayout col = page("🔦 المصباح اليدوي", "اضغط الدائرة لتشغيل الفلاش أو إطفائه", o);
        final Button big = button(torchOn ? "⏻ إطفاء" : "⏻ تشغيل", torchOn ? 0xFFEF4444 : ACC, WHITE);
        big.setTextSize(26 * SC);
        big.setMinHeight(dp(180));
        big.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                torchSet(!torchOn);
                big.setText(torchOn ? "⏻ إطفاء" : "⏻ تشغيل");
                big.setBackground(shape(torchOn ? 0xFFEF4444 : ACC, 90));
            }
        });
        add(col, big);
        add(col, tv("يُطفأ المصباح تلقائياً عند الخروج من التطبيق.", 12, GRAY, false));
        return o[0];
    }

    // ---------- PINNED FAVOURITES (subscriber feature) ----------
    String labelFor(int tab) {
        for (String[][] group : new String[][][]{SEARCH_INDEX, SEARCH_INDEX2}) {
            for (String[] s : group) if (Integer.parseInt(s[2]) == tab) return s[0];
        }
        return "قسم " + tab;
    }
    boolean isPinned(int tab) { return sp.getString("pins", ",").contains("," + tab + ","); }
    void togglePin(int tab) {
        String s = sp.getString("pins", ",");
        if (isPinned(tab)) s = s.replace("," + tab + ",", ",");
        else s = s + tab + ",";
        sp.edit().putString("pins", s).apply();
    }
    void addPinned(LinearLayout col) {
        String s = sp.getString("pins", ",");
        if (s.length() <= 1) return;
        section(col, "⭐ مفضّلتي", ACC2);
        HorizontalScrollView hs = new HorizontalScrollView(this);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (String part : s.split(",")) {
            if (part.isEmpty()) continue;
            final int tab = Integer.parseInt(part);
            Button b = button(labelFor(tab), CARD, TXT);
            b.setOnClickListener(go(tab));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.setMargins(dp(4), dp(4), dp(4), dp(4));
            row.addView(b, lp);
        }
        hs.addView(row);
        add(col, hs);
    }

    void welcomeSound() {
        if (!sp.getBoolean("welcome_sound", true)) return;
        try {
            final MediaPlayer mp = MediaPlayer.create(this, R.raw.welcome);
            if (mp == null) return;
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                public void onCompletion(MediaPlayer m) { m.release(); }
            });
            mp.start();
        } catch (Throwable e) { }
    }
}
