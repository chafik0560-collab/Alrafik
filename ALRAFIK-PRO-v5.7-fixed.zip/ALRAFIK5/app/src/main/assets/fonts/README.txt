Brand font (optional)
=====================
Put a TrueType font named brand.ttf in this folder to change the app's titles and names.
Example: download "Cairo" or "Tajawal" (Arabic, free, SIL Open Font License) from fonts.google.com,
rename the .ttf file to brand.ttf and place it here. Without it, the app uses the system font.
