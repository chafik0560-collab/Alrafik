# ALRAFIK PRO - الرفيق (v5.1)
Developer: Chafik Sehmi
Plain Java + Android framework only (for CodeAssist), no AndroidX.
Data sources: aladhan.com (prayer, method 19), TheSportsDB free key (football). Info may change.

## What's new in v5.1
- Islamic section: Quran (114 surahs, text loaded online), Hisn al-Muslim selection, hadith collection with random hadith, step-by-step prayer teaching, digital tasbih.
- Login: local account with PIN (create on first run), logout in settings.
- Home screen reorganized into groups (Islamic, Services, Daily life, Women, Account).

## What's new in v5.0
- Live clock in the top bar (HH:mm:ss).
- Women: monthly cycle calculator (next period, ovulation, fertile window, history, average cycle length).
- Hospitals: nearby hospitals / emergency / pharmacy search, university hospitals, SAMU and civil protection numbers.
- Municipality services: civil-status documents, urbanism, waste fee, complaints.
- My Documents: pick PDF/image files from the phone (stores references only, nothing uploaded).
- Complaints: write, categorize, send (WhatsApp/email/SMS) and track status locally.
- Internet recharge: operators and voucher code copy helper.
- Notes log: local notes, long-press to delete.
- Bills: water, gas, electricity, rent, phone; due dates, overdue highlighting, paid toggle, total due.
- Restaurants: category search in your wilaya, delivery link, favorites list.
- Home grid and "More" menu updated with all new sections.

## Privacy
All user data (notes, bills, complaints, cycle history, documents list) stays on the device in SharedPreferences.
